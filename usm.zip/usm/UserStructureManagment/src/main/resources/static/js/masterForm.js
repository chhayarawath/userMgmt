$(document)
		.ready(
				function() {
					
				var forms = document.getElementsByTagName('form');
				for (var i = 0; i < forms.length; i++) {
					forms[i].setAttribute('autocomplete', 'off');
				}

					/*
					 * $('body').bind('cut copy paste', function(e) {
					 * e.preventDefault(); });
					 */

					$("form").attr('autocomplete', 'off');

					setTimeout(function() {
						$('#status_message').fadeOut();
					}, 8000);

					setTimeout(function() {
						$('#warning_message').fadeOut();
					}, 8000);

					setTimeout(function() {
						$('#error_message').fadeOut();
					}, 8000);

					$("#filter").click(
							function(event) {
								if ($('#filter-panel').hasClass('collapse')) {
									$('#filter-panel-text').collapse('show');
									$('#filter-panel').collapse('hide');

									$("#divFilterText").html(
											"<label class='currentColor'>"
													+ headerArea + "</label>");
								}

								if ($('#filter-panel-text')
										.hasClass('collapse')) {
									$('#filter-panel-text').collapse('hide');
									$('#filter-panel').collapse('show');
								}
							});

					/* for file upload */
					onFileUploadFunc();

				});
function checkFileExistsInModify() {

	var j = 10000;
	$('.hidden')
			.each(
					function(i, obj) {

						if (obj.value.length > 0) {
							var url = "download/pdf/" + obj.value;

							document.getElementById('displayFile' + j).innerHTML = "<a href='"
									+ url + "'>" + obj.value + "</a>"
							document.getElementById('divFaIcon' + j).innerHTML = "<i class='fa fa-remove mandatory pointer'  id='closeFile"
									+ j
									+ "'  onclick='removeFile(\""
									+ j
									+ "\",\""
									+ "file"
									+ j
									+ "\",\""
									+ obj.id
									+ "\");' ></i>";
						}
						j++;
					});
}

/*
 * mode 1= save and view function on screen, mode 2= only reset functionality on
 * screen
 */
var filename;
function uploadDoc(fileId, mode) {
	
	var fillpass = fileId;
	filename = document.getElementById(fileId).value;
	regex = new RegExp("(.*?)\.(pdf|jpg|png|jpeg|PNG|JPG|JPEG|PDF)$");
	if ((regex.test(filename))) {
		formData = captureFileWithSecurityCode(filename, fileId);
		if(formData != 0)
			$.ajax({
					url : 'echofile',
					type : "POST",
					data : formData,
					enctype : 'multipart/form-data',
					processData : false,
					contentType : false
				})
				.done(function(data) {
						if (mode == 1)
							fileUploadSuccessWithView(data, fileId);
						else
							fileUploadSuccessWithoutView(data, fileId);
					})
				.fail(function(jqXHR, textStatus) {
					var msg = '';
			        if (jqXHR.status === 0) {
			            msg = 'Not connect.\n Verify Network.';
			        } else if (jqXHR.status == 404) {
			            msg = 'Requested page not found. [404]';
			        } else if (jqXHR.status == 500) {
			            msg = 'Internal Server Error [500].';
			        } else if (textStatus === 'parsererror') {
			            msg = 'Requested JSON parse failed.';
			        } else if (textStatus === 'timeout') {
			            msg = 'Time out error.';
			        } else if (textStatus === 'abort') {
			            msg = 'Ajax request aborted.';
			        } else {
			            msg = 'Uncaught Error.\n' + jqXHR.responseText;
			        }
							
					bootbox.alert('File upload failed ...'+msg+" >> "+textStatus);
					var selectedTab = window.frameElement.id.split("_")[0].split(" ").join("_");  
					var secSelTab = hex_md5(selectedTab);
					$('#'+csrf_token_key).val(getToken(secSelTab));
				});		
		
	} else {
		bootbox.alert("This is not valid file. Ex-(pdf|jpg|png|jpeg|PNG|JPG|JPEG|PDF) ");
		return false;
	}
}


function captureFileWithSecurityCode(filename,fileId) {
	var oFile = document.getElementById(fileId).files[0];
	if (oFile.size > 5242880) {// 5 mb for bytes.
		bootbox.alert("File size must be under 5 MB!");
		return 
	}

	var formData = new FormData();
	formData.append("file", document.getElementById(fileId).files[0]);
	formData.append(csrf_token_key , $('#'+csrf_token_key).val() );
	formData.append("f_codes"+fileId , $("#f_codes"+fileId).val() );
	var qstring = getFormDataParams(formData);	 
	var hcode = getHexaCode(qstring);
	formData.append(token_key , hcode ); 
	formData.delete("f_codes"+fileId);
	$("#f_codes"+fileId).remove();
	return formData;
}

function fileUploadSuccessWithView(data, fileId) {
	if(data.includes("Error")) {
		document.getElementsByTagName("body")[0].innerHTML = data;
	}
	
	$('#hstnumViewFileFlag').val(0);
	var url = "download/pdf/" + data;
	
	document.getElementById('divFaIcon' + fileId).innerHTML = "<a class='btn btn-info' id='closeFile"
			+ fileId
			+ "'  onclick='removeFile(\""
			+ fileId
			+ "\");' >Reset</a> "
			+ "<a class='btn btn-warning'  href='download/pdf/"
			+ data
			+ "' id='openFile"
			+ fileId
			+ "' onclick='enableViewFlag();'>View</a>"
			+ "<button type='submit' id='btnSave' class='btn btn-primary lessMargin'>Save</button>";
	
	document.getElementById('displayFile' + fileId).innerHTML = "<a href='"
		+ url
		+ "'>"
		+ data
		+ "</a><input type='file' style='display: none;' id='"+fileId+"' name='file'>";
		
	document.getElementById('filename' + fileId).value = data;
	
	 var selectedTab = window.frameElement.id.split("_")[0].split(" ").join("_");  
	 var secSelTab = hex_md5(selectedTab);
		
	 $('#'+csrf_token_key).val(getToken(secSelTab)); 

	 $("#btnSave").click(
		function(event) {
			var fileName = document.getElementById('filename' + fileId).value;
			if (fileName.length > 0) {
				var viewFileFlag = $('#hstnumViewFileFlag').val();
				if (viewFileFlag == 0) {
					bootbox.alert('Kindly review your file before upload.');
					return false;
				} else {
					finalUploadDoc();
					return true;
				}
			}
		});
}


function fileUploadSuccessWithoutView(data,fileId) {
	if(data.includes("Error")){
		
		document.getElementsByTagName("body")[0].innerHTML = data;
		
	}
	
	var url = "download/pdf/" + data;
	
	document.getElementById('divFaIcon' + fileId).innerHTML = "<a class='btn btn-info' id='closeFile"
			+ fileId
			+ "'  onclick='removeFileWithoutView(\""
			+ fileId
			+ "\");' >Reset</a> ";		
	
	document.getElementById('displayFile' + fileId).innerHTML = "<a href='"
		+ url
		+ "'>"
		+ data
		+ "</a><input type='file' style='display: none;' id='"+fileId+"' name='file'>"
		
		document.getElementById('filename' + fileId).value = data;
	
	 var selectedTab = window.frameElement.id.split("_")[0].split(" ").join("_");  
	 var secSelTab = hex_md5(selectedTab);
		
	 $('#'+csrf_token_key).val(getToken(secSelTab)); 

}




function removeFile(fileid) {
	$('.wid-75-margin').val("");
	var fileNameToDelete = document.getElementById('filename' + fileid).value;
	document.getElementById('filename' + fileid).value = "";

	document.getElementById('displayFile' + fileid).innerHTML = "<label class='div-inline'><span "
			+ "class='btn btn-primary'>Choose File<input type='file' style='display: none;'"
			+ " id='"+fileid+"' name='file'></span></label> <input type='text' "
			+ "class='form-control div-inline wid-75-margin' readonly='readonly'>";

	document.getElementById('divFaIcon' + fileid).innerHTML = "<a class='btn btn-info' id='faUpload"+fileid+"' " + "onclick='uploadDoc("+fileid+",1);'>Upload</a>";

	onFileUploadFunc();
	
	$.ajax({
		url : 'deleteFile',
		type : "GET",
		data : {
			fileToDelete: fileNameToDelete
		},
	})
	.done(function(data) {
		console.log("File Deleted: " + data);
	})
	.fail(function(jqXHR, textStatus) {
		console.log("Unable to delete: " + textStatus);
	});		
}


function removeFileWithoutView(fileid) {
	$('.wid-75-margin').val("");
	document.getElementById('filename' + fileid).value = "";
	document.getElementById('displayFile' + fileid).innerHTML = "<label class='div-inline'><span "
			+ "class='btn btn-primary'>Choose File<input type='file' style='display: none;'"
			+ " id='"+fileid+"' name='file'></span></label> <input type='text' "
			+ "class='form-control div-inline wid-75-margin' readonly='readonly'>";

	document.getElementById('divFaIcon' + fileid).innerHTML = "<a class='btn btn-info' id='faUpload"+fileid+"' "
	+ "onclick='uploadDoc("+fileid+",2);'>Upload</a>";
	
	onFileUploadFunc();
}

function enableViewFlag() {
	$('#hstnumViewFileFlag').val(1);
}



function onFileUploadFunc() {
	$(document).on('change', ':file',
		function() {
			var input = $(this), 
				numFiles = input.get(0).files ? input.get(0).files.length : 1, 
				label = input.val().replace(/\\/g, '/').replace(/.*\//, '');

			input.trigger('fileselect', [ numFiles, label ]);

			var f = $(this).get(0).files[0];
			readSingleFile(f, $(this).attr('id'));
		});

	$(':file').on('fileselect',
		function(event, numFiles, label) {
	
			var input = $(this).parents('.file-group').find(':text'), 
				log = numFiles > 1 ? numFiles + ' files selected' : label;
					
			if (input.length) {
				input.val(log);
			} else {
				if (log)
					bootbox.alert(log);
			}
		});
}