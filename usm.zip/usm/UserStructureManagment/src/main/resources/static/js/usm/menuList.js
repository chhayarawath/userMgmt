var viewMethodName = null;
var reportTitle = 'Menu List';
var displayColumnsInReports = [1, 2, 3, 4, 5, 6];

$(document).ready(function() {

    console.log("Document is ready. Initializing...");

    // Test alert
    alert("hello");

    // Load list initially
    getList();

    $("#gnumModuleId").change(function() {
        console.log("Module ID changed to: " + $(this).find('option:selected').text());
        getList();
    });

    $("#gnumIsvalid").change(function() {
        console.log("Isvalid changed to: " + $(this).find('option:selected').text());
        getList();
    });

    $("#add").click(function(event) {
        console.log("Add button clicked.");
        $("#strModuleName").val($("select#gnumModuleId").find('option:selected').text());
        callAdd('#MenuListForm', 'addMenu');
    });

    $("#delete").click(function(event) {
        console.log("Delete button clicked.");
        callDelete('#MenuListForm', 'deleteMenu');
    });

    $("#modify").click(function(event) {
        console.log("Modify button clicked.");
        $("#strModuleName").val($("select#gnumModuleId").find('option:selected').text());
        callModify('#MenuListForm', 'editMenu');
    });

    loadList("GET", "menulist", filters, headerArea);
});

function getList() {
    console.log("Fetching list...");
	alert("hello getList")

    var filters = {
        gnumIsvalid: $('select#gnumIsvalid').find('option:selected').val(),
        gnumModuleId: $('select#gnumModuleId').find('option:selected').val()
    };
    var headerArea = 'Module Name: ' 
        + $("select#gnumModuleId").find('option:selected').text()
        + ' , Status: '
        + $("select#gnumIsvalid").find('option:selected').text();

    console.log("Filters: ", filters);
    console.log("Header Area: ", headerArea);

    loadList("GET", "getMenuList", filters, headerArea);
    loadList("POST", "getList", filters, headerArea);
}

function hello(){
	alert("print hello")
}
