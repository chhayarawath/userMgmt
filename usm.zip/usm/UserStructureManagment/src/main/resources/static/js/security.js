function checkURL(vURL) {
    var flg = true;
    $.ajax({
        url: vURL,
        async: false,
        success: function() {

            flg = true;
        },
        error: function(jqXHR, status, er) {


            // only set the error on 404
            if (jqXHR.status === 404) {
                flg = false;
            } else if (jqXHR.status === 500) {
                flg = false;
            }
        }
    });
    return flg;
}


var token_key = "fhttf";
var csrf_token_key = "x-auth-token";
var form_data_token_key = "form-data-token";
var user_activity = "user-activity";

var createFHash = function(frmId) {


    var datastring = $("#" + frmId).serializeArray();
    //console.log(datastring);

    document.getElementsByName(token_key)[0].value = getHexaCode(datastring);

    console.log(token_key + "  :: " + document.getElementsByName(token_key)[0].value);




    // alert("hi");

    // document.forms[0].xyz.value = "changed xyz value";

    // alert("xyz hidden field value changed from 'for hidden test xyz' to 'changed
    // xyz value' ");

};


var getHexaCode = function(datastring) {

    datastring.sort(function(a, b) {
        var a1 = a.name.toLowerCase(),
            b1 = b.name.toLowerCase();
        if (a1 == b1) return 0;
        return a1 > b1 ? 1 : -1;
    });


    //console.log(datastring);

    var myInput = "";

    $.each(datastring, function(index, val) {

        if (val.name != token_key) {

            //	 console.log( index + ": " + val.name +" -> "+val.value);

            var newVal = val.value;
            //newVal = newVal.replace(/\+/g, " "); // replacing + with blanks
            newVal = newVal.replace(/\%26/g, "&"); // replacing & with blanks
            newVal = newVal.replace(/ /gi, "_");
            newVal = newVal.replace(/\%2C/g, ","); // replacing + with blanks
            newVal = unescape(newVal);
            newVal = newVal.replace(/\n|\r\n|\r/g, '_');

            if (newVal == 'undefined')
                newVal = '';
            myInput = myInput + "" + newVal;

            //console.log( index + ": " + val.name +" -> "+newVal);

        }


    });


    console.log("str :: " + myInput);

    // alert("srt :: "+myInput);

    return hex_md5(myInput.replace(/\%7C/gi, "|"));

};



var submitForm = function() {
    document.forms[0].submit();
};


var getQueryParameters = function(str) {

    str = str.split('?')[1];

    var outputArray = new Array();

    var strVals = str.split("&");

    for (var i = 0; i < strVals.length; i++) {

        var newVals = strVals[i].split("=");

        var obj = {
            name: "" + newVals[0],
            value: "" + newVals[1]
        };

        outputArray[i] = obj;

    }

    return outputArray;

};


var getJsonParameters = function(obj) {

    var outputArray = new Array();

    var i = 0;
    for (var prop in obj) {
        var myobj = {
            name: "" + prop,
            value: "" + obj[prop]
        };
        outputArray[i] = myobj;
        i = i + 1;

    }

    return outputArray;

}


var getFormDataParams = function(obj) {

    var outputArray = new Array();
    var fileI = 0;
    var i = 0;
    for (var key of obj.keys()) {

        var myobj = null;

        //  alert("key >> "+key +" >> "+obj.get(key));

        if (!key.includes("file")) {
            //  alert("key >> "+key +" >> "+obj.get(key));

            myobj = {
                name: "" + key,
                value: "" + obj.get(key)
            };

            outputArray[i] = myobj;
            i = i + 1;

        }


    }




    return outputArray;

}



function readSingleFile(f, id) {
    //Retrieve the first (and only!) File from the FileList object

    //	alert("inside read single file ");

    if (f) {
        var r = new FileReader();
        r.onload = function(e) {
            var contents = e.target.result;
            //  var base64Contents=Base64.encode(contents);

            contents = contents.split(',')[1];

            var encodedFileContent = hex_md5(contents);

            $("#f_codes" + id).remove();

            $("<input type='hidden' name='f_codes' class='f_codes' id='f_codes" + id + "' value='" + encodedFileContent + "' />").insertAfter("#fhttf");

            //	  alert("file_codes created for id :: "+id+"  >> "+encodedFileContent);

        }
        r.readAsDataURL(f);

    } else {
        alert("Failed to load file");
    }
}



var createFHashAjaxQuery = function(str) {

    var mystr = "";

   // if (checkURL('/IMCS/hislogin/initChangePassword')) {

        var qstring = getQueryParameters(str);
        console.log(qstring);
        var hcode = getHexaCode(qstring);
        mystr = str + "&" + token_key + "=" + hcode;

    //} else {

    //    mystr = "/DVDMS/hissso/jsp/error/sso_error_login_appnotavail.jsp?a=0";

  //  }

    // alert("inside testQuery");

    return mystr;
};

var createSecureAjaxInput = function(obj) {



}

var getToken = function(selTabVal) {
    // strUrl is whatever URL you need to call
    var strUrl = "/DVDMS/drugFinder/getToken",
        strReturn = "";



    // console.log("inside getCurrentDate");

    $.ajax({
        url: strUrl,
        type: "POST",
        dataType: "text",
        data: {
            selTab: selTabVal
        },
        success: function(html) {
            strReturn = html;

            // console.log("success >> "+strReturn);

        },
        error: function(err) {

            console.log("Token generation error");

        },
        async: false
    });

    return strReturn;
}


function getFormData($form) {
    var unindexed_array = $form.serializeArray();
    var indexed_array = {};

    $.map(unindexed_array, function(n, i) {
        indexed_array[n['name']] = n['value'];
    });

    return Base64.encode(JSON.stringify(indexed_array));
}


$(document).ready(function() {
	
	function resetIdleTime() {
		sessionStorage.setItem("test_session", 1);
	}
	
	$(document).click(resetIdleTime);
    $(document).keypress(resetIdleTime);

    $('<input>').attr({
        type: 'hidden',
        id: form_data_token_key,
        name: form_data_token_key,
        value: getFormData($("form")),
    }).appendTo('form');

    $('<input>').attr({
        type: 'hidden',
        id: token_key,
        name: token_key
    }).appendTo('form');


    $('<input>').attr({
        type: 'hidden',
        id: user_activity,
        name: user_activity,
        value: $(".panel-heading").html().replace(/<\/?[^>]+(>|$)/g, "").replace('&gt;&gt;', '').split('&nbsp;')[0].trim(),
    }).appendTo('form');




    //var frameData=window.frameElement.src;
    // alert("above frame element ");

    if (window.frameElement == null) {
        if (window.parent == null) {
            document.getElementsByTagName("body")[0].innerHTML = "<center>Unauthorized Activity</center>";
            return false;
        }
    }

    var selectedTab;
    if (window.frameElement) {
        selectedTab = window.frameElement.id.split("_")[0].split(" ").join("_");
    } else {
        selectedTab = 'new_window';
    }

    var secSelTab = hex_md5(selectedTab);


    $('<input>').attr({
        type: 'hidden',
        id: csrf_token_key,
        name: csrf_token_key,
        value: getToken(secSelTab)
    }).appendTo('form');

    // $('#'+csrf_token_key).val(getToken());


    (function() {



        // alert("inisde original submit ");

        var originalSubmit = document.forms[0].submit;

        document.forms[0].submit = function() {




            // alert("intercepted submit");
            // Do some stuff with the form elements
            // console.log( jQuery(document.forms[0]).serializeArray() );

/*
            if (checkURL('/IMCS/hislogin/initChangePassword')) {*/

                $("input.notForSubmit").attr("disabled", true);

                createFHash($("form").attr("id"));



          /*  } else {

                document.forms[0].action = "/DVDMS/hissso/jsp/error/sso_error_login_appnotavail.jsp";

            }*/

            $("div#ajaxSpinner").removeClass('hide').addClass('show');

            // Call the original submit() function to actually submit the form
            // Per Aria's suggestion below keeping the "this" binding consistent
            originalSubmit.apply(document.forms[0]);

            return false;
        };

    })();

});