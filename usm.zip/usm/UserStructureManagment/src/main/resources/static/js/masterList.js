var headerArea;

$(document)
		.ready(
				function() {

				var forms = document.getElementsByTagName('form');
				for (var i = 0; i < forms.length; i++) {
					forms[i].setAttribute('autocomplete', 'off');
				}

					var checkCount = 0;

					$("#exampleModal").hide();

					$("#modify").hide();
					$("#delete").hide();
					$("#view").hide();
					$("#addUnit").hide();
					$("#addDistributor").hide();
					$("#proforma").hide();
					$("#1102").hide();
					$("#renew").hide();
					$("#tender").show();
					$("#runJob").hide();
					$("#jobLog").hide();
					$("#verify").hide();
					$("#freeze").hide();
					$("#recieve").hide();
					$("#approval").hide();
					$("#print1").hide();
					
					$(".reportShow").hide();

					$("#view")
							.click(
									function(event) {

										var checkCount = $('input.checkbox:checked').length;

										if (checkCount == 1) {

											$("#user-activity").val($("#user-activity").val().replace('List' ,'View'));
											
											if (viewMethodName != null
													&& viewMethodName.length > 0) {

												openViewModelAjax(viewMethodName);

											} else {

												openViewModel($(
														"#tableListing input[name=id]:checked")
														.closest('tr'));

											}

										} else {

											alert("Only One Record Should be Selected");
											return;
										}

									});

					$("#filter").click(function(event) {
						if ($('#filter-panel').hasClass('collapse')) {
							$('#filter-panel-text').collapse('show');
							$('#filter-panel').collapse('hide');
						}

						if ($('#filter-panel-text').hasClass('collapse')) {
							$('#filter-panel-text').collapse('hide');
							$('#filter-panel').collapse('show');
						}
					});
					
					$("#filterReport").click(function(event) {
						if ($('#filter-panel').hasClass('collapse')) {
							$('#filter-panel').collapse('hide');
						}
						
						$('#filter-panel').collapse('show');
							

						
					});
					

					$('select').on('change', function() {
						resetButton();
					});

					setTimeout(function() {
						$('#status_message').fadeOut();
					}, 8000);

					
					/* for file upload */
					$(document)
							.on(
									'change',
									':file',
									function() {

										var input = $(this), numFiles = input
												.get(0).files ? input.get(0).files.length
												: 1, label = input.val()
												.replace(/\\/g, '/').replace(
														/.*\//, '');

										input.trigger('fileselect', [ numFiles,
												label ]);

										var f = $(this).get(0).files[0];

										readSingleFile(f, $(this).attr('id'));
									});

					$(':file')
							.on(
									'fileselect',
									function(event, numFiles, label) {

										var input = $(this).parents(
												'.file-group').find(':text'), log = numFiles > 1 ? numFiles
												+ ' files selected'
												: label;

										if (input.length) {

											input.val(log);
										} else {

											if (log)
												bootbox.alert(log);
										}

									});

				});

				function callModify(formId, strName) {
				    // Count the number of checked checkboxes
				    var checkCount = $('input.checkbox:checked').length;

				    if (checkCount === 1) {
				        // Update the user activity indicator
				        $("#user-activity").val($("#user-activity").val().replace('List', 'Modify Page'));
				        
				        // Set the form action to the specified URL
				        $(formId).attr('action', strName);
				        
				        // Submit the form
				        document.getElementById(formId.substring(1)).submit();
				    } else {
				        // Show alert if more than one record is selected
				        alert("Only One Record Should be Selected");
				    }
				}













function callAdd(formId, strName) {
	alert("sdgsahgd")

	$("#user-activity").val($("#user-activity").val().replace('List' ,'Add Page'));
	
	$(formId).attr('action', strName);

	document.getElementById(formId.substring(1, formId.length)).submit();
}

function callDelete(formId, strName) {
	var checkCount = $('input.checkbox:checked').length;
 
	if (checkCount > 0) {
		alert("hello cnf")
		bootbox.confirm({
		    title: "Delete Record(s)?",
		    message: "Do you want to delete the selected record(s).",
		    buttons: {
		        cancel: {
		            label: '<i class="fa fa-times"></i> Cancel'
		        },
		        confirm: {
		            label: '<i class="fa fa-check"></i> Confirm'
		        }
		    },
		    callback: function (result) {
		        if (result) {
		        	 
		        	$("#user-activity").val($("#user-activity").val().replace('List' ,'Delete'));
		        	 		        	
					$(formId).attr('action', strName);
					//document.getElementById(formId.substring(1,formId.length)).submit();
				    $(formId).submit();
				}
		    }
		});

	} else {

		alert("Atleast One Record Should be Selected");
		return;

	}
}

var afterReportLoad = function() {
}

var listAreaDataReport = function(data) {
	$('#filter-panel').collapse('hide');	
	$(".reportShow").show();
	$("#listArea").html(data);
	afterReportLoad();
}

/*var listAreaData = function(data) {

	$("#listArea").html(data);
	$('#tableListing').DataTable({
        
       layout: {
		   "paging": true,
        "destroy": true,
        "searching": true,
        "pageLength": 10,
        dom: 'Bfrtip',
        topStart: {
            buttons: ['excel', 'pdf', 'print']
        }
    }
      
        	
    });*/
  /*  new DataTable('#tableListing', {
    layout: {
        topStart: {
            buttons: ['copy', 'excel', 'pdf', 'colvis']
        }
    }
    	
	});*/	
		
    
    
    
    var listAreaData = function(data) {
	
    $("#listArea").html(data);

    new DataTable('#tableListing', {
		
        destroy: true,
        searching: true,
        pageLength: 10,
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'excel',
                text: 'Excel',
                title: document.querySelector('.panel-heading b').textContent,
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'pdf',
                text: 'PDF',
                title: document.querySelector('.panel-heading b').textContent, 
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'print',
                text: 'Print',
                title: document.querySelector('.panel-heading b').textContent, 
                exportOptions: {
                    columns: ':visible'
                }
            }
        ],
        paging: true
    });


    
   

	$('#tableListing > tbody > tr').click(function() {
		if ($(this).hasClass('no-click')) {
			return false;
		}
		if ($(this).hasClass('selectedRow')) {

			$(this).removeClass('selectedRow');

			selectCheckBox($(this), false);

		} else {
			$(this).addClass('selectedRow');

			selectCheckBox($(this), true);

		}

	});

	let debounce;
$(document).ready(function() {
    $('#checkAll').click(function(event) {
        clearTimeout(debounce);
        debounce = setTimeout(() => {
            if (this.checked) {
                $('.checkbox').each(function() {
                    $(this).prop('checked', true);
                    selectTr($(this), true);
                });
            } else {
                $('.checkbox').each(function() {
                    $(this).prop('checked', false);
                    selectTr($(this), false);
                });
            }
        }, 250); // Adjust the delay as needed
    });
});

	

	/*$('.checkbox').change(function() {
	//removed due to this function calling twice on change checkbox
		//buttonEnable();

	});*/

	$.fn.dataTable.moment('DD-MMM-YYYY');
	
	$('#tableListing').DataTable(
				{
					
						"paging" : true,
						"destroy" : true,
						"searching" : true,
						"searchHighlight" : true,
						"aaSorting" : [],
						
						responsive : true,
						dom : 'Bfrtip',
						layout: {
        topStart: {
            buttons: [
                {
                    extend: 'csv',
                    split: ['pdf', 'excel']
                }
            ]
        }
    },
						
						
						buttons : [ {
							extend : 'collection',
							text : '<i class="fa fa-clipboard"></i>',
							buttons : [
									{
										extend : 'excel',
										text : '<span>Excel </span><i class="fa fa-file-excel-o"></i>',
										title : reportTitle,

										exportOptions : {
											columns : displayColumnsInReports,
											stripNewlines : false
											
										},
									},
									{
										extend : 'csv',
										text : '<span>CSV </span><i class="fa fa-file-text-o"></i>',
										title : reportTitle,

										exportOptions : {
											columns : displayColumnsInReports,
											stripNewlines : false
										},
									},
									{
										extend : 'pdfHtml5',
										text : '<span>PDF </span><i class="fa fa-file-pdf-o"></i>',
										title : reportTitle,
										exportOptions : {
											columns : displayColumnsInReports,
											stripNewlines : false
										},

										customize : function(doc) {

											//var logo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWoAAABgCAYAAAA0NDgxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAE/cSURBVHja7J15XNTV+sffs7FvgwKCyDK4oLmPa64llJotWmDWzTIT2u/tZkJZZpYFWdebraBmmZlBVrYnmLa7gPuagoQCojAg2wCznN8f3u/8hnFmQEWzms/rxUtn5vs937M85/me8zzPeT4yIYTABRdccMGFyxbKy6ESVVVVCCEoKysjPz+fU6dO8c4776BQKAgICMDHxwdvb2/kcjkBAQEUFRUxfPhwBg8eTGNjI8OGDSM0NNQ1mi644MJfErI/ckVtNptJS0vjjTfeAGDw4MH4+/tTVlbGddddh1wux8PDg2PHjuHu7k7Xrl3ZsWMHAwcOZOXKlYwcOZJjx46Rm5vLDz/8QHBwsGtEXXDBBZeibk9UVlYSHR1Neno6AwcOxMvLC4PBwMGDBxk2bBhff/014eHhlJWVERAQAEBsbCxlZWWcOHGCwMBAevXqxcCBA1m+fDmJiYmuEXXBBRdciro90dzczODBg3nhhRcoLCxkz549mM1mvLy8KC4uxtPTk5EjRxIQEIDBYMBsNrNv3z42bNjA448/jl6v58CBA8hkMjZs2MB3332Hj4+Pa1RdcMGFvxT+UBu1m5sbGo2GkpIShg0bhlKpJDc3l8mTJ9O5c2diY2Nxd3dvcU9TUxM33XQTZWVlbNmyBbPZzJgxY1ixYgWHDh1Cq9W6RtUFF1z4S0F+MQo1GAx88cUXjBs3jquuuorXXnsNewv3iooKCgoK2LFjBx4eHkRERPDOO+9QWlrKq6++SmJiIp9++qnl+pMnTzJ37lw2bNhAWVkZEyZMYMeOHURERODn54evr6/DOhUWFpKbm8vWrVtpampyjbwLLrjw9zR91NXV8fTTT7Nj6yZ27NrPvfFNjOgjmP8e9BpxB//85z8JCgoiIiICgHvuuYeoqCiMRiM7duxgwYIFfPPNN+Tn5+Pj44Onpydr167lxx9/pEuXLsycORONRoPZbKa5uZk+ffpgNptpaGhgzpw5zJ49m3nz5iGX///7p7a2lieffJLs77KQdRQ0VzcToYhi0YsvcfXVV7skwAUXXPj7rKgbGxu57dYEDm76D1P7FrL5RSMv3A2TRkHKzT5s37SKzKevYsLVWmY/ch/vrFjO5198yV133cVDDz3EgAEDKCkpobi4mKeeeoq3336bLl26cPr0aQ4fPsypU6fQ6/XExMQwffp0brzxRpqbmwkJCWH48OGsXr2a9PR09uzZY6mTTqfjH//4Bx8dW03su2FckRHFwKxu1Iw5xaRJk8jOznZJgAttQlVVFfHx8chkMmQyGenp6Rf1eZmZmcTHx5Oammr5Lj09HZlMRn5+vmtAXIr6/LB48WLKDn7Dl2lKkq8+TYxaYK4DauCmQU30796BuP7eTBxg4uiW5Rz+PInTp+swmwVVVVVMmDCBMWPGMGXKFDIyMrjvvvvIzs4mODiYa665hi5dujB8+HDy8vJYunQpa9euJSoqinHjxpGbm8vEiRMZM2YMixYtIj09neumTeDKKUP5fv9GejwcjcJbjrHBgMloJqxHCN3vimT2E4+i0+lcUnCBSE1NJSYmxqLEYmJiSE9Pp7Cw8LJ8GVZVVZGammqpr0wmIz4+nszMTIf3xMfHk5CQgBCCuLi4sxR1YGBgi/IuRJnn5uaSnJxMbm6uS7hcaD9FvWzZMrZ99RKhQX68vtaTwzp3TjR48uWBTjQb5ahUJuL7CiZdUc5D45uJjenC7zofevWM5a2Mt1i5ciVvvfUWXl5ejBs3Dl9fX9atW8eAAQMoKytj/vz5vPXWW6xduxYhBIcOHaJLly7ExcWh0+lYv349H374IYUFhXyQ9QGZx5bQ+OQpwu5T0/ve7shDBKZGMwDCYMZrnIqQOwMoOVbKf/7zH06dOuWShPNAYWEhMTExZGdnk5SUhBACIQR5eXnk5+cTExNDVVXVRXl2dnb2ea0ss7OziYmJIT8/n4KCAkud4+LiSE5OthviKT0rISEBgJycnLNe8Dqdjry8PACLQk9JSTmvtklybYuUlBSEEC6H+d8Q5x31YTabWbVqFXnfrcRYvoE37lKgclfw3McevJWmYvJQE+P6mthR5ItMNFFY4YZZpiIitJ4hEVXEqlVM6ncLze6RfLL2QzZs2IC3tzdTp05Fr9fz4IMPcvDgQYYOHUpaWhoymYzBgwfTvXt3+vbtS0FBAc888wxZWVlUVFQwYMAAenbvCQkNdB7ZiZOLa/EJ88JkMqPc44a8mwyFjxzDARNH3i5DoVLRZ043so6t4oO41XRRR3DTTTcxa9YsvL29XZLRBsTHxwOQl5eHWq22fK9Wq8nKyiI5OfmiKer09HQyMjLO+cWSnJyMRqMhJyfnLCWoVqtJTk4mOTm5RdmFhYVtKl+j0bT41wUX/vAV9apVq8hdfidjQr7j+dvldOpkooN/M4vvqyO+n5wTOhX7ipspPKVic6EX+4/LmLXMlxuf88JNaST/mIKV739EVGQkCxYsYNq0aWzcuJEPP/yQ+vp6AgICqK6uJiAggLfffpslS5bw6KOPIpfL6dy5Mz169ODnn3+msbGRJ554gl69ehEZE4nhiKAh34h6sjeKvmYOv1tE7RY97sFuiBNQuaKB8m2V+I5yJyTJn6i5wXR5NYCayWUs/HQ+jzzyiEsq2mjuKCwsJCkpqYWStkZaWtpFU9Lns5pOTU2lqqrK4Uo3KSkJjUZDZmZmC+V8sV42Lrhw0RX1T9/n0MFXztJd15D4Zlc+2RJA9o4IHnlTzYrvTPj5eXGqTsbEIdUUn2ymW8dalj5YTfI4Gd/s8cLHXWAyGYmN7c62bdvIyclh1qxZhIaGUl1dzc8//4xMJmP48OHs3r0bd3d3KioqqK2tZc+ePdTW1jJ+/HgGDBhAWFgYAEH+wbh1cEPVSU5Vdj3VXzYSMqYDPuPcOfhQMYVPlePWW04HrT/qsd40FRkQJoFbiPKMcg9Ss//EHoxGo0syWoFkz5XMAfagVqvPUorZ2dkMGjTIYsdNTEy0KMLExMQWNl7Jvm1tT05PT7c42KRy2qpIJZtvXFycU7ODVM+qqqoWtmbJDn0uijs7O5vExEQSExNbtF3ajVgjOTn5rLbbvmgCAwNbvKQyMzNb2MeTk5NdwulS1GdQXFzMycJfmTBQQbTbDl6eVkZc91riY8pJmVLHpIGwcVc90cGCYxUe3D3WwHs/KPh6sxdj+jfSJ7yJ0T1NGAzNzH7032zYsAEvLy/MZjPffPMNjY2N3HjjjSxcuBCz2cybb77JvHnzOH36NLGxsURERHDy5El2797N4MGD0Wg0GI1GKqpPcfqXehRNSsL/1QH1JG+CxwXSfNiIe0cVne8NpGJ/FSd/rqJ4QSXH5uk4/bmeqjV6vAI9MJvMePp7uqSiFeTn51NVVYVarba7zbdVuJJyy8zMJDk52WJrzcrKIjc316K0srKyyMrKsvxfegmkpaVZ7klJSbGs1PPy8hBCOFzRO6qzs+ul36RrrW3NOp2uzc+zVr6SjbuwsJC8vDwyMjLIzc1t4byMj4+nsLDQ8gxbR2JycjLp6ektXhL5+fkkJyeTlpaGEIK0tDQyMzNd0Ux/QZyzjfr3339n1vQbeHrCUXqHu2Gino6+zZRVyYkKEnipjNx7jYrZK43U6N0pLPXglc8hYZiBXw6rWLPZl7tHNbPkW1/MTVXcOeMexl01ivfee4/o6GjeffddfvvtNyIiInj22Wfp1asXa9eupbS0lMzMTI4fP06XLl04dOgQ27ZtY+PGjfj4+PBR1kds3LyRqPHhGL0MFP7nFKIOqg/XYm420+ulKHTra/F298brei+6PNIRQ40BwwFBww4jBrkRnzAvKsNLeeSRR3jllVdaxGO70HZkZWVRVVVFTEwMWq3WYg9OT08nISHBooATEhIoLCwkNTWV9PR0UlJSSEhIQKvVkpuba7lOUpp/Ruh0OgIDA9FqtRaFL63aJaWbnZ1Nbm5uC1t/WlpaC4WbkZGBRqNpEa4n3S+VJ/3bVpu6C3/hFfXCBfN4I2E33p5uTF/WiZ8K/Ej7xJsrn/Zg1jsdeOFjH34rU9BoVHCyuokeoXXIMeHlLuc//67hlqGChZ+6cXVsHTt+O82e3TsA6NmzJx999BGPPfYYM2fOxGQyMXfuXMLCwjh27BghISFMnjyZhQsXMmfOHD788EMWL15MSkoKmzdvZtU7qyhuLuLkzkqOvFxCwFU+aJ4LocuMEBpKGjm88Dh+aj8CBvvQUNiIyl+Bwk+Oz1XuBD7gjr64Gd+eXoTcruZrxScseHaBSzocQKvVolarqaqqcmgrlhSO9G9hYSGFhYVnKVxJuViXk5CQQGZmpuW75ORkpyaWc62zM0UmKb+L6RC0XrVLJhm1Wt0imqMtL6a4uDjLid/U1FS75hQX/qaKeuuvG6nSq8jZ482UQae4vt9pNh/Q01/jzk0Da7n/hjrqDG6M6+fO3t8VvLTOnYHdPAntoOT2pwOI7WzgugFG3N0V9OliJi3tRRYtWsT69et5/fXXSU5OJigoCK1Wy8SJExk1ahT19fWsWbMGtVrNddddx9atW5k7dy6vv/46Hh4eNDQ0UPB7AUHhHVDJlXRLCUOUyCh5tYrS9yoYuLQ7mlmdkakFxdknOH2oliOPnaDqnUYOzyql4ttagscFcHprPcULK4i4I4Q1X612SUcrSkJaDbYFklKyte9KCtFaMUkOyuTkZIvJoj0Up1RnZ/HJktK80BfDueBCnJWJiYkWBW0byeLC31hR3zr9fm58OYDS0x506RzOuuPX4R85mkFd5Zys88FLKRgcUceWg028epeJ6gYIDlBw81DB/fG1vPCpN9/udmPtZjm/nxIEBQehUqmYMGECU6ZMwdvbmzlz5vDjjz9y7NgxYmNj6devH48++igRERHk5+ezY8cOtm3bRkxMDJMnT+amG29i5NiRBCZ402Rs5Pg7Feg21uIercRNrcSrgyfFH5ZxZNkx/CJ8CR4XiIdWgV7XSHOliZMfVCMXSnw6e6H0UrD/yaNEdoh2SYcTpKWloVarSU9Pb5Oy1mq1aDSas5SktGq2XU3GxcWRn59vOWjSHpBMD44OtkjRHlKo3qXcoVRVVbXox7ZEtaSmplpMJhcrwsaFP6miTk1NZVbyfWR9V0rGz90pPVlHhw4d+K1pKEUVclZv9MPTQ4HBrOCO15UkjTPh425m4Vo53+2V80xCHXOnCB66TsGofgHs3b2TrVu30rNnTxYuXMjChQtRKpW8//773H///UycOJF77rmHWbNmMWPGDObOncv69evx9/dn/vz5TJ48mZNlJ8kv3Iah3oRfdx/M9YLo+cH4DvKk9mg9xz+soPl3E13+EUyHG73pcKU/wWPUiGoZ7iZ3+vboR8OhJswGQcnP5QT8HsySxUtc0uEEGo2GjIwM1Go1iYmJltA3CfZO5aWkpFBYWNhii56enk5cXBxJSUktrrX+bPubtLouLCy0mEgyMzORyWROTxdqtVqysrIsLwBrE0h6ejrJyckkJSWdFakiXdfayle6zp5pxfpe292FtINITU21KGjphZaenm45hGN7n/Sv9DxrRX+xj7i7cIkhzgMmk0ksXrxYDIztID55Mkjcc9MV4uEEjZh7W5j48ulA8cStavHuv3zFurl+4olbg8Ti5BDxU5qXuFbrKZ6c1lGk3eUr1j3uLbakewqZTCbkcrn46quvxObNm8UzzzwjtFqtcHd3F0qlUgACEAqFQgBCJpMJlUolJk+eLNLT00VBQYEYMXSk6HJVqBj90mAxNlcr+s/oJUYtHiQiR4aL7ndFCZVKJfo9HCuu2TxMhI/sJIbPHSi6T44WA/7VU/S6q5vQDI0S/e+6QgQO9xPDhg8TxcXFwoW2QafTiZSUFKHRaCxjBYi4uDiRlpZ21vUZGRktrk1KSnJYtkajsfu7TqcTWq1WACIjI8NSrvVnZygoKBBJSUln1df2Xp1O1+IaQGi1WrtlqtXqs65NS0tr8VmtVousrKwW3yUkJAghhMjLy7O0SaPRiLy8PAGIlJQUodPpREJCQov7srKyREFBgaUv4+LiRF5enlCr1UKr1YqCggKXcP6FcEHZ89JeeI7Q0gV4+QVxoERBwUkDD8fVseRrOTnbG/jhBU/WbvUhd0cDk4fKGd5Lj69cwcPvKokKltM9FB5ZWoWfnx9du3YFYNq0aSQmJloiPU6cOMEvv/zCkCFDGDJkCEeOHCEyMpIhQ4aQmZlJWVkZmzZtws3HjSHP9KHJX8++R4sI0PgRkxLG6UO1GIvAo4uSw68fo7GmiSsei0HlpcR4TOAX6YNwE5RsL+OuK5KYM3sObm5urje4Cy64cNngghR1XV0do0ePxM94hHceEJxq8uT+Nw3sPNLA2L7ulOpkvPcQmIUKFHre+7EjV3Zr4seDcN81MqY8pwf/KJYvfYOrr74ag8GASqVi+/btNDY2snXrVu6//37uuusuZDIZK1as4KOPPqJPnz5UVFQwevRozGYz3bt3R2aS0dyvHncvd9y93VDFyOGUnOO/nMC3ozenD9fhN9ALQ6UR/S4DHa8PIOKhjpxcU03ptpMMCxrBJ++tc0mECy64cNlBMX/+/Pnne7ObmxvjxsXx1Tc5eJqOc+8bBibeci/hHsW8+A8DO4vduXFgE898rKJn52ZuH97Ik2sUeHuqUCnM7K6IYOxVV1NQcISDBw8yY8YMtmzZwqZNmzhy5AirVq1Cp9Oxf/9+zGYzP//8M1lZWXz77bc8++yzDBs2jPHjx1NeXs7A/lp27NxF74UaTv2g41TuacJu7EjIZH8Klx+nvljPFY/EsH/ZEeY++hS+On/2nNiFMlJOtwN9yXg10ynxgAsuuODCH4ULPtHRtWtXFr+xiq2me0id/x+mTZtGYWkDJoOZvl3MPLpSxbX9DGzc509lrRw/twYenVDPR1vcGX31RN584zULOYBWq8XLy4s5c+Zw3XXX4ePjQ11dHUePHuX3339HJpOxc+dOYmJiGDx4MI2Njfj7+9Pc3Ez3nt3pFBBC9dZa6osakctlmJsEpcuqCLpaTfTN4VR8d5rwAWEs/3ApUVFRmFa50+WLWNasWUNoaKhLGlxwwYXLEu3CmdinTx+WLl0KwD0z7ybIq5Z7l3qQ/a86/vWeJ5P66zlRBw+u8EChUqCU1+Hh4cbatR8ye/ZsvvrqK+6++27y8vJ47rnnuOaaa5gxYwafffYZsbGx7N+/n71797JkyRJCQkLYv38/GRkZrFixgtzcXF577TXCwsJwk7nx1rrX6PFgFDseP8DRlcfplRFJ3VY9R/5bBkZBxJjOFO37nZKSEvbs2oNKpXJJgQsuuPDXXlFbo6ioiJzcDdwxVsk916n44Fd33BRmJr/sSZBPMwlXKpk/xcCaX30JvuJmHnnkX3h6elJUVMQNN9zA2LFjiYiI4OqrryYqKgq5XM5dd93Fnj17+Oc//8mDDz7IyJEj8fPz4x//+AdXX301/fr1Y/PmzSxYsAA3LzdkZij5+iRd7+1CY20zNb82UPzmKbrOCcPvCi8OZB8mwC2A91e/z9GjR10S4IILLvw9VtQARqORe+65h6uii3ljvT8PTTiT2+PusUa8fVS88rWKr/NqGBCtoEdoM7/+/APvv3uI2tpali1bxoQJE1i3bh1ffvklHh4exMfH8+STTzJ69GimTp3KhAkT+Omnn7jvvvu4//77iYqKwsvLi59++olevXpRXV3NxEkTyP4gi+2fb6dXxxi8OnpwfFUFMf/uTNmPpzi9p56ec6PZt6CQptNNLnYXF1xw4e+1ojYajRw6dIiresuZm2Ci2WziHyNNTFtspKZaj4JGArwFU4arePcnTxTyMzkcpkyZQnl5ObGxsfj6+rJixQpiYmK4//77ufbaa3nwwQdZs2YNM2bMIDg4mOeff56cnBwOHDiAv78/Tz/9NMHBwYwcOZJZs2Zx4MgBQsd1ROgh6u5Qyn+poHpzHeI0dJ0bjklvImxwMF5RHqxdu9YlAS644MLfR1Hv3r2byspK/vUO6Oo9+XaXitW/uJE+XUZBhZyRPcwcKRN09DHi6yXo0qUL/v7+bN68mXnz5qFWq+nZsycrVqzgs88+Y+nSpYSGhhIZGcnnn39Ohw4duO222xg6dCjTpk1jzJgxLFmyhB49evDCCy+wbNkybr311jM5fRUyvDp7cOClImIfjqb6QA1yDxmNB5opWVNB1yfDEAbB8ePHL0kn5+fnnxeH3vned7nCOq+0PcqrPwLp6ekMGjTIaR9LHIuBgYF/W0VhTxbb0neXCyR2H0djeDnK5kVR1EePHkXTUU/yRF8++knPzYMFOTv1XDfQRGwYzMoADzc524vk/HZMD0Lwxhtv4Obmxp133sn69ev55JNPWLx4MUOHDsXLy4vvv/+e559/nrlz53LHHXewdu1asrOzefbZZ/Hz82PWrFkkJyfz8MMP89hjj7HqvVXsLtqJChXlP1bSMTqQwFE+VB+opfGAkcNLjhHzSGdKP6ik08SONNOE2Wx22i7rJPcxMTGt9oM1yat1Ssq/GtLT0+0S2jqCRMsl5U2WUntKsJfDWjoSnZ2dfdZv7dG3mZmZLY5tO0JiYmK7KCNrYoD4+Pg2J2OylkFHf5c6B3Vb+6412Bvb/Px8hznN7d3TlrFxRl7cmmxeFmivI47ffvut8PVELEn2F6tTOoppY3xF4ihPMaa3t6h410uMH9JBLLyrk5gRHygGD7hCXDfpevHee++J+++/X3z55Zdi3Lhxwt/fX2zfvl1s2rRJBAUFieeff17U1taKlStXivj4eHHjjTeKDz74QCxcuFAsWLBArF27Vjz++OOiU6dO4tlnnxW3TbtdzLzvbjFy1QAxcM4VYtBjfUSPu6JE9PXhYuwXg4VCoRA9bteIkUu0otcT0SIiKkLo9fpW25aTk9PiWLAjSEeG1Wq10Ol0f8hRU2f1aw8UFBQIrVYrtFqtyMrKOutouFarPavtOp3Ocny6tbKxOlZti7i4OKFWq9u1PdLY2vab7eeEhIQLenZCQoLQaDSWo92OjtifT9/ExcW12rcXA4767nzSEEhH4fPy8s6aT/aO7UvH+9uSMsCZ/LRVNv9otOuK2sNNzsofFOw55kbOzmYW3SFn3m1KnvnEm7JKPR5KI/uOmThw5HcqTp3ku+++IzMzkzlz5rB582buuecewsPDeeyxx/Dz8+PBBx/koYce4rXXXuOjjz5i8ODBHD9+nObmZgYMGEB5eTlr167loYceYsGCBeTkrqd/9wHodxjxjfZB6aZAf9hA+N1BFC47TmDPAEo3laP7qZZD6cXcdutteHh4tNo2KfObWq12mvQnMzPTkgXuj0h0L7GoXEwkJiZSWFhITk5Oi6x2SUlJ5OTknJV0Sdo2t2X1KPWZo5SmF6NP7ZV5MfoxNzcXjUbTggD3XNKbOmu7lOzqUqO9xkOtVlsSb1n3SUpKClqtlsLCwrP6Kjc3F61We1bCrnOtb1tl8y9j+ujfvz8B/n7MiPNgfX4dSoUgboGZ7UcgqkMzV0T7sq3QRK8wI71jgmnQN5Kfn8/SpUvx9fVl+fLlHD9+nJdeeomioiLGjBnDZ599xurVq6msrOSRRx6he/fuVFRUkJ2dzdtvv83YsWO599578fLyYtasWQwYMIBdu3bx+8cleAyRUbb1JBX7dFR/3sCpjVX0fiYGz44elP18ErlczvTp089ZmAoLC+1uM9PT0y0K/Y+CNf/gxTJ35OfnOyS01Wg0JCQkWLLZWSu+PxMuRj9qNBqLUkhPTyc3N/eclIyzMYmLi3NI2PtngfTStzU5JCQknJUCVrquPdLf/llks90U9dChQ7kx8R4OFZ5idKxg8nB3+nRu5pUvmtE3mTlaWs+DE5oYP9CNyMhoYntewcSJE/n444/p27cve/fuJSsri+LiYr788ku++OIL5s+fT3Z2NrfddhsjR47k5ZdfJjY2lmeeeYaEhARWrFjBrl27ePzxx9m7dy/h4Z3Z/NNm3LorOflRNW4dVISNC6J0XQUhwzty+pc6ZN5yuj8agZubG0rluUUnSnmK7dnEMjMzHU4WW6eLRD8VGBhoWYHKZDIGDRp0VupNW2dNdna2hcxUorCSbHC5ubkWQlapLOvnxMTEtLAry2SyFs4Va1uoPQGWJpF17mh7uw+pnlKZknNGsju2tz01PT29ha3cNq+zdbtasw3b60dbp5Sj8WpNEVVVVREYGGjJIS056M7F1mqrZGxtxM7aKzlFZTJZi3bExMSQn59vSf/aVlm0hTXJ7rnIlfQi02q1Z8mGvRSu0mdbRW1d/7Y4BZ3JprVz0TZ9bnp6OvHx8RaiZeuxO9c6XHIbtRBCLFmyREQGy0W3zp4itKO7WDvHW0wc7CX6xngLH0+FmDLCXzx8U5CIDHEXCoVCKJVKcdNNN4mJEyeKZ599VvTr109s375dzJ8/X3h7e4uPP/5YrFmzRnTq1EmkpqaKDRs2iG7duonOnTuLxx57TDzxxBMiPDxcLFu2TIwcOVIMGzxMeIS5ib53x4rowRHi6pxBImRwB6EOCxB+ob6ii7az6D83Vvj28hLPPPPMOdnQJDuZlG7S2qaVlZUl4uLi7NoypfSb1ra8uLg4iy07JSXFYoNUq9WWtJ727pPSaebk5Fg+W6cBtX22lDZTrVaLtLQ0kZGRYbGfS/Y6a3tyXl6e0Gg0Du3rUipPazuiLaQ0ntZ2Rem71uyA9tKK2v7Z2hiTkpJa2Cml8ZHqaJ0qVbKpSn0utdm2j+3Zo6XvHI2XM+Tl5Vn6W6PRnFV/tVrttE+d9Y2t/dZZeyW5wyq9rNQOrVZ7zrJo23fnK1e2NmlrOZH8HtZlWs83axt+XFyc5Rop5au1Td/euNqTzbS0NKFWq1v4EwCh0+lapKlNSEiwpKdNSUlpUx3+cBs1wO23347cO5LQgGamjfJga7EnPcMVdPA2sfRBf77d3sBP+/R0Cwvg1ml3MnnyZO666y5LaN7vv//OLbfcQkBAAEFBQWzfvp01a9bw4osvcuLECR588EG8vLyYOHEiJSUlfP/995hMJt577z2EEFxz1bVoZ/RBHgENukbqcg0o3VVo7g6npqyWyt906AsM1P2mZ/jw4efVRmnVbJuk3dE2VrLdWsPavisxc0g2cGkFYe8+aetsvT3MyMhwWNe8vDzLc5KSkkhKSkKn06FWq0lLS7Nsw613BY7MGpcSEuO47Z+9FZTEbG4b/SD1UVVVlWWVHxcX16KPzweOxsuZ3yIxMZGMjAyL6cy6z6uqqkhLS3O6S7FdmUv9UVBQcJapzVl7c3JyLHJq3Q7JDmz9nWSqcSSLjsyDFyJXtuaP3Nxc4uLiLLsRaVUrfW8Nie1GWtUPGjTorLlyrnZzqW+tSYMTEhLIy8tr0XcSw0571+GimD6krc+6desoa9bgoWimvglW/WBg33EZB441c8tIH67s6UbeYR3fbdzA3r17WLBgAXl5eSxatAh/f38mT57Mrl27KCkpITs7m+uvv55nn32WI0eO8Oabb1JTU0NdXR0PPPCAhY5r2LBh7N61m7dXL6dR2UhtXgN+Pb0pX19J9wcjKMwuJmRwEKGDQzj80VHGx4+nX79+59VGrVZLQkIC2dnZ5OfnWxSDM3tZWxWfRL7q6D6tVotWqz2v+FV7ZUkkstZhT87sppICcBaSJZXVVsVzIcjPz0etVttV6tILVafTkZSURGpqqmXitKczzVl52dnZJCcnk5aWhkajaWE6kyawtSPtfOzetv3cWnvtyWJb5LOtMnw+cuXI/GGtqG0VuL2Xdlpa2llycD6nj1NSUigoKLCMn6NQUNs+ac86XFRFDWcSND322GNk/6zn/Zwq9I1Glt2voqFZQd4RA1OHNXPzCG/iYk/TJbonU6dOJTo6mhtvvBFvb2+am5st5KKTJk1iz549NDY28ttvv5GZmcmQIUP44osvUCqVLFiwAHd39zM2oudeJOKaMJrMzfj4eVN7qp5ju0qpzq/DK8Cb0Gs6cGxHCdGR0Xz22WcEBwdfsOMjPT2d9PT0S+rIycvLIyUlxWJvtLWhnqtASisVySnlbELaYwy3pzytr73YsOdosme/BsjKyrqkuwVpBSj1hVqttvS5FJvtbEd0Lju8y6G95ytX9mz5mZmZFoWs0WiIi4sjNzeXzMzMFtEzti/G9oBkv5eedS58lBcrnl1+MQpNTExk4OipeLgJBnb1YOsRBXqDDJVSwfOfqvjHqGbG9zNTVlrKe6tWs2/fPnbu3Mn+/fs5ceIE48ePZ8uWLXzwwQd07dqV/v37k56ejsFgIDU1lalTpzJ79my+/vprjh49yquvvsqLi9M59P1hDLvNNNQ2ImuQ0WO6hkMZRWAQ6PcZaa4yMGPGjHN2ItoTJus3/6VkrJa2rQUFBWRkZJwVYXE+u4PMzEy7zhl7E1Cj0ZCdnW13yy9FxFivgi4mpMmanJx8VpSJ1KbU1FSysrIsq9pLCemlZd1XUsiZve37hYbY/dHtPV+5crQIst4tSN+npqbaXQRIphpbZ/H5HFSSon5ycnLOaRHWnnW4JIra39+fVatWMWxgVyYNMLDokwYq6j1oNsI9VzUydkADNw6qx1Sxk+Ijv1FWVsa3365HoVAQGRnJunXrKCgoIC0tDXd3d3744QcqKiqYPHkyc+fO5ZtvvqGoqIiqqioWLFhAQEAARb8XEX5LCLXH6zA1mfCO9sBQYsK3txcECoo3HUetVpOcnHxeb1jbLaQ0gLZCaEs86mgC2tsyV1VVOb0vPz+/xaBbx+Ra/2ttI2xtqy/ZTauqqto0oXJyclCr1cTHx7dYPWRmZhIfH28hkLWngFqriy1Za2t9FhcXR1xcHFVVVS3s1DExMZaVmXV5tp57R89qaz/ajpejHYg18a9UB4nMVtpW29p1HbXd2fPOpb1tkc/WrnH2YjlXubI1fxQWFrZQyAkJCRZTk73ypPlobSO2jTJx1gZH5MPWNmZp9+ZoDNpSh/PGxTxN89xT/xSje7uLYLW7GNzdQ6x/zkuIz2VCfIRo+gCROMJTvPVQJ/HZF1+L8vJy8fHHH4uIiAihVqvF4MGDxd133y2CgoLE66+/LqKjo8XYsWNFnz59REREhJg3b544efKkxXMe262niJkZLq7ZPlR0n6wRbt5uolPfEDE0va+IvqOz8PT0FBs3bjznNkiRE9jxelt7nm1JS/mft92W4DQlJeWsMq1PPmIVpWF7X15enkhKSrJENkjXWXvXpcgCa7JU6VpHkQVarfacT5elpKS0IHR1VIZtW/mf99zeyT3b6yRPvKO+tY6csK6HtQdf8thrtVpLn0gn0Wz72Jpo1lE/OhovZycSra+T6q3T6VrUOy4uziEhrb0+dDReztprW05WVtZZpLy2bcMOSa89ubYX2XA+cmUddWGvbbbRHrYRHNZttI7IsW2nvXHFTmRHSkqK5bN0AtR6PG3b7awOfxi5bWtobm7myUfvIlZ8TGWjD4/dVgmVZ9bxlTUKPtgSwFV9FahvPkhYyBkb1vr161m+fDmrV6/mkUce4fXXX+fWW2/l8OHDREVFERwcjEqlYvHixZbn/Prrr/z6/WZe/OJ5+r8XQ1OpgWPPVVCxpxr/Xj7o6xsZGTKGjz/+GBfOXjnFxMRQUFDwh0d7uOCSKxcuoelDgpubG036OuKvaCbM3wC10jIevNxlqFQKdh81U1xcYrln1KhRPPDAAygUCry9vTGbzaxevZojR44wevRo/vvf/3Lq1KkWz+nQoQNRXSJRa30xmUyoQhSE3dcBubsMc7OgeZ+JmTNnukbbgbPtXJw9LrjgkqtLD+XFfoDRaMJkFpyq+d9m4H+K2tPNiJDJ+GVPHU39DjFscG/LPd7e3gDs37+fNWvWEB0dzd69ezl58iQAXbp0QQhh8W7v3r0bs1lg9DeAAJPejFuYAt8obzre7MuADoO47rrrXKNtNYkk26harbbEhbrggkuu/oYragClVzC6OhnHK8X/K2oANxlGo5my0x7U1Z22fH306FE2bNgAnDniOXXqVIYMGcLdd9+Nh4cHSqWS66+/nubmZgCampooLCygpqaGZn2TZHdH5gUymQxTswkPXzfXSFtB8qZrNBoyMjL+0PwkLrjkyoXLYEXt3yGM41VyaprcMJtkyGX/U9gKgY+qiS1HlXQ/9v/chcXFxezduxcAHx+fFmUZDAYAamtrLavp0tJSFAol1bXVeHX0tLwMhAA3Hzfk3nKam42ukbZCXFwcF9E14YJLrlz4s62oo6JjKK5UUnHahL5JDjLJJgJaTTNlFafZu3eP5XqTyURxcTEAp0+fxmj8fyVbV1cHQEFBgSXh/5YtW+jSuQvHq4/h2VOF2XDmRSBTynDvpEIIQW1djWukXXDBBZeidoTY2Fhe+waOnWpCJZf9/w9GiA01ERWkIi9/hyXW0Nvbm+rqagBOnTpFY2Oj5ZYTJ05QWlpKaWmp5dDKZ599ho+vL8UFxcgbFMjksjMvg0aQ1chQqpTIhdw10i644IJLUTvCFVdcQVWzP94qAypPKzu1HKrrFdQ3Q3nZGeULEB4ebjkfX1hYSH19vaWs8vJyPvvsM/R6PUqlkpKSEvLz84kKj6LW4zQeke4IgwAZmI1mzHIzwiAID+7iGmkXXHDBpagdwd/fn/79+3NldxMylamloq5TMnz0NURFR1lsW2FhYZajmPn5+TQ0NFjKCg8P5/nnn6exsZHy8nKOHj2Ku7s7ukodB48cwMPP7Uw5AoRR4N7FjfpSPf379neNtAsuuOBS1I5gNpvR6/XcMEgB1jyycjkfbTYjU3rhpvp/n6aXlxf9+vVj9uzZ+Pn5ERQUZPmtd+/eHDt2DIVCwYEDBwgODiYgIIC3lr3JibxT6PcYkbvLkcllmGrEmVjsCj+uv/76S96xfzUGcRecozWW6/aSKSkJvy1BwuXebinFwJ9xPlwOc/miK+r9+/fjVr8HbQ8zNP3vS3f4vUTBvA+bqK7S0djYaIniABg2bBj79u1j8uTJLSI/evbsiZubGyqVij179hATE3OGN/GTtfTvPYCTX+pQuP3PYWmU0SxrZkTnMRcUJmSPDdn6Lzk5+bKYMH9mSIwZtizjreW/uJzgjOXa0eS3la3ExESHmQmljG5ZWVmW037Wz7Nli7Flp7HHZN4eOSja0u7c3FySk5PPOy9zenq6JXdGYGCghcrs7zTvLrqi3rt3L9EB1ag8zf8Ly4PT9R78UqhGoVQyZtQIlEqlJYpDEkqlUknPnj1blKXVahkxYgSenp6YTCYUCgXDhw8nIiKCjIwMTm9tQF/ShEx5Rul7e3pyorzsguovTQw4O6F9Wloaubm5JCYmnpXsSavVtsiLfCmU3aVWru2l4FJTUy39Jf2p1WoLhdifAQUFBW1O7SrlE7fOpS3lLHaUZ9w6vadGoyEvL69FMn+p/6S8z3l5eS0OnFhfL+VMbo9Tg47abZ3oPy4u7rwPv0iHaKQ6S74rWwLli4lLPZf/EEWt1+uJCv1ffLMMcIMf9nnx48lBdA6P5KbJN+Hj44NcfqYqJpOJoKAgQkNDCQ0NbVGWj48PQ4cOpVu3bnTpcsZBePvttxMZGUlMDw1Bhk7UZDchd5chk4Gnvye7VfkXzLDgSKBTUlLIy8tDq9Vacu/+EbgU7OMX43mJiYnk5uaSk5NzVs7flJQUMjIy/lTEuG1RfJmZmaSmplraZ31vVlaWJem/bf86ywFurw72dpEX6zi3vXIlcoQLRWZmJgkJCS2IBzIyMv70ZL6XnaJWqRScrPfgUJEPqMBkUPD2d0YKdT74+njSt29fRo8eTWlpKZs2beLnn3/G09OTESNGtAjNAzAajXh6eiKXyzl69CilpaX079+fkJAQ5HI5YdFhyPLcaSwwIA+WYXBrRn21D0uXL72ok1MSmkupLG0V3qVUaO3xvOzsbEuuYkcr0aSkpL/c6bb09PQWMmPv5W9vx/JnemHl5ua226JFIvC13VldKmKKv42irq6qwt9Lwfq9nmz/PQi9XkleoZn9u7YxbNhQy6q7qKiI0tJS9uzZw9atW/Hz8+P3339vUVZTUxOlpaUcPHgQo9HIZ599hre3NzKZDJVKhYenOz06x9JY0IwyQIGx2oSbcONw5aEW0SPtDYmForCw0LJ6b415XGIElyagMyZt298HDRpkWWE5Y822tu3ZOkOc1ccZk3Vrz3PWBtuVUlsmnO1K2xnLszU7tHXbbZVGW8uwZZh2xkzdVgVWWFho4Vu0B8m0IclSdnY2MpnMEgVljxn9QtEac/a5tDs3N9dilpDucybLrSl0Ka+1rUnIHjmFI/lzJOuObPaS7Ev97Ij6ztGclF4w1j6I+Pj4CzPjXYw81EajUdTU1Ii6ujoxZswY8dIMb/Hmw53FV093EEdedxdBHQJETEyM+PDDD8Vrr70m5syZI15//XVxzz33iLvvvluMGTNGXHPNNWL58uUtyt24caOIjIwUTz31lFi9erX4z3/+I/Lz88XQoUNFZWWlmDJlirj15mliwGM9xYQTw8TQRf3EoAf6ib639RT79u077/ZIDNDWOZAd5QHOyMiwy9rsjBG8NSbtpKSkFuzGGo2mBZu1PXblpKQkodVqLTmOpfzBUn5cZ/Vpjbnb0fOcteFcGM1tcx3zv9zJzlierfMoS3mDrXNVS/3grAxnDNPOmKmd9Yu9drXGSi2NjXVeba1WexbjuKM84bTC5G6dI7o15uzzabc9ZnfpO2dj4wjWebs1Go3dHNfO5M+ZrEv9ZZsjvTUG9tbmZFxcnEW2dTqd0Gq1ZzHQnwvaXVEXFxeLpNuuFsMHasTN1/YTMplMhHVwE13D/UXxUi/x78kBQqXyFdOnTxfjx48Xt912m0hJSRGZmZnixRdfFPv27ROJiYkiKipKfPTRRy3KTk5OFpMnTxZ33HGHmD17tpg0aZJYv369mDlzphg6dKi4+uqrxZQbpoj+U3uLcfsHiTEbBoruUzQirG8nMXLUSPHoo4+KJ559XHy38buLqqitFZz14EoCbS0UkgA7mlBSOTk5OZZ7rAXN3kQpKChoURdHytNefSQlan2vbYJ0RxOzNaVgT1Fbt8uewrJ+jj1yAawS99tTENJEk57T1jJsxzotLa3FRJOUrvWL5nJS1PbIGez1T2v9cT7tdqaonY2NM+Tl5VnmmKTwrV8urcmfI1nX6XRnyXtWVlaLOtnO5dbmpL2FBlaEBeeDdjd9vP766/jUbuKuYeX8Y2AhC+8MYeY18HpSI7p6M+u2CZ5/YT7du3end+/e1NbWEh0dTWVlJTExMaxbt45p06bRpUuXs5yAjY2N6PV6+vfvT2hoKHFxcSxatIjk5GQaGxuZNGkSTcYmGvNNVG48jUdXJZ0e8Cf0+kCK3I7wTcgnfK7MYmrKLbz//vvt2m5pWyPZVJ05bqx/a41JW9pOWdtqk5KS0Ol0Dp8h9Zs95nHr3x05g86VubstbOD2POmtOcls7dPnw/IstU1qQ1vLsO2TtjJTtxY90BbH4KVmcnfWH+3R7raOTWt9l5OTQ1ZWloVzUoq0Ohf5sx1XtVpNXFxcC7NGZmZmC5OcPbZxZ3NSohGzV5/zHdN2U9RGo5EXn38a+dE3KdL5caxSxhFdAEO66lnwQDPX9Jfx/uZQahsFRoMBo9FIhw4d6NixIxs3bqSiooJffvmFDRs2UFJSwqBBgyxJmCTMmDGD3NxclEol/fv3p0ePHvTo0YMff/yR7t27U1FRQVNzEwqlnLqPDZhOm1H4yFG5uSFqBF5BHrjrvAjsEcB/Mxdz5MiRdmm7RPYqsSWfj8OktZjQc4kZdcSv15aXiLXtDdrOZN2WNthzBp1rLGx7xM6eTxkXwkxt3WbJ/uzIXin9ptVqL5kj1Vl/tEe7L9T5ausPkiKtrBcc5yp/tmVKdmyJ8OBC+y0/P79dHcDtpqhPnjzJ2lWLCVG7E+QPp2rg9/JmOquN/LYL/rXczMa8Y1RU1vD666/xyy+/cOLECXr27ElsbCyenp4IIfDw8ODXX3/F3d2dgoIj7N27l4qKCiorKykvL8fHx5uioqO88sor5ObmEhQURFFRET179qS4uJguXbow+qrRuBV6s/+Fo5gMRk7l6wibEELZWzo6lUbQu2Nf9ANP88KSF9rFKy0J0/mEDLXGpC29gdPT01sIhsT47UwJ2q6cJeXgTBDPh8m6tTY4im7QarXk5+e3eZXWHizP51vG+TJT23OOOXue9P2lUoit9Ud7tftCIkjsKTzrlen5yJ+9YAApxLY1Mt7W5qRGo6Gqqor4+PgWu6fs7Ow2h1leNEUdFhaGOvQKKnWn+f20Gt/AcPLLNaw6OJ6nNlzHvvrR+HYZxTXXjm/BNKxWqwkICKC+vh4hBAMGDKC+vo7331/Orl07GTPmBrp2vYZu3a7lrrseob6+gTVrVnLy5EnKysrYunUr+/fv59dff+XgwYM0NDSQl59H55gwAveEol+oxPg7+B/qiJePFyVFx6n9rR6vEj9iojVtVsaOJpXk7U1LS2sR69lW5vHWmLStf7f2Ig8aNMiicG1Zs7VaLUlJSWRnZ7eIOsnMzGyhfB0xa1vX3x6Tte3zWmuDI0jb2PT09LNO5WVmZp7Vh62xPDtrj/Tv+ZRhW449ZmpHY27vBZWSkkJmZmaL6AppfDMzM8nIyDjrZdoa47mj8WtN/traH+fSbmv5kOSuLWPjqD22px8zMzPJzs621L0t8tda3yUlJVFVVWV3J2MvNNDZnJTCSm2jp6S5+YdGfaSlpYkxo4aLxx+9V6SlpYnU1FSxfPly8emnn4rZs2eLBQsWiKuuuko8//zz4v777xdr1qwRTzzxhFi+fLl44oknxNChQ8WkSZNEfHy86NChk/DwuFrAvwQ8KyBd+Pq+IJTKZ4Rc/ohQqSaIbt36ihkzZojFixeLN954Q0yfPl0sWrRIvPDCCyIpKUlkZmaK1atXi7feekssW7ZMPPnkkyItLU1Mnz5djBozUtxw8/ViypQpYu/evU7b5cjZgg07uLOoBVvmcXuM4M6YtG3rYe05t8eaba8etozlzurjjMna2fNaa4Mz2bF2FEne/ZSUlLOcP45Ynm2ZyhMSEs6KgJDa35YybB2ozpipHbFcO0NWVtZZbU5KSjrrvtYY2J05dK2dj87Y4J0xZ59vuyV5TUpKOqexsScbBQUFZ0V+2DrKnclfa3PPmQPe3lxuy5yUomloA8v8JWEhLy4uZuHChWRmZqJWqwkKCqJ/ZDM3D9Px1VZvvshr4pZbEujatSsymQyFQoGnpyfNzc14e3vj7u7O3NRHOF56CpMZoC9wE4GBftx3XyBXXBGMv783bm4KTp/Ws23bMVatOk1JSTUy2RcEBBQxdepU/P39qa2t5auDnzEifAynak+iFCoCfQI5ceIEx44dw9/fH5PJRH19vYWHsVu3bhbqLxdccMGFyxGK+fPnz7+QAj744AM2btxITU0N1dXVuFFLSkIHBnZpIL5fLSb8uHH6PHr37k1ERAQ9e/YkMjKSjh070q1bNwqP7CeUHWw/VI3BNAC4h5tvlvPaa2MZPDiG3r274eXljtFoIjKyE1ptFLfeGkVd3Ql27dLS2FiASqUjNTWVTp06sa35F9Sd1NT2qEA0ynjkzn+j0WiIjIzkiy++oLCwkIaGBhobGzl9+jRFRUWoVCqGDh1qOcbuggsuuPCXUtTz5s1Do9Ewfvx4hBB09S/lyl4enKxWEtWhDm9FAwcbBnHFFVdY7jGbzXh7e/P2228z1PAMn29pZH+xH3Af06fDokW3Ul/fQH29nqKiEjw83Dh1quoMo7nJjNFo4sYbB9HYeIi8vF4cP/4Z0dEhBHYI5GexiSJdIW49VDSc0qPtOITevXszZswYpkyZQmFhIXq9ntTUVHr06EFYWBiLFy9m6tSpLVKquuCCCy5cLrigJaTRaESv13Ps2DH69evHddddx5Vd9fjIq/FUGfjuYBiRQUp++HY1Qgi8vb3x8/PDz8+PpqYm3E99wSCNoLgSIJ6uXc2kpk6gpOQEJpOZmpp66ur0FBaWUFfXwMmTOo4fP0lDQyPl5RXMnj2Rvn1NwAQ2bdqEUqnEK8odj+NeKKoV1NRX89Dch1iwaD4HDhzA19cXpVKJEIKoqCi6dOlCv379GDp0KDt37nRJgwsuuPDXU9R1dXXI5XLc3d2pqqpi4MCBHDP1Y9E6EwPCqzCZ4eApNWGKfXz77bfU19dTXV1tSVXoZSqioUnO8Qo3hOjJrFlh1Nc3oNc3UVtbz+nTdTQ2NnLiRAW1tQ006ptoamqmudlARUU1DQ2N3H57Z6A7mzdv55nn59N00EjIvf4YThoxnhR0e7UTh8fuIndDLuXl5dTU1GAwGPD19cVgMBAYGEhkZCR+fn4uaXDBBRf+moq6trYWNzc3KisrCQ0N5Z/PriUqKoqAEAMxgVX8dsKdq/r58NEHy3nppUWsXPEmP/zwA0qlksK6GIp1bjQ0qvH0VHLFFRGo1WpMJjO1tXrq6vScOKHjv//9neeePcLBQ8eprq6jrq4JHx8vAHr0CCUkWEVVlTsnTpVi3q6kIc+Iu7sHEU90ROWm4tjyk1TpqjCZTDQ1NdHU1IRCocBkMuHm5kZ4eDjff/89W7dudUmECy64cNlBeb43CiF49dVX6dy5MwqFAr1eT3NzM2FhYfxW0sSxY3IG96jh2Gk/VEoZiyfvRpi3E9EJth7244f8IK7tfoJv8/XoG5WoVO54e3vS1NQMKFCp3PDz8+Gbb4o4fLgDIGPjxuM89FAEfn7eKBQKmpqaCQjwpL5BIJN5M37MKLbXbMM/ygePam/q5ToINtGxZwdya75iz9ZtnPQrtZg/lEqlJQrFy8uLX3/9lSFDhrikwgUXXPjrKOqDBw8SGRnJ8ePHEULQ1NTEunXr8JJVo/aRgUHGlEHHMTXKUbibzxAHyGBIjJ6VP9diCLyD5mA3PDxyACPl5TqUSjAYjHh4KGloMNKvnz95eZU0N5sZPbojTU1mjEYDej14eXlSX9+Il5eZpiaIjo5m3+GdNO02YfJtgFIFxtAm1EN88R6rQiY303VCKKX/qqW2tha5XI5CoUCpVHL06FFmzJjhkggXXHDhr2P6kMvlzJkzh0OHDqHX63Fzc+OLL75Ar9czcYDAJ9jEt3s7cLREhcLHDEJ+5mlGCPQzUqV3J/G2u5k1axYhIYLGRgOFheWEhXXE3V2OwWBECDnR0cHMmRPJ00/HEBvbGXd31Zk3jFKOQiHj0KEyTp5UERIiQ6vVUlfegDnUSHOtAYO5Gf12I3UH9cgUMkwNJhQyOT49PaiurkalUiGXyykvLycuLo7hw4e7JMIFF1z46yhqgBEjRqDRaCgrK8NsNhMbG8uxY8fYtLMW6uGdjUYmv6Jm2354eZ2SNz5XUNskB2+4b2QJ33//PeHh4Vx11TBgO9nZZej1TXTsqMbHx5OAAB/c3d3w9fUmMNAPf38/3N1Vlj8/Px9WriwDSomN7UyvXr24svtIKrdWY1YbkHeWceJjHcpeAn1JEzWfNyPK5OiPNlmOlNbU1HDo0KFL7kzMzMw8i2fxUkEiVrVOQH8xmJYdJVx34fLApWDXvljPSE1NdZHbnguKioooLi5GLpfTt29f5JU/0TlIxgPv9uLq217kxVffI23zZN7ffQWZW3tz7YudSVygwOjZGf/iBbz6wkNMnz6d6OjD7NghIy3ta7y9PVGrffH398bDw50ePSLw8fHC29uTLl1C8PBwIzIynOefX8vOnUpkshzuuWcmTU1N3H3bTDzMZxI8Kf3l9InuS/+tI+n8Zk98flNTubOKQzlH0Ol01NTUcPToUfLy8i5pDLUkZGlpaS1yAcTExLR6rzUzxfmmnIyPj7/oQi5xA7YlCY2Uoc2WDaM9U2pe6pdgW9nFXTg/JCUlWZh8/g5QXmgB4eHhbN68merqan788Uc867dTEjyTmXffjZeXF25ubixc+DynT5+2mBlycnL4pEDHwGhBt5pVbNvcjeXLX2H8+MdYteofwJfce+9V+Pv7ERUVTmNjEzKZDF9fH0wmI76+3syfv4aMDCXwHs88M5URI0bQ1NTEL9t+xmu6jN8ePkanpgDu6jWNKdffzJJ3XuFotz0M2DqCa/81haKiIgD27dvHlClTLknuX0mB5ebmWliZ8/LyLPRFhYWFpKenO8xSlp6ebklkVVBQcN5kpTqd7iw6J4lpuT0nkkajaRNbdHx8PBqNxpLPNzs7+yw6KPj/REDWya8uJ0j0XUlJSZa+lBIFDRo0iLS0tMuKlLW9x1zqA+s2XoxnwJnETzk5ORY298tVJi6bFfXs2bMxGAycOnWK8vJyzCYDYWILtbW1eHp6YjabUSgUeHt74+3tTa9evZg3bx533nkn3uGj2WecgP+xlzCZTKSmXge8wapVlUycmMeiRb+wefNuKit1GAwG9u8/ygcfbOb66z8hI6MJmexdFiyYRHJyMgaDASEEPzR8R9N2M6GdwpAhw9BgpKS0hAP984k+HkufyL6Eh4ezc+dOvv76ayorK1myZMkl6Wwp25ztZJUydqnVaqdpGa3Tnl4sRun2RFtZuQsLC0lLS7Ncn5CQQE5Ozln3txez9cXcQZwru/hfCe3FTn8u8pWWlva3WFVf8Iq6R48eTJkyha+//hoPDw/U3qHEDTCwbOlbjB5zNWazmZqaGhQKhWU1FxgYSF1dHWq1mh93ltHHX88PK1bQt29fQkJqKC9/nZoaLStXDmLlyhMEBppoblbQ2NiI0SgH9tChw14SEq5iwoQJ7Nu3D4VCwfufvcfRLr+x5+kjhF4VhLfejbLTZTz94jyOdP4N1SYfgq/qzJYtW9iyZQu+vr68/PLL+Pr6XrLJLCkie0KXkJBgyXFrj7hTUtIXRJJ5GU5uOJOr13pXo1arW3yWmK0vdeL6c1lJtsYuLuU7/quu/tqDnf5ckZCQYEn4fzntVi67FTXAiy++yJgxY9DpdHirI9h9qjMyuYpPP/3UYgvV6XRUVVVhNpuJiIigubkZnU5H4m2zGHhLJtdffz2enp68/PLLPPTQrdx3XzTXXruDbt2+wWj8ig4dvqd3763ce+8pHnwwlFmzJuPp6cmKFSvYuHEjGRkZ/LbzCP13X8mMqXcTUx+LZmtvqqqq6OgRxKDykfSM6UVJSQlRUVH885//ZMuWLdxyyy2XrLOzs7OdJu1PSUlBrVbbXSFkZmY6FcS2sJhL+Ybt2X7Ph2nZGVv5uZhIpDbbMjVLStkZs7U9+7Z1HZ2xirfGvi39Jt3vyK5/Puzi58JKb69fnfW9bdlSOwYNGtSif+2NeXZ2dgs5sf7tfNjpncmVdf5r69/bWn/rHaktScZfDu1JbFtdXS0OHjwovv/+e/HCCy9YcrF26NBBhIWFiYiICNG1a1dx5ZVXin79+omxY8eK22+/Xdx5553i9ttvF88//7xISUkRKSkp4q233hJr164Vb775pnjzzTfFsmXLREZGhli2bJlYtGiReOWVV8S///1vMWfOHPHGG2+IhQsXinvvvVc8+OCD4qWXXhK33HKLuP7668Vtt90mJk6cKPr06SP69u0rduzYIaqrq8WlhkSQay/vrsRSbJ3j1jq3rZS7+HwZwCWCUuvParXa8szzZVpuja3cHqGpI+JSjUbTIl+xbe5ee2UVFBS0yLNdUFBgyZ1dUFDglFW8LezbUp9LfeQov/b5kNY6Y8aWxsc2t7P1M5z1vZQHWa1WW76T+qo1dm21Wt2CtNU6N/W5stM7kyutVmsZY6n/pLLbUn/b/ndGKvxXABer4CVLlghAhIeHi/79+4vevXuLoUOHir59+4rBgweLMWPGiKuuukpcd9114tprrxWTJk0SU6dOFdOmTRM333yzuOWWW8Ttt98uFixYIF5++WXx1FNPiYcffljcdttt4qabbhIJCQkiKSlJJCYmiuuvv15MnjxZTJgwQYwaNUr069dP9OjRQ3Tt2lVoNBoRGxsr3N3dhZeXl6irq/tDOlpSNPYSnlsrauk660lvnQT9XBnAJZZlW2Wp0WhaJJY/V6bltrCVt1VRO0rSbl22vbKSkpJavDjs9Z8jVvHW2LcTEhLOSgbf3uzijpixbRnH7SW1P1emeGnMrV8+tmPuqK8u5Jm2z3CUoN92cdGW+jtjRv+rQXmxVurdu3cH4Pjx4wwePJh9+/YxYsQIdu3aRa9evTCbzRgMBoYOHcqRI0e48soraWxs5MCBA3h4eBAVFUVtbS0lJSX07t2bgoICevXqRV1dnYUYVwiBXq/H19eX77//nmHDhlFfX8+HH37IqVOnGD9+PFlZWfTu3ZuDBw9y7bXX4u7uflk72LRaLQkJCRZ+NWmr54jSSmJgdsTELdEg2Zpc7LEx25YrbdmtzRTW9lXpmampqQ657c4FEk2VxH2XnJyMVqt1GJGTm5trl2ldrVa3yrQu0ac5MifFxcWRnJxMbm6upd2O6nGh7OL2xsJ6iy/9bv3d+fS9Wq1ucZ29vpOo0XJzc0lISGjRP+f7TNsxc/Ts7OxscnNzHfazbf3/TrhomfKvvfZavvrqK2644QbKy8txd3dn27Zt1NXVceTIEbZt28b+/ftZuXIlGzZs4NVXXyUjI4Off/6ZnTt38u6777JmzRo+//xznn76ad5++21efvllli5dyhdffMGrr77KsmXL+Oijj8jIyGD9+vW88cYbvP322xw9epSKigo+/fRTGhsb2bFjB7feeivvvfceSqXyD+3wtjgCJaUsxYm25iRxxsDcFl661uzqrdnFoe1s5fbKt+2TjIwMS+SEM9ujIx5BZ7bitrYtKSmJrKwsEhISyMzMZNCgQQ4jGtqbXTwlJcUSqmnthLZWYO3R9/aQl5dHSkoKVVVVpKamtgjjbI9nOpJHqU/+DNFMf8qoD2eYMGECEyZMwGAwYDabMRqNlpU0nMlnbTQaMRgMNDU1YTAYMBgMNDc3W743m800NTUhhEAmk1lYWBQKheWzlGpVCIFCocDNzc1yPNzDw4OAgAACAgL+0I6WVnpt9WRLKwxphe0I1gzMVVVVlhWvpLylyZ2bm2tZVUuko84UhjXTskajsdShsLDQsnKU2MpbY21uSzSMbTSHM6er9TXSzsNaiRUWFrZaJ41GY3FSWisd6xdjQkICCQkJFhJTZxEbUvhdenp6i/A8ayVn7SBtrV1JSUmWkD8pDE1qkzVT/IX2vT2kpaWRlpZm2dVINHvt8UxpXKWdiu0Cpi3j7mi1fanOQvzpnYkuiFZtlPacIZIzzR6pqa19Ny4u7iy7pi1JqmRrla6RbKOSXTAtLa2FM8vR85yVKzmKpOsl+3VCQkILEtnWbNTSNUlJSZb66nQ6ERcXJzQaTYvvJPtpQUGByMjIsDiYrB1TKSkpLe6ztZHa2k5xQBxra6eNi4uzax+1hkTYam231el0FvurrV1WGkt7NldHdmJrJ52zvrdXtq0z2HZ88vLyWvSTtZ+iLc9MSUlp4RB1JAMSCa213Vqj0Zwle63V39bp7XImXgL88ssvYt++fRf1GXv37hWbN2/+w9ooRV/YczDZ845bC19rbNTOGMAlxSf9LkUdSJEQ58u07Iyt3LZMR462rKwsUVBQ0OLlIV1v62SzZra2fsk5Ynt2xireGvu2FH0kRaO0lUW6rezibWGBt/2zjlJx1ve2MmX7UpKcy7ZjnpeXJ5KSkiz9bOuEPld2emdyZf2b7XPaUn9bBd5Wh7VLUV8gli1bJm655Rbx5ZdfCrPZfFGesWnTJjFp0iTxzjvviIaGhj+knRqNpk2RBC78fWHvpWxP2blwpq/srbL/arhsaLdnzpxJdnY2ISEh7Nmz56I8Y8yYMXz++eeMHTuWzZs3/yHtTElJITU19W/rvXahdeTm5lJQUMD/FlKWv7y8PJezzY7t/698IrHdnYlfffUVn3/+OWazGblcjkwmw2QyWU4e2djFkcvlmM1mi5NQgkql4uTJkwQEBFjKkcoSQjBt2jTGjh2LTqfjmWeeoampCQCZTGYRaNtnSt9LjkilUkllZSXvv/8+cXFx3HrrrZesw5OSkqiqqrI4sVqLAHDh7wUpaZdWq23hbJOcw5frEfpLjcLCQpKTky2O1786ZEK0T2qr0tJSKioqeOCBB0hJSSEoKIiHH36Ya665hhtvvBGVSoXZbEYmk/Hdd98hk8no3r07M2fOZM2aNWzatIktW7Ywb948vvvuOz744AOWLl0KnMkZffDgQVavXs2nn35KaGgoTU1N7NmzB71ej6enJ25ubhiNRqZMmcITTzzB4MGDWbFiBTfccANffvklRUVFzJ49Gx8fH4QQlJeXc+utt7J+/XoGDx78h0zI/Px8uxECLvy9ISVvknZdUg6Rv8PKsa2QYuz/Dkq6XVfUAL/88gsmk4l+/foRHBxMx44dGTlyJCqVivfee8+iTHfs2EFKSgpxcXF06tSJsWPHUltbS2VlJcOHD6eyspK8vDy6du3KPffcQ48ePQgODqZbt26EhoZaVtC+vr4MGjTIEjstraaHDBnC2rVr2bNnD0uWLOHUqVN4enoyYsQI/vvf/1JSUmI5KNOjR48/pOP/LgLmwrlDCo9zwTH+bgucdrNR19XVcd999xEQEMCnn35KYmIiW7du5fTp09xxxx107tyZCRMm0K1bN4YMGUJ0dDSPP/441dXV7Nq1iwceeICsrCzi4+N54okn8PT0ZN++fXh7ezNv3jzc3d2pq6uzPE+hULBx40aqqqqIiYlBp9MxbNgwPDw8LOS1M2bM4MCBA7z66qv4+PiwcuVKsrKyuOaaaxg3bhwqlYrm5maX1Lvgggt/jxV19+7defHFFwkJCWH69OnMmDGDqVOnYjabGT9+PDNmzCAgIIBRo0bx/fffM2/ePI4fP27J9paYmEh5eTnz5s3j008/JScnh5EjR1JQUEBiYiJHjx6lZ8+eLRT1DTfcwMKFCzEajZSXlzNp0iTmz5+P0WjkmWeeYdmyZaSmplJdXY3ZbCY6OpqZM2cSHx9vOQ4rLkJScxdccMGFy3JFDfDYY4+dYVn55Rd8fHyIjIzEz8+PRx99lKysLPR6PXAm+uL9999n7dq1aDQahBC89NJLLF++nG7dutGnTx/UajVKpZKZM2eyfPly3n//fYvZQ0JYWBgPPfQQHTp0sLBqBAUFIZPJUCgUJCcns27dOp566ilMJhOjRo1CpVKxZ88e5HI5nTp1OsvR6YILLrhwuaHdnIkuuOCCCy78CVbULrjgggsutD/+bwCdWpApgy52CwAAAABJRU5ErkJggg==';
											var logo = '';
											doc.pageMargins = [ 10, 35, 10, 30 ];
											doc.defaultStyle.fontSize = 8;
											doc.styles.tableHeader.fontSize = 8;

											doc['header'] = (function(page,
													pages) {
												return {
													columns : [ {
														image : logo,
														width : 120,
														height : 30
													}

													],
													margin : 0
												}
											});
											doc['footer'] = (function(page,
													pages) {
												return {
													columns : [
															{
																alignment : 'left',
																text : [
																		'Created on: ',
																		{
																			text : getCurrentDate()
																		} ]
															},
															{
																alignment : 'right',
																text : [
																		'page ',
																		{
																			text : page
																					.toString()
																		},
																		' of ',
																		{
																			text : pages
																					.toString()
																		} ]
															} ],
													margin : 20
												}
											});
											doc.content[2].table.widths = Array(
													doc.content[2].table.body[0].length + 1)
													.join('*').split('');

										},

										messageTop : function() {
                                             //  alert("gjhhk");
											var searchVal = $(
												
													'#tableListing_filter')
													
													.find('*')
													.filter(
															':input:visible:first')
													.val();

											if (searchVal != null
													&& searchVal.length > 0) {
												headerArea = headerArea
														+ ' \r Search (contains) :   '
														+ searchVal;
											}
                                         //  alert("gjhhk");
											console.log("inside pdf :: "
													+ headerArea);

											return headerArea;
										}

									},
									{

										extend : 'print',
										text : '<span>HTML </span><i class="fa fa-print"></i>',
										exportOptions : {
											columns : displayColumnsInReports
										},
										message : '',
										title : '',
										customize : function(win) {

											var jsDate = getCurrentDate();

											var imageAddress = "http://"
													+ window.location.hostname
													+ ":"
													+ window.location.port
													+ "/DVDMS/hisglobal/images/report_header.png";
											var headerAreaHtml = '<center><img src="'
													+ imageAddress
													+ '" width="600px" height="100px"></img>  <br/><br/> <font size=\'4px\' >'
													+ reportTitle
													+ '</font></center><font size=\'4px\' > '
													+ headerArea
													+ '</font><div style=\'float:right\'><b>Created on : </b>'
													+ jsDate + '</div>';

											var searchVal = $(
													'#tableListing_filter')
													.find('*')
													.filter(
															':input:visible:first')
													.val();

											if (searchVal != null
													&& searchVal.length > 0) {
												headerAreaHtml = headerAreaHtml
														+ ' <br/> <b>  Search (contains) : </b> '
														+ searchVal
														+ '</font> ';
											}

											$(win.document.body).css(
													'font-size', '9pt')
													.prepend(headerAreaHtml);

											$(win.document.body).find('table')
													.addClass('compact').css(
															'font-size',
															'inherit');
										}

									}, ]
						} ]
					});

};

var loadList = function(getType, getUrl, filterData, localHeaderArea) {
	headerArea = localHeaderArea;
	if ($("#listArea").length == 0)
		return;
	$("#divFilterText").html(
			"<label class='currentColor'>" + headerArea + "</label>");

	ajaxFunction(getType, getUrl, filterData, "listAreaData");

}


var loadListReport = function(getType, getUrl, filterData, localHeaderArea) {
	headerArea = localHeaderArea;
	
	
	if ($("#listArea").length == 0)
		return;
	$("#divFilterText").html(
			"<label class='currentColor'>" + headerArea + "</label>");

	ajaxFunction(getType, getUrl, filterData, "listAreaDataReport");

}

var selectTr = function(obj, bool) {

	if (bool) {

		obj.closest("tr").addClass('selectedRow');

	} else {

		obj.closest("tr").removeClass('selectedRow');

	}

	buttonEnable();

};

var selectCheckBox = function(obj, bool) {

	obj.find('input:checkbox:first').each(function() {

		$(this).prop('checked', bool);

	});

	buttonEnable();

};
var resetButton = function() {
	$("#add").show();
	$("#modify").hide();
	$("#delete").hide();
	$("#view").hide();
	$("#proforma").hide();
	$("#1102").hide();
	$("#renew").hide();
	$("#tender").show();
	$("#runJob").hide();
	$("#jobLog").hide();
};

var buttonEnable = function() {
//	alert("in buttonenable");

	var checkCount = $('input.checkbox:checked').length;

	if (checkCount == 1) {

		$("#add").hide();
		$("#displayord").hide();
		$("#modify").show();
		$("#delete").show();
		$("#view").show();
		$("#addUnit").show();
		$("#addDistributor").show();
		$("#proforma").show();
		$("#1102").show();
		$("#renew").show();
		$("#tender").hide();
		$("#runJob").show();
		$("#jobLog").show();
		$("#verify").show();
		$("#freeze").show();
		$("#recieve").show();
		$("#approval").show();
		$("#print1").show();

	} else if (checkCount > 0) {
		$("#add").hide();
		$("#displayord").hide();
		$("#modify").hide();
		$("#delete").show();
		$("#view").hide();
		$("#proforma").hide();
		$("#1102").hide();
		$("#renew").hide();
		$("#tender").hide();
		$("#runJob").hide();
		$("#jobLog").hide();
		$("#verify").hide();
		$("#freeze").hide();
		$("#recieve").hide();
		$("#approval").hide();
		$("#print1").hide();
		

	} else {

		$('#checkAll').prop('checked', false);
		$("#add").show();
		$("#displayord").show();
		$("#modify").hide();
		$("#delete").hide();
		$("#view").hide();
		$("#proforma").hide();
		$("#1102").hide();
		$("#addUnit").hide();
		$("#addDistributor").hide();
		$("#renew").hide();
		$("#tender").show();
		$("#runJob").hide();
		$("#jobLog").hide();
		$("#verify").hide();
		$("#freeze").hide();
		$("#recieve").hide();
		$("#approval").hide();

	}

};

var openViewModel = function(row) {

	var viewContent = "<table id='viewTableListing' class='table-bordered' width='100%'>";

	$("#tableListing thead tr th").each(
			function(index) {

				if (index > 0) {

					viewContent = viewContent + "<tr><td width='50%'><b>"
							+ $(this).text() + "</b></td>";

					viewContent = viewContent + "<td width='50%'>"
							+ row.find('td').eq(index).text() + "</td></tr>";

				}

			});

	viewContent = viewContent + "</table>";

	$("#modelBody").html(viewContent);

	$("#exampleModal").modal();

};

var openViewModelAjax = function(methodNameVal) {

	data = {
		id : $('input[name=id]:checked').val()
	};

	ajaxFunction("GET", methodNameVal, data, "modelAjaxResult");

}

var modelAjaxResult = function(data) {
	$("#modelBody").html(data);
	$("#exampleModal").modal();

};

var getCurrentDate = function() {
	// strUrl is whatever URL you need to call
	var strUrl = "/DVDMS/drugFinder/getCurrentDate", strReturn = "";

	// console.log("inside getCurrentDate");

	jQuery.ajax({
		url : strUrl,
		success : function(html) {
			strReturn = html;

			// console.log("success >> "+strReturn);

		},
		error : function(err) {

			var now = new Date();
			var baseDate = now.toString().split("GMT")[0];
			var dateDtl = baseDate.split(" ");
			strReturn = dateDtl[2] + "-" + dateDtl[1] + "-" + dateDtl[3] + " "
					+ dateDtl[4];

			// console.log("error >> "+strReturn);

		},
		async : false
	});

	return strReturn;
}

/*
 * mode 1= save and view function on screen, mode 2= only reset functionality on
 * screen
 */
var filename;
function uploadDoc(fileId, mode) {
	
	var fillpass = fileId;
	filename = document.getElementById(fileId).value;

	regex = new RegExp("(.*?)\.(pdf|jpg|png|jpeg|PNG|JPG|JPEG|PDF)$");
	
	if ((regex.test(filename))) {
		formData = captureFileWithSecurityCode(filename,fileId);
		if(formData != 0)
			$.ajax({
				url : 'echofile',
				type : "POST",
				data : formData,
				enctype : 'multipart/form-data',
				processData : false,
				contentType : false
			})
			.done(
				function(data) {
					if(mode==1)	
						fileUploadSuccessWithView(data, fileId);
					else
						fileUploadSuccessWithoutView(data, fileId);
					})
			.fail(function(jqXHR, textStatus ) {
				 var msg = '';
			        if (jqXHR.status === 0) {
			            msg = 'Not connect.\n Verify Network.';
			        } else if (jqXHR.status == 404) {
			            msg = 'Requested page not found. [404]';
			        } else if (jqXHR.status == 500) {
			            msg = 'Internal Server Error [500].';
			        } else if (textStatus === 'parsererror') {
			            msg = 'Requested JSON parse failed.';
			        } else if (textStatus === 'timeout') {
			            msg = 'Time out error.';
			        } else if (textStatus === 'abort') {
			            msg = 'Ajax request aborted.';
			        } else {
			            msg = 'Uncaught Error.\n' + jqXHR.responseText;
			        }
							
					bootbox.alert('File upload failed ...'+msg+"  >> "+textStatus);
					var selectedTab = window.frameElement.id.split("_")[0].split(" ").join("_");  
					var secSelTab = hex_md5(selectedTab);
					$('#'+csrf_token_key).val(getToken(secSelTab));
				});		
	} else {
		bootbox.alert("This is not valid file. Ex-( docx|pdf|xml|jpg|png|gif|jpeg|txt|xlsx|PNG|JPG|JPEG|TXT) ");
		return false;
	}
}


function captureFileWithSecurityCode(filename,fileId) {
	var oFile = document.getElementById(fileId).files[0];
	if (oFile.size > 5242880) {// 5 mb for bytes.
		bootbox.alert("File size must be under 5 MB!");
		return 0;
	}

	var formData = new FormData();
	formData.append("file", document.getElementById(fileId).files[0]);
	formData.append(csrf_token_key , $('#'+csrf_token_key).val() );
	formData.append("f_codes"+fileId , $("#f_codes"+fileId).val() );
	 
	var qstring = getFormDataParams(formData);	 
	var hcode = getHexaCode(qstring);
	formData.append(token_key , hcode ); 
	formData.delete("f_codes"+fileId);
	$("#f_codes"+fileId).remove();
	return formData;
}

function fileUploadSuccessWithView(data,fileId) {
	if(data.includes("Error")) {
		document.getElementsByTagName("body")[0].innerHTML = data;
	}
	
	$('#hstnumViewFileFlag').val(0);
	var url = "download/pdf/" + data;
	
	document.getElementById('divFaIcon' + fileId).innerHTML = "<a class='btn btn-info' id='closeFile"
			+ fileId
			+ "'  onclick='removeFile(\""
			+ fileId
			+ "\");' >Reset</a> "
			+ "<a class='btn btn-warning'  href='download/pdf/"
			+ data
			+ "' id='openFile"
			+ fileId
			+ "' onclick='enableViewFlag();'>View</a>"
			+ "<button type='submit' id='btnSave' class='btn btn-primary lessMargin'>Save</button>";
	
	document.getElementById('displayFile' + fileId).innerHTML = "<a href='"
		+ url
		+ "'>"
		+ data
		+ "</a><input type='file' style='display: none;' id='"+fileId+"' name='file'>"
		
		document.getElementById('filename' + fileId).value = data;
	
	 var selectedTab = window.frameElement.id.split("_")[0].split(" ").join("_");  
	 var secSelTab = hex_md5(selectedTab);
		
	 $('#'+csrf_token_key).val(getToken(secSelTab)); 



	$("#btnSave")
			.click(
					function(event) {
					
						var fileName = document.getElementById('filename' + fileId).value;
						if (fileName.length > 0) {
							var viewFileFlag = $(
									'#hstnumViewFileFlag')
									.val();
						if (viewFileFlag == 0) {

								bootbox
										.alert('Kindly review your file before upload.');
								return false;
							} else {
								finalUploadDoc();
								return true;
							}
						}

					});
}


function fileUploadSuccessWithoutView(data,fileId) {
	if(data.includes("Error")){
		
		document.getElementsByTagName("body")[0].innerHTML = data;
		
	}
	var url = "download/pdf/" + data;
	
	document.getElementById('divFaIcon' + fileId).innerHTML = "<a class='btn btn-info' id='closeFile"
			+ fileId
			+ "'  onclick='removeFileWithoutView(\""
			+ fileId
			+ "\");' >Reset</a> ";		
	
	document.getElementById('displayFile' + fileId).innerHTML = "<a href='"
		+ url
		+ "'>"
		+ data
		+ "</a><input type='file' style='display: none;' id='"+fileId+"' name='file' >"
		
		document.getElementById('filename' + fileId).value = data;
	
	 var selectedTab = window.frameElement.id.split("_")[0].split(" ").join("_");  
	 var secSelTab = hex_md5(selectedTab);
		
	 $('#'+csrf_token_key).val(getToken(secSelTab)); 

}




function removeFile(fileid) {
	$('.wid-75-margin').val("");
	document.getElementById('filename' + fileid).value = "";

	document.getElementById('displayFile' + fileid).innerHTML = "<label class='div-inline'><span "
			+ "class='btn btn-primary'>Choose File<input type='file' style='display: none;'"
			+ " id='"+fileid+"' name='file'></span></label> <input type='text' "
			+ "class='form-control div-inline wid-75-margin' readonly='readonly'>";

	document.getElementById('divFaIcon' + fileid).innerHTML = "<a class='btn btn-info' id='faUpload"+fileid+"' "
	+ "onclick='uploadDoc("+fileid+",1);'>Upload</a>";

	onFileUploadFunc();
}


function removeFileWithoutView(fileid) {
	$('.wid-75-margin').val("");
	document.getElementById('filename' + fileid).value = "";
	document.getElementById('displayFile' + fileid).innerHTML = "<label class='div-inline'><span "
			+ "class='btn btn-primary'>Choose File<input type='file' style='display: none;'"
			+ " id='"+fileid+"' name='file'></span></label> <input type='text' "
			+ "class='form-control div-inline wid-75-margin' readonly='readonly'>";

	document.getElementById('divFaIcon' + fileid).innerHTML = "<a class='btn btn-info' id='faUpload"+fileid+"' "
	+ "onclick='uploadDoc("+fileid+",2);'>Upload</a>";
	
	
	onFileUploadFunc();
}

function enableViewFlag() {
	$('#hstnumViewFileFlag').val(1);
}



function onFileUploadFunc() {
	$(document)
	.on(
			'change',
			':file',
			function() {
				var input = $(this), numFiles = input
						.get(0).files ? input.get(0).files.length
						: 1, label = input.val()
						.replace(/\\/g, '/').replace(
								/.*\//, '');
						

				input.trigger('fileselect', [ numFiles,
						label ]);

				var f = $(this).get(0).files[0];
				
				readSingleFile(f, $(this).attr('id'));
			});

$(':file')
	.on(
			'fileselect',
			function(event, numFiles, label) {

				var input = $(this).parents(
						'.file-group').find(':text'), log = numFiles > 1 ? numFiles
						+ ' files selected'
						: label;
						
				if (input.length) {
					input.val(log);
				} else {

					if (log)
						bootbox.alert(log);
				}

			});
}
function checkBoxChange(){
        buttonEnable();
}
