package com.UserStructure.Bean;

import java.util.Date;

public class CountryBean {
	
	private static final long serialVersionUID = 1L;
	
	private Integer gnumCountrycode;
	private String gstrCountryname;
	private String gstrCountryshort;
	private Integer gnumSeatid;
	private Date gdtEntrydate;
	private Integer gnumIsvalid;
	private String gstrNationality;
	private Long gnumHl7Code;
	private Integer isModify = 0;
	private Integer gnumIsUt = 0;
	public Integer getGnumCountrycode() {
		return gnumCountrycode;
	}
	public void setGnumCountrycode(Integer gnumCountrycode) {
		this.gnumCountrycode = gnumCountrycode;
	}
	public String getGstrCountryname() {
		return gstrCountryname;
	}
	public void setGstrCountryname(String gstrCountryname) {
		this.gstrCountryname = gstrCountryname;
	}
	public String getGstrCountryshort() {
		return gstrCountryshort;
	}
	public void setGstrCountryshort(String gstrCountryshort) {
		this.gstrCountryshort = gstrCountryshort;
	}
	public Integer getGnumSeatid() {
		return gnumSeatid;
	}
	public void setGnumSeatid(Integer gnumSeatid) {
		this.gnumSeatid = gnumSeatid;
	}
	public Date getGdtEntrydate() {
		return gdtEntrydate;
	}
	public void setGdtEntrydate(Date gdtEntrydate) {
		this.gdtEntrydate = gdtEntrydate;
	}
	public Integer getGnumIsvalid() {
		return gnumIsvalid;
	}
	public void setGnumIsvalid(Integer gnumIsvalid) {
		this.gnumIsvalid = gnumIsvalid;
	}
	public String getGstrNationality() {
		return gstrNationality;
	}
	public void setGstrNationality(String gstrNationality) {
		this.gstrNationality = gstrNationality;
	}
	public Long getGnumHl7Code() {
		return gnumHl7Code;
	}
	public void setGnumHl7Code(Long gnumHl7Code) {
		this.gnumHl7Code = gnumHl7Code;
	}
	public Integer getIsModify() {
		return isModify;
	}
	public void setIsModify(Integer isModify) {
		this.isModify = isModify;
	}
	public Integer getGnumIsUt() {
		return gnumIsUt;
	}
	public void setGnumIsUt(Integer gnumIsUt) {
		this.gnumIsUt = gnumIsUt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "CountryBean [gnumCountrycode=" + gnumCountrycode + ", gstrCountryname=" + gstrCountryname
				+ ", gstrCountryshort=" + gstrCountryshort + ", gnumSeatid=" + gnumSeatid + ", gdtEntrydate="
				+ gdtEntrydate + ", gnumIsvalid=" + gnumIsvalid + ", gstrNationality=" + gstrNationality
				+ ", gnumHl7Code=" + gnumHl7Code + ", isModify=" + isModify + ", gnumIsUt=" + gnumIsUt + "]";
	}
	
	

}
