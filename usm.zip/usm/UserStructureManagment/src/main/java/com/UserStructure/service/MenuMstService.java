package com.UserStructure.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.UserStructure.Bean.MenuMstBean;
import com.UserStructure.entity.UmmtMenuMst;
import com.UserStructure.repository.MenuRepository;

@Service
public class MenuMstService {
	
	@Autowired
	public MenuRepository menu;
	
	 private   ModelMapper modelMapper = new ModelMapper();
	
	public List<MenuMstBean> getModule(Integer gnumIsValid) {

		List<UmmtMenuMst> list = menu.findAllByGnumIsvalid(gnumIsValid);

		List<MenuMstBean> beanList = new ArrayList<>(); 
		for(UmmtMenuMst mst : list) {
			MenuMstBean bean = new MenuMstBean();
			BeanUtils.copyProperties(mst, bean);
			beanList.add(bean);
		}
		
//		   for (UmmtMenuMst mst : list) {
//	            MenuMstBean bean = modelMapper.map(mst, MenuMstBean.class);
//	            beanList.add(bean);
//	        }
//		
			
		return beanList;
	}



}
