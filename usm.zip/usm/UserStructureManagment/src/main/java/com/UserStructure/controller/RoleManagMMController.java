package com.UserStructure.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.UserStructure.Bean.MenuMstBean;
import com.UserStructure.hlp.MenuMstHLP;
import com.UserStructure.service.MenuMstService;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.UserStructure.Bean.MenuMstBean;
//import com.UserStructure.Utill.GenericCombo;
//import com.UserStructure.Utill.UsmUtill;
//import com.UserStructure.service.MenuMstService;
import com.UserStructure.util.UsmUtill;

@Controller
@RequestMapping("")
public class RoleManagMMController {

	@Autowired
	private MenuMstService menuMstService;

	@Autowired
	private UsmUtill UsmUtil;
	
	@Autowired
	public MenuMstHLP menuMstHLP;
	

	@GetMapping("/menu") // Define a valid path for the menu
	public ModelAndView showMenu(@ModelAttribute MenuMstBean menuMstBean, Model model) {
		
		System.out.println("call method to show ui page.................");
		
		return new ModelAndView("menulist","menuMstBean",menuMstBean); 
		// Return the name of the Thymeleaf template
	}

	@RequestMapping(value = "getList")
	public @ResponseBody String getList(@ModelAttribute MenuMstBean menuMstBean, Model model) {
//		List<GenericCombo<Integer, String>> moduleList = menuMstService.getModule(1, menuMstBean).stream()
//				.map(b -> new GenericCombo<>(b.getGnumModuleId(), b.getGstrModuleName())).collect(Collectors.toList());

		//String moduleCombo = UsmUtil.getOptions(moduleList, menuMstBean.getGnumModuleId());
		
		System.out.println("calling to get menu..........");

		List<MenuMstBean> list = menuMstService.getModule(1);
		//model.addAttribute("ModuleCombo", moduleCombo);

		return menuMstHLP.getAllMenuList(list);
	}
	
	@RequestMapping("addMenu")
	public ModelAndView addMenu(@ModelAttribute MenuMstBean menuMstBean, Model model) {
		
		/*
		 * menuMstBean.setGnumOnlineOffline(0); menuMstBean.setIsModify(0); String
		 * RootMenuCombo =
		 * UsmUtil.getOptions(MenuMstService.getRootMenu(1,menuMstBean).stream() .map(b
		 * -> new ComboOption(String.valueOf(b.getGnumMenuId()), b.getGstrMenuName()))
		 * .collect(Collectors.toList()),"-1^Select Value", "");
		 * model.addAttribute("RootMenuCombo", RootMenuCombo);
		 */
						
		return new ModelAndView("menuForm", "MenuMstBean", menuMstBean);
	}
	
	
	
}

//@Controller
//public class  RoleManagMMController {
//
//    @Autowired
//    private MenuMstService menuMstService;
//    @Autowired
//    private UsmUtill UsmUtil;
//
//    @GetMapping("/menulist")
//    public ModelAndView getList(@ModelAttribute MenuMstBean menuMstBean, Model model) {
//        List<GenericCombo<Integer, String>> moduleList = menuMstService.getModule(1, menuMstBean).stream()
//            .map(b -> new GenericCombo<>(b.getGnumModuleId(), b.getGstrModuleName()))
//            .collect(Collectors.toList());
//
//        String moduleCombo = UsmUtil.getOptions(
//            moduleList, 
//            menuMstBean.getGnumModuleId()
//        );
//        
//        model.addAttribute("ModuleCombo", moduleCombo);
//        
//        return new ModelAndView("menulist", "MenuMstBean", menuMstBean);
//    }
//}
