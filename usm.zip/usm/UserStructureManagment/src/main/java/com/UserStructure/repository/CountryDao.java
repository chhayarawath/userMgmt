package com.UserStructure.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.UserStructure.entity.GbltCountryMstImsc;


public interface CountryDao extends JpaRepository<GbltCountryMstImsc, Integer> {
	
	// Using @Query annotation to define a custom query
    @Query("SELECT c FROM GbltCountryMstImsc c WHERE c.gnumIsvalid = 1 ORDER BY c.gnumCountrycode")
    List<GbltCountryMstImsc> findAllValidCountries();
    


}
