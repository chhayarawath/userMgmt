package com.UserStructure;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.UserStructure")
//@EntityScan(basePackages = "com.UserStructure.Bean") // Adjust package name as needed
public class UserStructureManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserStructureManagmentApplication.class, args);
	}

}
