package com.UserStructure.Bean;

import java.util.Date;

public class StateMstBean {
	
	private Integer gnumStatecode;
	private Integer gnumCountrycode;
	private String gstrStatename;
	private String gstrStateshort;
	private Integer gnumSeatid;
	private Date gdtEntrydate;
	private Integer gnumIsvalid;
	private Date gdtLstmodDate;
	private Integer gnumLstmodSeatid;
	private String gstrRemarks;
	private Integer gnumHl7Code;
	private Integer gnumHospitalCode;
	private Integer gnumIsDefaultState;
	private Integer gnumIsDefaultUt;
	private String gstrDatasourceName;
	private String gstrSchemaName;
	private String id; // Base64 encoded ID
	private String strCountryName;
	private Integer isModify; // Flag to indicate modification
	
	 // New field for the success/error message
    private String strMessage;

   
	// Getter and Setter for strMessage
    public String getStrMessage() {
        return strMessage;
    }

    public void setStrMessage(String strMessage) {
        this.strMessage = strMessage;
    }

	public Integer getGnumStatecode() {
		return gnumStatecode;
	}

	public void setGnumStatecode(Integer gnumStatecode) {
		this.gnumStatecode = gnumStatecode;
	}

	public Integer getGnumCountrycode() {
		return gnumCountrycode;
	}

	public void setGnumCountrycode(Integer gnumCountrycode) {
		this.gnumCountrycode = gnumCountrycode;
	}

	public String getGstrStatename() {
		return gstrStatename;
	}

	public void setGstrStatename(String gstrStatename) {
		this.gstrStatename = gstrStatename;
	}

	public String getGstrStateshort() {
		return gstrStateshort;
	}

	public void setGstrStateshort(String gstrStateshort) {
		this.gstrStateshort = gstrStateshort;
	}

	public Integer getGnumSeatid() {
		return gnumSeatid;
	}

	public void setGnumSeatid(Integer gnumSeatid) {
		this.gnumSeatid = gnumSeatid;
	}

	public Date getGdtEntrydate() {
		return gdtEntrydate;
	}

	public void setGdtEntrydate(Date gdtEntrydate) {
		this.gdtEntrydate = gdtEntrydate;
	}

	public Integer getGnumIsvalid() {
		return gnumIsvalid;
	}

	public void setGnumIsvalid(Integer gnumIsvalid) {
		this.gnumIsvalid = gnumIsvalid;
	}

	public Date getGdtLstmodDate() {
		return gdtLstmodDate;
	}

	public void setGdtLstmodDate(Date gdtLstmodDate) {
		this.gdtLstmodDate = gdtLstmodDate;
	}

	public Integer getGnumLstmodSeatid() {
		return gnumLstmodSeatid;
	}

	public void setGnumLstmodSeatid(Integer gnumLstmodSeatid) {
		this.gnumLstmodSeatid = gnumLstmodSeatid;
	}

	public String getGstrRemarks() {
		return gstrRemarks;
	}

	public void setGstrRemarks(String gstrRemarks) {
		this.gstrRemarks = gstrRemarks;
	}

	public Integer getGnumHl7Code() {
		return gnumHl7Code;
	}

	public void setGnumHl7Code(Integer gnumHl7Code) {
		this.gnumHl7Code = gnumHl7Code;
	}

	public Integer getGnumHospitalCode() {
		return gnumHospitalCode;
	}

	public void setGnumHospitalCode(Integer gnumHospitalCode) {
		this.gnumHospitalCode = gnumHospitalCode;
	}

	public Integer getGnumIsDefaultState() {
		return gnumIsDefaultState;
	}

	public void setGnumIsDefaultState(Integer gnumIsDefaultState) {
		this.gnumIsDefaultState = gnumIsDefaultState;
	}

	public Integer getGnumIsDefaultUt() {
		return gnumIsDefaultUt;
	}

	public void setGnumIsDefaultUt(Integer gnumIsDefaultUt) {
		this.gnumIsDefaultUt = gnumIsDefaultUt;
	}

	public String getGstrDatasourceName() {
		return gstrDatasourceName;
	}

	public void setGstrDatasourceName(String gstrDatasourceName) {
		this.gstrDatasourceName = gstrDatasourceName;
	}

	public String getGstrSchemaName() {
		return gstrSchemaName;
	}

	public void setGstrSchemaName(String gstrSchemaName) {
		this.gstrSchemaName = gstrSchemaName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStrCountryName() {
		return strCountryName;
	}

	public void setStrCountryName(String strCountryName) {
		this.strCountryName = strCountryName;
	}

	public Integer getIsModify() {
		return isModify;
	}

	public void setIsModify(Integer isModify) {
		this.isModify = isModify;
	}

	

	@Override
	public String toString() {
		return "StateMstBean [gnumStatecode=" + gnumStatecode + ", gnumCountrycode=" + gnumCountrycode
				+ ", gstrStatename=" + gstrStatename + ", gstrStateshort=" + gstrStateshort + ", gnumSeatid="
				+ gnumSeatid + ", gdtEntrydate=" + gdtEntrydate + ", gnumIsvalid=" + gnumIsvalid + ", gdtLstmodDate="
				+ gdtLstmodDate + ", gnumLstmodSeatid=" + gnumLstmodSeatid + ", gstrRemarks=" + gstrRemarks
				+ ", gnumHl7Code=" + gnumHl7Code + ", gnumHospitalCode=" + gnumHospitalCode + ", gnumIsDefaultState="
				+ gnumIsDefaultState + ", gnumIsDefaultUt=" + gnumIsDefaultUt + ", gstrDatasourceName="
				+ gstrDatasourceName + ", gstrSchemaName=" + gstrSchemaName + ", id=" + id + ", strCountryName="
				+ strCountryName + ", isModify=" + isModify + ", strMessage=" + strMessage + "]";
	}
	
/*	public StateMstBean(Integer gnumStatecode, Integer gnumHospitalCode, Integer gnumCountrycode) {
	    this.gnumStatecode = gnumStatecode;
	    this.gnumHospitalCode = gnumHospitalCode;
	    this.gnumCountrycode = gnumCountrycode;
	}*/

}
	
	