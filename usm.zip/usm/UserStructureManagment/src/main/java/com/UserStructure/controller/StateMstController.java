package com.UserStructure.controller;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.UserStructure.Bean.StateMstBean;
import com.UserStructure.entity.GbltCountryMstImsc;
import com.UserStructure.entity.GbltStateMstImsc;
import com.UserStructure.hlp.StateMsterHlp;
import com.UserStructure.service.CountryService;
import com.UserStructure.service.StateMstService;
import com.UserStructure.usm.DvdmsConfig;
import com.UserStructure.util.ComboOption;
import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("/state") 
/*@Controller
@RequestMapping("/")*/
public class StateMstController {

    @Autowired
    private StateMstService stateMstService;
    
    @Autowired
    private CountryService countryService;

    @Autowired
    private StateMsterHlp stateMsterHlp;

    @Autowired
    private HttpSession session; // Inject HttpSession
//=============================================================================================================================================
    @GetMapping("/stateMaster")
    public ModelAndView getList(@ModelAttribute StateMstBean stateMstBean, ModelMap model) throws Exception {
        // Set session attributes
        session.setAttribute("hospitalCode", DvdmsConfig.GLOBAL_HOSPITAL_CODE);
        session.setAttribute("seatId", DvdmsConfig.SEAT_ID);
       

        // Fetch the list of valid countries
        List<GbltCountryMstImsc> countryList = stateMstService.getCountryList()
                .stream()
                .filter(country -> country.getGnumCountrycode() != null && country.getGstrCountryname() != null)
                .collect(Collectors.toList());

        // Prepare the list of ComboOption for status
        List<ComboOption> statusOptions = List.of(
            new ComboOption("1", "Active"),
            new ComboOption("2", "Inactive")
        );// Set default values for stateMstBean
        // Retrieve the country code for India from the countryList
        Integer indiaCountryCode = countryList.stream()
                .filter(country -> "India".equals(country.getGstrCountryname())) // Check for country name
                .map(GbltCountryMstImsc::getGnumCountrycode) // Get the country code
                .findFirst()
                .orElse(null); // Handle case where "India" is not found

        stateMstBean.setGnumCountrycode(indiaCountryCode); // Set the country code as Integer
        stateMstBean.setGnumIsvalid(1); // Set default status to Active

        // Add the lists to the model attributes
        model.addAttribute("countryList", countryList);
        model.addAttribute("statusOptions", statusOptions);
        model.addAttribute("stateMstBean", stateMstBean);

        // Return ModelAndView with the view name
        return new ModelAndView("stateMstLst", model);
    }

    @GetMapping("/getStateList")
    public @ResponseBody String getStateList(@ModelAttribute StateMstBean stateMstBean) {
        return stateMsterHlp.getStateList(stateMstService.getStateList(
                session, // Pass session to service
                stateMstBean.getGnumCountrycode(),
                stateMstBean.getGnumIsvalid())); // Ensure gnumIsvalid is passed
    }

//=============================================================================================================================================
    
    
    @RequestMapping("addState")
    public ModelAndView addState(@ModelAttribute StateMstBean stateMstBean, Model model) {
        stateMstBean.setIsModify(0);
        return new ModelAndView("addStateForm", "stateMstBean", stateMstBean);
    }
    
  
//=============================================================================================================================================    

    @RequestMapping("modifyState")
    public ModelAndView modifyState(@RequestParam("selectedStates") List<String> selectedStates, ModelMap model, HttpSession session) throws Exception {
        // Decode Base64 selectedStates and convert to Integer
        List<Integer> stateIds = selectedStates.stream()
                .map(id -> Integer.valueOf(new String(Base64.getDecoder().decode(id))))
                .collect(Collectors.toList());

        // Ensure the list has at least one ID
        if (stateIds.isEmpty()) {
            throw new IllegalArgumentException("No valid state IDs provided.");
        }

        // Use the first state ID (if multiple, modify logic as needed)
        Integer id = stateIds.get(0);

        // Retrieve state details using the service, passing the session
        StateMstBean stateDetail = stateMstService.getStateDetail(session, DvdmsConfig.GLOBAL_HOSPITAL_CODE, null, id);

        // Check if stateDetail is found
        if (stateDetail != null) {
            stateDetail.setIsModify(1); // Modify flag set
            model.addAttribute("stateMstBean", stateDetail); // Add state details to the model
        } else {
            model.addAttribute("error", "State not found.");
        }

        // Return the model and view with the updated stateMstBean
        return new ModelAndView("addStateForm", "stateMstBean", stateDetail != null ? stateDetail : new StateMstBean());
    }

  //=================================================================================================================================
 
  @RequestMapping(value = "saveState1", method = RequestMethod.POST)
  
	public ModelAndView saveState(@ModelAttribute StateMstBean stateMstBean, ModelMap model)
			throws Exception {
		
		stateMstBean.setGnumSeatid(DvdmsConfig.SEAT_ID);
		stateMstBean.setGnumHospitalCode(DvdmsConfig.GLOBAL_HOSPITAL_CODE);
		stateMstBean.setGdtEntrydate(stateMstService.getDSTimeStamp());
		ModelAndView modelAndView = new ModelAndView();
		Integer status = stateMstService.createOrUpdateState(stateMstBean);
		
		model.addAttribute("SUCCESS_MESSAGE", stateMstBean.getStrMessage());
		
		if (status > 0) {
			model.addAttribute("SUCCESS_MESSAGE", stateMstBean.getStrMessage());
			
			if(stateMstBean.getIsModify() == 0) {
		    	stateMstBean.setGstrStatename("");
		    	stateMstBean.setGstrStateshort("");
			}
			modelAndView.setViewName("redirect:/state/getList");
			return modelAndView;
		} else {
			model.addAttribute("SUCCESS_MESSAGE", stateMstBean.getStrMessage());
			modelAndView.setViewName("redirect:/state/getList");
			return modelAndView;
		}
	}
  
//===============================================================================================================================      
  @GetMapping("/viewState")
  @ResponseBody
  public String viewState(@RequestParam("stateCode") Integer stateCode) {
      GbltStateMstImsc state = stateMstService.getStateByCode(stateCode);

      if (state != null) {
          return "<table id='viewTableListing' class='table-bordered' width='100%'>"
                  + "<tr><td><strong>State Name</strong></td><td>" + state.getGstrStatename() + "</td></tr>"
                  + "<tr><td><strong>State Short Name</strong></td><td>" + state.getGstrStateshort() + "</td></tr>"
                  + "<tr><td><strong>UT</strong></td><td>" + (state.getGnumIsDefaultUt() == 1 ? "Yes" : "No") + "</td></tr>"
                  + "</table>";
      } else {
          return "<p>State not found!</p>";
      }
  }

 //========================================================Delete===============================================================

  @RequestMapping(value = "deleteState", method = RequestMethod.POST)
  public ModelAndView deleteState(@ModelAttribute StateMstBean stateMstBean, 
                                  @RequestParam("selectedStates") List<String> selectedStates,
                                  ModelMap model) throws Exception {

      // Initialize ModelAndView
      ModelAndView modelAndView = new ModelAndView();

      // Set the hospital code
      stateMstBean.setGnumHospitalCode(DvdmsConfig.GLOBAL_HOSPITAL_CODE);
      List<StateMstBean> states = new ArrayList<>();

      // Loop through selected states
      for (String encodedId : selectedStates) {
          String decodedId = new String(Base64.getDecoder().decode(encodedId));
          try {
              Integer stateCode = Integer.valueOf(decodedId);
              StateMstBean stateToDelete = new StateMstBean();
              stateToDelete.setGnumStatecode(stateCode);
              stateToDelete.setGnumHospitalCode(DvdmsConfig.GLOBAL_HOSPITAL_CODE);
              stateToDelete.setGnumCountrycode(stateMstBean.getGnumCountrycode());

              states.add(stateToDelete);
          } catch (NumberFormatException e) {
              model.addAttribute("ERROR_MESSAGE", "Invalid state code: " + decodedId);
              return new ModelAndView("stateMstForm", "stateMstBean", stateMstBean);
          }
      }

      // Call the service to delete states
      boolean result = stateMstService.deleteState(states);

      // Prepare response based on result
      if (result) {
          model.addAttribute("SUCCESS_MESSAGE", selectedStates.size() + " State(s) Successfully Deleted!!");
          modelAndView.setViewName("redirect:/state/getList");
      } else {
          model.addAttribute("SUCCESS_MESSAGE", "State(s) Deletion failed !!");
          modelAndView.setViewName("redirect:/state/getList");
      }

      return modelAndView;
  }



 
}
    

