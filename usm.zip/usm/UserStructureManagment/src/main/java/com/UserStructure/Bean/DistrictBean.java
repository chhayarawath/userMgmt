
package com.UserStructure.Bean;
import java.sql.Date;
public class DistrictBean {

	private Integer numDistId;
	private String strDistCode;
	private String strDistName;
	private String strDistStName;
	private Integer gnumSlno;
	private Date gdtEffectiveFrm;
	private Date gdtEffectiveTo;
	private Integer gnumCountrycode;
	private String gstrCountryname;
	private String gstrStatename;
	private Integer strIsCircle;
	private Integer isModify = 0;
	private Integer gnumIsvalid;
	private Integer gnumSeatId;
	private Date gdtEntryDate;
	private Date gdtLstmodDate;
	private Integer gnumLstmodSeatid;
	private String gstrRemarks;
	private Integer gnumStatecode;
	private Integer numZoneId;
	private String hstnumLongitude;
	private String hstnumLatitude;
	private String hststrMapFeatureId;
	private Integer stateCode;
	private String strZoneName;

	public Integer getNumDistId() {
		return numDistId;
	}

	public void setNumDistId(Integer numDistId) {
		this.numDistId = numDistId;
	}

	public String getStrDistCode() {
		return strDistCode;
	}

	public void setStrDistCode(String strDistCode) {
		this.strDistCode = strDistCode;
	}

	public String getStrDistName() {
		return strDistName;
	}

	public void setStrDistName(String strDistName) {
		this.strDistName = strDistName;
	}

	public String getStrDistStName() {
		return strDistStName;
	}

	public void setStrDistStName(String strDistStName) {
		this.strDistStName = strDistStName;
	}

	public Integer getGnumSlno() {
		return gnumSlno;
	}

	public void setGnumSlno(Integer gnumSlno) {
		this.gnumSlno = gnumSlno;
	}

	public Date getGdtEffectiveFrm() {
		return gdtEffectiveFrm;
	}

	public void setGdtEffectiveFrm(Date gdtEffectiveFrm) {
		this.gdtEffectiveFrm = gdtEffectiveFrm;
	}

	public Date getGdtEffectiveTo() {
		return gdtEffectiveTo;
	}

	public void setGdtEffectiveTo(Date gdtEffectiveTo) {
		this.gdtEffectiveTo = gdtEffectiveTo;
	}

	public Integer getGnumCountrycode() {
		return gnumCountrycode;
	}

	public void setGnumCountrycode(Integer gnumCountrycode) {
		this.gnumCountrycode = gnumCountrycode;
	}

	public String getGstrCountryname() {
		return gstrCountryname;
	}

	public void setGstrCountryname(String gstrCountryname) {
		this.gstrCountryname = gstrCountryname;
	}

	public String getGstrStatename() {
		return gstrStatename;
	}

	public void setGstrStatename(String gstrStatename) {
		this.gstrStatename = gstrStatename;
	}

	public Integer getStrIsCircle() {
		return strIsCircle;
	}

	public void setStrIsCircle(Integer strIsCircle) {
		this.strIsCircle = strIsCircle;
	}

	public Integer getIsModify() {
		return isModify;
	}

	public void setIsModify(Integer isModify) {
		this.isModify = isModify;
	}

	public Integer getGnumIsvalid() {
		return gnumIsvalid;
	}

	public void setGnumIsvalid(Integer gnumIsvalid) {
		this.gnumIsvalid = gnumIsvalid;
	}

	public Integer getGnumSeatId() {
		return gnumSeatId;
	}

	public void setGnumSeatId(Integer gnumSeatId) {
		this.gnumSeatId = gnumSeatId;
	}

	public Date getGdtEntryDate() {
		return gdtEntryDate;
	}

	public void setGdtEntryDate(Date gdtEntryDate) {
		this.gdtEntryDate = gdtEntryDate;
	}

	public Date getGdtLstmodDate() {
		return gdtLstmodDate;
	}

	public void setGdtLstmodDate(Date gdtLstmodDate) {
		this.gdtLstmodDate = gdtLstmodDate;
	}

	public Integer getGnumLstmodSeatid() {
		return gnumLstmodSeatid;
	}

	public void setGnumLstmodSeatid(Integer gnumLstmodSeatid) {
		this.gnumLstmodSeatid = gnumLstmodSeatid;
	}

	public String getGstrRemarks() {
		return gstrRemarks;
	}

	public void setGstrRemarks(String gstrRemarks) {
		this.gstrRemarks = gstrRemarks;
	}

	public Integer getGnumStatecode() {
		return gnumStatecode;
	}

	public void setGnumStatecode(Integer gnumStatecode) {
		this.gnumStatecode = gnumStatecode;
	}

	public Integer getNumZoneId() {
		return numZoneId;
	}

	public void setNumZoneId(Integer numZoneId) {
		this.numZoneId = numZoneId;
	}

	

	public String getHstnumLongitude() {
		return hstnumLongitude;
	}

	public void setHstnumLongitude(String hstnumLongitude) {
		this.hstnumLongitude = hstnumLongitude;
	}

	public String getHstnumLatitude() {
		return hstnumLatitude;
	}

	public void setHstnumLatitude(String hstnumLatitude) {
		this.hstnumLatitude = hstnumLatitude;
	}

	public String getHststrMapFeatureId() {
		return hststrMapFeatureId;
	}

	public void setHststrMapFeatureId(String hststrMapFeatureId) {
		this.hststrMapFeatureId = hststrMapFeatureId;
	}

	public Integer getStateCode() {
		return stateCode;
	}

	public void setStateCode(Integer stateCode) {
		this.stateCode = stateCode;
	}

	public String getStrZoneName() {
		return strZoneName;
	}

	public void setStrZoneName(String strZoneName) {
		this.strZoneName = strZoneName;
	}

	@Override
	public String toString() {
		return "DistrictBean [numDistId=" + numDistId + ", strDistCode=" + strDistCode + ", strDistName=" + strDistName
				+ ", strDistStName=" + strDistStName + ", gnumSlno=" + gnumSlno + ", gdtEffectiveFrm=" + gdtEffectiveFrm
				+ ", gdtEffectiveTo=" + gdtEffectiveTo + ", gnumCountrycode=" + gnumCountrycode + ", gstrCountryname="
				+ gstrCountryname + ", gstrStatename=" + gstrStatename + ", strIsCircle=" + strIsCircle + ", isModify="
				+ isModify + ", gnumIsvalid=" + gnumIsvalid + ", gnumSeatId=" + gnumSeatId + ", gdtEntryDate="
				+ gdtEntryDate + ", gdtLstmodDate=" + gdtLstmodDate + ", gnumLstmodSeatid=" + gnumLstmodSeatid
				+ ", gstrRemarks=" + gstrRemarks + ", gnumStatecode=" + gnumStatecode + ", numZoneId=" + numZoneId
				+ ", hstnumLongitude=" + hstnumLongitude + ", hstnumLatitude=" + hstnumLatitude
				+ ", hststrMapFeatureId=" + hststrMapFeatureId + ", stateCode=" + stateCode + ", strZoneName="
				+ strZoneName + ", getNumDistId()=" + getNumDistId() + ", getStrDistCode()=" + getStrDistCode()
				+ ", getStrDistName()=" + getStrDistName() + ", getStrDistStName()=" + getStrDistStName()
				+ ", getGnumSlno()=" + getGnumSlno() + ", getGdtEffectiveFrm()=" + getGdtEffectiveFrm()
				+ ", getGdtEffectiveTo()=" + getGdtEffectiveTo() + ", getGnumCountrycode()=" + getGnumCountrycode()
				+ ", getGstrCountryname()=" + getGstrCountryname() + ", getGstrStatename()=" + getGstrStatename()
				+ ", getStrIsCircle()=" + getStrIsCircle() + ", getIsModify()=" + getIsModify() + ", getGnumIsvalid()="
				+ getGnumIsvalid() + ", getGnumSeatId()=" + getGnumSeatId() + ", getGdtEntryDate()=" + getGdtEntryDate()
				+ ", getGdtLstmodDate()=" + getGdtLstmodDate() + ", getGnumLstmodSeatid()=" + getGnumLstmodSeatid()
				+ ", getGstrRemarks()=" + getGstrRemarks() + ", getGnumStatecode()=" + getGnumStatecode()
				+ ", getNumZoneId()=" + getNumZoneId() + ", getHstnumLongitude()=" + getHstnumLongitude()
				+ ", getHstnumLatitude()=" + getHstnumLatitude() + ", getHststrMapFeatureId()="
				+ getHststrMapFeatureId() + ", getStateCode()=" + getStateCode() + ", getStrZoneName()="
				+ getStrZoneName() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	

	

	

}
