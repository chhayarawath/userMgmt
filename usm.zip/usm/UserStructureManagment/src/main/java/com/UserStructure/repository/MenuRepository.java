package com.UserStructure.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.UserStructure.entity.UmmtMenuMst;

@Repository
public interface MenuRepository extends JpaRepository<UmmtMenuMst, Long> {
	
	public List<UmmtMenuMst> findAllByGnumIsvalid(Integer gnumIsvalid);
	
	
}
