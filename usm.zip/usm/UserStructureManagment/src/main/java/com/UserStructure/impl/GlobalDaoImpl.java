/*
 * package com.UserStructure.impl; import
 * com.UserStructure.repository.GlobalDao; // Ensure you import your GlobalDao
 * interface import org.springframework.stereotype.Repository; import
 * org.springframework.transaction.annotation.Transactional; import
 * javax.persistence.EntityManager; import javax.persistence.PersistenceContext;
 * import javax.persistence.Query; import java.util.Date;
 * 
 * @Repository public class GlobalDaoImpl implements GlobalDao {
 * 
 * @PersistenceContext private EntityManager entityManager;
 * 
 *//**
	 * Returns Database Server Date dtFormat --> date format[dd-Mon-yyyy,
	 * dd/MM/yyyy, dd/Mon/yyyy etc]
	 * 
	 * if dtFormat is blank then default format is dd-Mon-yyyy.
	 * 
	 * @param dtFormat Date Format in String.
	 * @return Database Server Date in required Format.
	 *//*
		 * @Override
		 * 
		 * @Transactional(readOnly = true) public String getDSDate(String dtFormat) { if
		 * (dtFormat == null || dtFormat.isEmpty()) { dtFormat = "dd-Mon-yyyy"; }
		 * 
		 * Query query =
		 * entityManager.createNativeQuery("SELECT TO_CHAR(now(), :dtFormat)");
		 * query.setParameter("dtFormat", dtFormat); return (String)
		 * query.getSingleResult(); }
		 * 
		 * @Override
		 * 
		 * @Transactional(readOnly = true) public Date getDSDate() { Query query =
		 * entityManager.createNativeQuery("SELECT cast(now() as date)"); return (Date)
		 * query.getSingleResult(); }
		 * 
		 * @Override
		 * 
		 * @Transactional(readOnly = true) public Date getDSDate2YearExtend() { Query
		 * query = entityManager.
		 * createNativeQuery("SELECT cast(now() + interval '2 year' as date)"); return
		 * (Date) query.getSingleResult(); }
		 * 
		 * @Override
		 * 
		 * @Transactional(readOnly = true) public Date getDSTimeStamp() { Query query =
		 * entityManager.createNativeQuery("SELECT now()"); return (Date)
		 * query.getSingleResult(); }
		 * 
		 * @Override
		 * 
		 * @Transactional public void flush() { entityManager.flush(); }
		 * 
		 * @Override
		 * 
		 * @Transactional public void clear() { entityManager.clear(); } }
		 */