package com.UserStructure.entity;

import java.sql.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "gblt_country_mst_imsc", schema = "usm")
public class GbltCountryMstImsc {

    @Id
    @GeneratedValue(generator = "TableIdGenerator")
    @Column(name = "gnum_countrycode", nullable = false, precision = 3, scale = 0)
    private Integer gnumCountrycode;

    @Column(name = "gstr_countryname", nullable = false, length = 40)
    private String gstrCountryname;

    @Column(name = "gstr_countryshort", length = 3)
    private String gstrCountryshort;

    @Column(name = "gnum_seatid", precision = 8, scale = 0)
    private Integer gnumSeatid;

    @Column(name = "gdt_entrydate", length = 29)
    private Date gdtEntrydate;

    @Column(name = "gnum_isvalid", precision = 1, scale = 0)
    private Integer gnumIsvalid;

    @Column(name = "gstr_nationality", length = 30)
    private String gstrNationality;
    
    @Column(name = "gnum_hl7_code", precision = 10, scale = 0)
    private Long gnumHl7Code;

	public Integer getGnumCountrycode() {
		return gnumCountrycode;
	}

	public void setGnumCountrycode(Integer gnumCountrycode) {
		this.gnumCountrycode = gnumCountrycode;
	}

	public String getGstrCountryname() {
		return gstrCountryname;
	}

	public void setGstrCountryname(String gstrCountryname) {
		this.gstrCountryname = gstrCountryname;
	}

	public String getGstrCountryshort() {
		return gstrCountryshort;
	}

	public void setGstrCountryshort(String gstrCountryshort) {
		this.gstrCountryshort = gstrCountryshort;
	}

	public Integer getGnumSeatid() {
		return gnumSeatid;
	}

	public void setGnumSeatid(Integer gnumSeatid) {
		this.gnumSeatid = gnumSeatid;
	}

	public Date getGdtEntrydate() {
		return gdtEntrydate;
	}

	public void setGdtEntrydate(Date gdtEntrydate) {
		this.gdtEntrydate = gdtEntrydate;
	}

	public Integer getGnumIsvalid() {
		return gnumIsvalid;
	}

	public void setGnumIsvalid(Integer gnumIsvalid) {
		this.gnumIsvalid = gnumIsvalid;
	}

	public String getGstrNationality() {
		return gstrNationality;
	}

	public void setGstrNationality(String gstrNationality) {
		this.gstrNationality = gstrNationality;
	}

	public Long getGnumHl7Code() {
		return gnumHl7Code;
	}

	public void setGnumHl7Code(Long gnumHl7Code) {
		this.gnumHl7Code = gnumHl7Code;
	}
    
    

}
