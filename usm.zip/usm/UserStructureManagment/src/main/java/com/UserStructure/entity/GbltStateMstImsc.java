package com.UserStructure.entity;
import java.util.Date;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "gblt_state_mst_imsc", schema = "usm")
public class GbltStateMstImsc {

	@Id
	@GeneratedValue(generator = "TableIdGenerator")
	//@GenericGenerator(name = "TableIdGenerator", strategy = "usm.entity.UsmIdGenerator")
	@Column(name = "gnum_statecode", nullable = false, precision = 2, scale = 0)
	private Integer gnumStatecode;

	@Column(name = "gnum_countrycode", precision = 3, scale = 0)
	private Integer gnumCountrycode;

	@Column(name = "gstr_statename", length = 40)
	private String gstrStatename;

	@Column(name = "gstr_stateshort", length = 3)
	private String gstrStateshort;

	@Column(name = "gnum_seatid", precision = 8, scale = 0)
	private Integer gnumSeatid;

	@Column(name = "gdt_entrydate", length = 29)
	private Date gdtEntrydate;

	@Column(name = "gnum_isvalid", precision = 1, scale = 0)
	private Integer gnumIsvalid;

	@Column(name = "gdt_lstmod_date", length = 29)
	private Date gdtLstmodDate;

	@Column(name = "gnum_lstmod_seatid", precision = 5, scale = 0)
	private Integer gnumLstmodSeatid;

	@Column(name = "gstr_remarks", length = 50)
	private String gstrRemarks;

	@Column(name = "gnum_hl7_code", precision = 10, scale = 0)
	private Integer gnumHl7Code;

	@Column(name = "gnum_hospital_code", precision = 3, scale = 0)
	private Integer gnumHospitalCode;

	@Column(name = "gnum_is_default_state", precision = 1, scale = 0)
	private Integer gnumIsDefaultState;

	@Column(name = "gnum_is_default_ut", precision = 1, scale = 0)
	private Integer gnumIsDefaultUt;
	
	@Column(name = "gstr_datasource_name", length = 10)
	private String gstrDatasourceName;
	
	@Column(name = "gstr_schema_name", length = 20)
	private String gstrSchemaName;

	public Integer getGnumStatecode() {
		return gnumStatecode;
	}

	public void setGnumStatecode(Integer gnumStatecode) {
		this.gnumStatecode = gnumStatecode;
	}

	public Integer getGnumCountrycode() {
		return gnumCountrycode;
	}

	public void setGnumCountrycode(Integer gnumCountrycode) {
		this.gnumCountrycode = gnumCountrycode;
	}

	public String getGstrStatename() {
		return gstrStatename;
	}

	public void setGstrStatename(String gstrStatename) {
		this.gstrStatename = gstrStatename;
	}

	public String getGstrStateshort() {
		return gstrStateshort;
	}

	public void setGstrStateshort(String gstrStateshort) {
		this.gstrStateshort = gstrStateshort;
	}

	public Integer getGnumSeatid() {
		return gnumSeatid;
	}

	public void setGnumSeatid(Integer gnumSeatid) {
		this.gnumSeatid = gnumSeatid;
	}

	public Date getGdtEntrydate() {
		return gdtEntrydate;
	}

	public void setGdtEntrydate(Date gdtEntrydate) {
		this.gdtEntrydate = gdtEntrydate;
	}

	public Integer getGnumIsvalid() {
		return gnumIsvalid;
	}

	public void setGnumIsvalid(Integer gnumIsvalid) {
		this.gnumIsvalid = gnumIsvalid;
	}

	public Date getGdtLstmodDate() {
		return gdtLstmodDate;
	}

	public void setGdtLstmodDate(Date gdtLstmodDate) {
		this.gdtLstmodDate = gdtLstmodDate;
	}

	public Integer getGnumLstmodSeatid() {
		return gnumLstmodSeatid;
	}

	public void setGnumLstmodSeatid(Integer gnumLstmodSeatid) {
		this.gnumLstmodSeatid = gnumLstmodSeatid;
	}

	public String getGstrRemarks() {
		return gstrRemarks;
	}

	public void setGstrRemarks(String gstrRemarks) {
		this.gstrRemarks = gstrRemarks;
	}

	public Integer getGnumHl7Code() {
		return gnumHl7Code;
	}

	public void setGnumHl7Code(Integer gnumHl7Code) {
		this.gnumHl7Code = gnumHl7Code;
	}

	public Integer getGnumHospitalCode() {
		return gnumHospitalCode;
	}

	public void setGnumHospitalCode(Integer gnumHospitalCode) {
		this.gnumHospitalCode = gnumHospitalCode;
	}

	public Integer getGnumIsDefaultState() {
		return gnumIsDefaultState;
	}

	public void setGnumIsDefaultState(Integer gnumIsDefaultState) {
		this.gnumIsDefaultState = gnumIsDefaultState;
	}

	public Integer getGnumIsDefaultUt() {
		return gnumIsDefaultUt;
	}

	public void setGnumIsDefaultUt(Integer gnumIsDefaultUt) {
		this.gnumIsDefaultUt = gnumIsDefaultUt;
	}

	public String getGstrDatasourceName() {
		return gstrDatasourceName;
	}

	public void setGstrDatasourceName(String gstrDatasourceName) {
		this.gstrDatasourceName = gstrDatasourceName;
	}

	public String getGstrSchemaName() {
		return gstrSchemaName;
	}

	public void setGstrSchemaName(String gstrSchemaName) {
		this.gstrSchemaName = gstrSchemaName;
	}


	
}
