package com.UserStructure.repository;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.UserStructure.entity.GbltStateMstImsc;


@Repository
public interface StateMasterRepository extends JpaRepository<GbltStateMstImsc, Integer> {	

	// Existing methods...
    List<GbltStateMstImsc> findAllByGnumIsvalid(Integer gnumIsvalid);

    Optional<GbltStateMstImsc> findByGnumStatecode(Integer gnumStatecode);
    
    // New method to find state by country code and validity status
    List<GbltStateMstImsc> findAllByGnumCountrycodeAndGnumIsvalid(Integer gnumCountrycode, Integer gnumIsvalid);
    
    Optional<GbltStateMstImsc> findByGstrStatename(String gstrStatename);

    @Modifying
    @Query("DELETE FROM GbltStateMstImsc s WHERE s.gnumStatecode IN :gnumStatecodes")
    void deleteByGnumStatecodeIn(@Param("gnumStatecodes") List<Integer> gnumStatecodes);
}

