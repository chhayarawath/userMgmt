package com.UserStructure.entity;
import java.math.BigDecimal;
import java.sql.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "gblt_district_mst_imsc", schema = "usm")
public class GbltDistrictMstImsc {

	@Id
	@Column(name = "num_dist_id", nullable = false, precision = 5, scale = 0)
	private Integer numDistId;
	
	@Column(name = "str_dist_code", length = 6)
	private String strDistCode;
	
	@Column(name = "str_dist_name", length = 100)
	private String strDistName;
	
	@Column(name = "str_dist_st_name", length = 5)
	private String strDistStName;
	
	@Column(name = "gnum_slno", nullable = false, precision = 3, scale = 0)
	private Integer gnumSlno;
	
	@Column(name = "gdt_effective_frm", nullable = false, length = 29)
	private Date gdtEffectiveFrm;
	
	@Column(name = "gdt_effective_to", length = 29)
	private Date gdtEffectiveTo;
	
	
	
	@Column(name = "gnum_isvalid", precision = 1, scale = 0)
	private Integer gnumIsvalid;
	
	@Column(name = "gnum_seat_id", precision = 8, scale = 0)
	private Integer gnumSeatId;
	
	@Column(name = "gdt_entry_date", length = 29)
	private Date gdtEntryDate;
	
	@Column(name = "gdt_lstmod_date", length = 29)
	private Date gdtLstmodDate;
	
	@Column(name = "gnum_lstmod_seatid", precision = 5, scale = 0)
	private Integer gnumLstmodSeatid;
	
	@Column(name = "gstr_remarks", length = 50)
	private String gstrRemarks;
	
	@Column(name = "gnum_statecode", precision = 2, scale = 0)
	private Integer gnumStatecode;
	
	@Column(name = "num_zone_id", precision = 5, scale = 0)
	private Integer numZoneId;
	
	/*@Column(name = "hstnum_longitude", precision = 10, scale = 6)
	private BigDecimal hstnumLongitude;
	
	@Column(name = "hstnum_latitude", precision = 10, scale = 6)
	private BigDecimal hstnumLatitude;*/
	
	@Column(name = "hstnum_longitude", length = 15)
	private String hstnumLongitude;
	
	@Column(name = "hstnum_latitude", length = 15)
	private String hstnumLatitude;
	
	@Column(name = "hststr_map_feature_id", length = 15)
	private String hststrMapFeatureId;
	
	@Column(name = "state_code", length = 2)
	private String stateCode;

	public Integer getNumDistId() {
		return numDistId;
	}

	public void setNumDistId(Integer numDistId) {
		this.numDistId = numDistId;
	}

	public String getStrDistCode() {
		return strDistCode;
	}

	public void setStrDistCode(String strDistCode) {
		this.strDistCode = strDistCode;
	}

	public String getStrDistName() {
		return strDistName;
	}

	public void setStrDistName(String strDistName) {
		this.strDistName = strDistName;
	}

	public String getStrDistStName() {
		return strDistStName;
	}

	public void setStrDistStName(String strDistStName) {
		this.strDistStName = strDistStName;
	}

	public Integer getGnumSlno() {
		return gnumSlno;
	}

	public void setGnumSlno(Integer gnumSlno) {
		this.gnumSlno = gnumSlno;
	}

	public Date getGdtEffectiveFrm() {
		return gdtEffectiveFrm;
	}

	public void setGdtEffectiveFrm(Date gdtEffectiveFrm) {
		this.gdtEffectiveFrm = gdtEffectiveFrm;
	}

	public Date getGdtEffectiveTo() {
		return gdtEffectiveTo;
	}

	public void setGdtEffectiveTo(Date gdtEffectiveTo) {
		this.gdtEffectiveTo = gdtEffectiveTo;
	}

	public Integer getGnumIsvalid() {
		return gnumIsvalid;
	}

	public void setGnumIsvalid(Integer gnumIsvalid) {
		this.gnumIsvalid = gnumIsvalid;
	}

	public Integer getGnumSeatId() {
		return gnumSeatId;
	}

	public void setGnumSeatId(Integer gnumSeatId) {
		this.gnumSeatId = gnumSeatId;
	}

	public Date getGdtEntryDate() {
		return gdtEntryDate;
	}

	public void setGdtEntryDate(Date gdtEntryDate) {
		this.gdtEntryDate = gdtEntryDate;
	}

	public Date getGdtLstmodDate() {
		return gdtLstmodDate;
	}

	public void setGdtLstmodDate(Date gdtLstmodDate) {
		this.gdtLstmodDate = gdtLstmodDate;
	}

	public Integer getGnumLstmodSeatid() {
		return gnumLstmodSeatid;
	}

	public void setGnumLstmodSeatid(Integer gnumLstmodSeatid) {
		this.gnumLstmodSeatid = gnumLstmodSeatid;
	}

	public String getGstrRemarks() {
		return gstrRemarks;
	}

	public void setGstrRemarks(String gstrRemarks) {
		this.gstrRemarks = gstrRemarks;
	}

	public Integer getGnumStatecode() {
		return gnumStatecode;
	}

	public void setGnumStatecode(Integer gnumStatecode) {
		this.gnumStatecode = gnumStatecode;
	}

	public Integer getNumZoneId() {
		return numZoneId;
	}

	public void setNumZoneId(Integer numZoneId) {
		this.numZoneId = numZoneId;
	}

	public String getHstnumLongitude() {
		return hstnumLongitude;
	}

	public void setHstnumLongitude(String hstnumLongitude) {
		this.hstnumLongitude = hstnumLongitude;
	}

	public String getHstnumLatitude() {
		return hstnumLatitude;
	}

	public void setHstnumLatitude(String hstnumLatitude) {
		this.hstnumLatitude = hstnumLatitude;
	}

	public String getHststrMapFeatureId() {
		return hststrMapFeatureId;
	}

	public void setHststrMapFeatureId(String hststrMapFeatureId) {
		this.hststrMapFeatureId = hststrMapFeatureId;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	
	
	

  
}
