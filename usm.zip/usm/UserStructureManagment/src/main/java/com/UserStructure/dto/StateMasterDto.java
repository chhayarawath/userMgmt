package com.UserStructure.dto;

import jakarta.persistence.Column;


public class StateMasterDto {
	private String gstrStatename;

	private String gstrStateshort;
	
	private String gnumIsDefaultUt;

	public StateMasterDto() {
		super();
	}

	public StateMasterDto(String gstrStatename, String gstrStateshort, String gnumIsDefaultUt) {
		super();
		this.gstrStatename = gstrStatename;
		this.gstrStateshort = gstrStateshort;
		this.gnumIsDefaultUt = gnumIsDefaultUt;
	}

	public String getGstrStatename() {
		return gstrStatename;
	}

	public void setGstrStatename(String gstrStatename) {
		this.gstrStatename = gstrStatename;
	}

	public String getGstrStateshort() {
		return gstrStateshort;
	}

	public void setGstrStateshort(String gstrStateshort) {
		this.gstrStateshort = gstrStateshort;
	}

	public String getGnumIsDefaultUt() {
		return gnumIsDefaultUt;
	}

	public void setGnumIsDefaultUt(String gnumIsDefaultUt) {
		this.gnumIsDefaultUt = gnumIsDefaultUt;
	}

}
