package com.UserStructure.Bean;

import java.util.Date;
import org.springframework.stereotype.Component;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;



@Data
@Setter
@Getter
public class MenuMstBean{
	
	private static final long serialVersionUID = 1L;
	private Long gnumHl7Code;
	private Integer isModify=0;	
	
	private Long gnumMenuId;
	public Long getGnumHl7Code() {
		return gnumHl7Code;
	}
	public void setGnumHl7Code(Long gnumHl7Code) {
		this.gnumHl7Code = gnumHl7Code;
	}
	public Integer getIsModify() {
		return isModify;
	}
	public void setIsModify(Integer isModify) {
		this.isModify = isModify;
	}
	public Long getGnumMenuId() {
		return gnumMenuId;
	}
	public void setGnumMenuId(Long gnumMenuId) {
		this.gnumMenuId = gnumMenuId;
	}
	public Long getGnumParentId() {
		return gnumParentId;
	}
	public void setGnumParentId(Long gnumParentId) {
		this.gnumParentId = gnumParentId;
	}
	public String getGstrMenuName() {
		return gstrMenuName;
	}
	public void setGstrMenuName(String gstrMenuName) {
		this.gstrMenuName = gstrMenuName;
	}
	public String getGstrMenuclassId() {
		return gstrMenuclassId;
	}
	public void setGstrMenuclassId(String gstrMenuclassId) {
		this.gstrMenuclassId = gstrMenuclassId;
	}
	public Integer getGnumMenuLevel() {
		return gnumMenuLevel;
	}
	public void setGnumMenuLevel(Integer gnumMenuLevel) {
		this.gnumMenuLevel = gnumMenuLevel;
	}
	public Integer getGnumDisplayOrder() {
		return gnumDisplayOrder;
	}
	public void setGnumDisplayOrder(Integer gnumDisplayOrder) {
		this.gnumDisplayOrder = gnumDisplayOrder;
	}
	public Integer getGnumEntryBy() {
		return gnumEntryBy;
	}
	public void setGnumEntryBy(Integer gnumEntryBy) {
		this.gnumEntryBy = gnumEntryBy;
	}
	public Date getGdtEntryDate() {
		return gdtEntryDate;
	}
	public void setGdtEntryDate(Date gdtEntryDate) {
		this.gdtEntryDate = gdtEntryDate;
	}
	public String getGstrUrl() {
		return gstrUrl;
	}
	public void setGstrUrl(String gstrUrl) {
		this.gstrUrl = gstrUrl;
	}
	public Integer getGnumIsvalid() {
		return gnumIsvalid;
	}
	public void setGnumIsvalid(Integer gnumIsvalid) {
		this.gnumIsvalid = gnumIsvalid;
	}
	public Integer getGnumApplicationType() {
		return gnumApplicationType;
	}
	public void setGnumApplicationType(Integer gnumApplicationType) {
		this.gnumApplicationType = gnumApplicationType;
	}
	public Integer getGnumModuleId() {
		return gnumModuleId;
	}
	public void setGnumModuleId(Integer gnumModuleId) {
		this.gnumModuleId = gnumModuleId;
	}
	public Integer getGnumIsportal() {
		return gnumIsportal;
	}
	public void setGnumIsportal(Integer gnumIsportal) {
		this.gnumIsportal = gnumIsportal;
	}
	public String getGstrImageClass() {
		return gstrImageClass;
	}
	public void setGstrImageClass(String gstrImageClass) {
		this.gstrImageClass = gstrImageClass;
	}
	public String getGstrColorClass() {
		return gstrColorClass;
	}
	public void setGstrColorClass(String gstrColorClass) {
		this.gstrColorClass = gstrColorClass;
	}
	public String getLevelOfHierarchy() {
		return levelOfHierarchy;
	}
	public void setLevelOfHierarchy(String levelOfHierarchy) {
		this.levelOfHierarchy = levelOfHierarchy;
	}
	public Integer getGnumOnlineOffline() {
		return gnumOnlineOffline;
	}
	public void setGnumOnlineOffline(Integer gnumOnlineOffline) {
		this.gnumOnlineOffline = gnumOnlineOffline;
	}
	public Integer getGnumOfflineMenuId() {
		return gnumOfflineMenuId;
	}
	public void setGnumOfflineMenuId(Integer gnumOfflineMenuId) {
		this.gnumOfflineMenuId = gnumOfflineMenuId;
	}
	public String getGstrUsmFileName() {
		return gstrUsmFileName;
	}
	public void setGstrUsmFileName(String gstrUsmFileName) {
		this.gstrUsmFileName = gstrUsmFileName;
	}
	public String getGstrParentName() {
		return gstrParentName;
	}
	public void setGstrParentName(String gstrParentName) {
		this.gstrParentName = gstrParentName;
	}
	public Long getRootMenu() {
		return rootMenu;
	}
	public void setRootMenu(Long rootMenu) {
		this.rootMenu = rootMenu;
	}
	public String getIntermediateMenu() {
		return intermediateMenu;
	}
	public void setIntermediateMenu(String intermediateMenu) {
		this.intermediateMenu = intermediateMenu;
	}
	public String getGstrModuleName() {
		return gstrModuleName;
	}
	public void setGstrModuleName(String gstrModuleName) {
		this.gstrModuleName = gstrModuleName;
	}
	public Long getGnumModuleLong() {
		return gnumModuleLong;
	}
	public void setGnumModuleLong(Long gnumModuleLong) {
		this.gnumModuleLong = gnumModuleLong;
	}
	public Integer getGnumVersionNo() {
		return gnumVersionNo;
	}
	public void setGnumVersionNo(Integer gnumVersionNo) {
		this.gnumVersionNo = gnumVersionNo;
	}
	public Integer getGnumSeatid() {
		return gnumSeatid;
	}
	public void setGnumSeatid(Integer gnumSeatid) {
		this.gnumSeatid = gnumSeatid;
	}
	public Integer getGnumHospitalCode() {
		return gnumHospitalCode;
	}
	public void setGnumHospitalCode(Integer gnumHospitalCode) {
		this.gnumHospitalCode = gnumHospitalCode;
	}
	public String getManualFile() {
		return manualFile;
	}
	public void setManualFile(String manualFile) {
		this.manualFile = manualFile;
	}
	private Long gnumParentId;
	private String gstrMenuName;
	private String gstrMenuclassId;
	private Integer gnumMenuLevel;
	private Integer gnumDisplayOrder;
	private Integer gnumEntryBy;
	private Date gdtEntryDate;
	private String gstrUrl;
	
	private Integer gnumIsvalid;
	private Integer gnumApplicationType;
	private Integer gnumModuleId;
	private Integer gnumIsportal;
	private String gstrImageClass;
	private String gstrColorClass;
	private String levelOfHierarchy;
	private Integer gnumOnlineOffline; 
	private Integer gnumOfflineMenuId;
	private String gstrUsmFileName;
	
	
	private String gstrParentName;
	private Long rootMenu;
	private String intermediateMenu;
	
	private String gstrModuleName;
	
	private Long gnumModuleLong ;	
	private Integer gnumVersionNo; 
	
	private Integer gnumSeatid;
	private Integer gnumHospitalCode;
	private String manualFile;

}
