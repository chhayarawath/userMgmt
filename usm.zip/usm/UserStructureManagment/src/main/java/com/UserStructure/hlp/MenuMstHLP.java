package com.UserStructure.hlp;

import java.util.List;


import org.springframework.stereotype.Component;
import org.thymeleaf.util.StringUtils;

import com.UserStructure.Bean.MenuMstBean;



@Component
public class MenuMstHLP {
	
	public String getAllMenuList(List<MenuMstBean> MenuList) {

		StringBuffer result = new StringBuffer("");
		result.append("<table class='table table-striped table-bordered' id='tableListing' > <thead> <tr class='bg-primary'> <th ><input type='checkbox' id='checkAll' /></th> "
					+ "<th key='menu-name'>Menu Name</th> "
					+ "<th key='menu-level'>Menu Level</th> "
					+ "<th key='parent'>Parent</th> "
					+ "<th key='url'>URL</th> "
					+ "<th key='offline-menu'>Offline Menu ID</th> "
					+ "<th key='manual-file-name'>Manual File Name</th> "
					+ "</tr> </thead>  <tbody> ");
		if (MenuList != null && MenuList.size() > 0) {

			for (MenuMstBean Menu : MenuList) {

				
				result.append(" <tr > ");
				result.append("  <td > <input class='checkbox' type='checkbox' name='id' value='"+Menu.toString()+ "' /> </td> ");
				result.append("  <td >" + StringUtils.capitalize(Menu.getGstrMenuName()) + "</td> ");
				result.append("  <td >" + Menu.getGnumMenuLevel() + "</td> ");
				result.append("  <td >" + ( Menu.getGstrParentName() != null ?  StringUtils.capitalize(Menu.getGstrParentName()) : "" ) + "</td> ");
				result.append("  <td >" + (Menu.getGstrUrl() != null ? Menu.getGstrUrl() : "") + "</td> ");
				
				if(Menu.getGnumOfflineMenuId() == null || Menu.getGnumOfflineMenuId() ==0 )
					result.append("  <td>--</td> ");
				else
					result.append("  <td >" +Menu.getGnumOfflineMenuId()+"</td> ");				

				if(Menu.getGstrUsmFileName() == null)
					result.append("  <td>--</td> ");
				else
					result.append("  <td >" +Menu.getGstrUsmFileName()+"</td> ");
				result.append(" </tr> ");

			}
			

		} else {

			result.append(" <tr> <td colspan='4'> <span key='no-record-found'> No Record Found </span> </td>  </tr> ");
		}

		result.append("</tbody></table>");

		return result.toString();

	}
	

}
