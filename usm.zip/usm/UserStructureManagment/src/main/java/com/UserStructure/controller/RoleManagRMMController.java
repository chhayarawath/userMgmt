package com.UserStructure.controller;
//import java.util.List;
//import java.util.stream.Collectors;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.UserStructure.Bean.MenuMstBean;
//import com.UserStructure.Utill.GenericCombo;
//import com.UserStructure.Utill.UsmUtill;
//import com.UserStructure.service.MenuMstService;

@Controller
@RequestMapping("")
public class RoleManagRMMController {

    @GetMapping("/rolemenu")  // Define a valid path for the menu
    public String showMenu() {
        return "rolemenulist";  // Return the name of the Thymeleaf template
    }
}

//@Controller
//public class  RoleManagMMController {
//
//    @Autowired
//    private MenuMstService menuMstService;
//    @Autowired
//    private UsmUtill UsmUtil;
//
//    @GetMapping("/menulist")
//    public ModelAndView getList(@ModelAttribute MenuMstBean menuMstBean, Model model) {
//        List<GenericCombo<Integer, String>> moduleList = menuMstService.getModule(1, menuMstBean).stream()
//            .map(b -> new GenericCombo<>(b.getGnumModuleId(), b.getGstrModuleName()))
//            .collect(Collectors.toList());
//
//        String moduleCombo = UsmUtil.getOptions(
//            moduleList, 
//            menuMstBean.getGnumModuleId()
//        );
//        
//        model.addAttribute("ModuleCombo", moduleCombo);
//        
//        return new ModelAndView("menulist", "MenuMstBean", menuMstBean);
//    }
//}
	

