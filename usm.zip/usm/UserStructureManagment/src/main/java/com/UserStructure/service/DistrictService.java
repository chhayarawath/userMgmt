package com.UserStructure.service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.UserStructure.Bean.CountryBean;
import com.UserStructure.Bean.DistrictBean;
import com.UserStructure.entity.GbltCountryMstImsc;
import com.UserStructure.entity.GbltDistrictMstImsc;
import com.UserStructure.repository.CountryRepository;


@Service
public class DistrictService {

  
    @Autowired
    private DistrictDao districtDao;

    @Autowired
    private CountryRepository countryRepository;
    
    
  
   
    public List<CountryBean> getCountry(Integer isvalid) {
        List<GbltCountryMstImsc> countries = countryRepository.findAllByGnumIsvalid(1);
        return countries.stream().map(this::convertToCountryBean).collect(Collectors.toList());
    }

    private DistrictBean convertToDistrictBean(GbltDistrictMstImsc district) {
        DistrictBean districtBean = new DistrictBean();
        BeanUtils.copyProperties(district, districtBean);
        return districtBean;
    }

    private CountryBean convertToCountryBean(GbltCountryMstImsc country) {
        CountryBean countryBean = new CountryBean();
        BeanUtils.copyProperties(country, countryBean);
        return countryBean;
    }

    public List<DistrictBean> getDistrictList(Integer gnumIsValid) {
        // Get the list of districts based on gnumIsValid
        List<GbltDistrictMstImsc> list = districtRepository.findAllByGnumIsvalid(gnumIsValid);

        // Create a list of DistrictBean objects
        List<DistrictBean> beanList = new ArrayList<>();

        // Loop through each GbltDistrictMstImsc object and set only the required fields
        for (GbltDistrictMstImsc mst : list) {
            DistrictBean bean = new DistrictBean();
            BeanUtils.copyProperties(mst, bean);
            beanList.add(bean);
        }

        // Return the list of DistrictBeans containing only the relevant fields
        return beanList;
    }

    public boolean isDistrictCodeExists(String strDistCode) {
        // Check if the district code exists
        return districtRepository.findBystrDistCode(strDistCode).isPresent();
    }

    public boolean isDistrictNameExists(String strDistName) {
        // Check if the district name exists
        return districtRepository.findBystrDistName(strDistName).isPresent();
    }

    public String saveDistrict(DistrictBean districtBean) {
        // Logic to save the district
        GbltDistrictMstImsc district = new GbltDistrictMstImsc();
        BeanUtils.copyProperties(districtBean, district);
        districtRepository.save(district);

        return "District saved successfully!";
    }
}
