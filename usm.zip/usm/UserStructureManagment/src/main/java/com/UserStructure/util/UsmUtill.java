package com.UserStructure.util;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

@Service
public class UsmUtill {

    private static final Map<String, String> imcsPathMap = new HashMap<>();

    static {
        fetchImcsPathToMap();
    }

    /**
     * Returns combo string
     * <code>&lt;option value='0'&gt;Select Value&lt;/option&gt; </code> based on
     * the provided ComboOption List and defaultOptions
     * 
     * @param defaultOption - 0^Select Value#1^All returns
     *                      <code>&lt;option value='0'&gt;Select Value&lt;/option&gt; &lt;option value='1'&gt;All&lt;/option&gt; </code>
     * @param defaultValue - the value should be selected
     * @return options string
     */
    public static String getGenericOptions(List<GenericCombo<?>> options, Integer selectedValue, GenericCombo<?> defaultOption) {
        StringBuilder html = new StringBuilder();
        html.append("<option value=\"").append(defaultOption.getValue()).append("\">")
            .append(defaultOption.getDisplay()).append("</option>");

        for (GenericCombo<?> option : options) {
            html.append("<option value=\"").append(option.getValue()).append("\"");
            if (Objects.equals(option.getValue(), selectedValue)) {
                html.append(" selected");
            }
            html.append(">").append(option.getDisplay()).append("</option>");
        }

        return html.toString();
    }

    public String getOptionsDisplayCSS(final List<ComboOption> list, final String defaultOption,
            final String defaultValue) {

        StringBuilder result = new StringBuilder();

        if (defaultOption != null && !defaultOption.isEmpty() && defaultOption.contains("^")) {
            result.append(new ArrayList<>(Arrays.asList(defaultOption.split("#"))).stream()
                .map(s -> "<option class='lessPadding' value='" + s.split("\\^")[0] + "' "
                        + (s.split("\\^")[0].equals(defaultValue) ? "selected" : "") + ">" + s.split("\\^")[1]
                        + "</option>")
                .collect(Collectors.joining()));
        } else {
            if (list == null) {
                result.append("<option class='lessPadding' value='0'>Select Value</option>");
            }
        }

        if (list != null) {
            for (ComboOption comboOption : list) {
                result.append("<option class='lessPadding' value='" + comboOption.getValue() + "' "
                        + (comboOption.getValue().equals(defaultValue) ? "selected" : "") + ">"
                        + comboOption.getDisplay() + "</option>");
            }
            list.clear();
        }
        return result.toString();
    }

    /**
     * Returns combo string
     * <code>&lt;option value='0'&gt;Select Value&lt;/option&gt; </code> based on
     * the provided defaultOptions
     * 
     * @param defaultOption - 0^Select Value#1^All returns
     *                      <code>&lt;option value='0'&gt;Select Value&lt;/option&gt; &lt;option value='1'&gt;All&lt;/option&gt; </code>
     * @param defaultValue - the value should be selected
     * @return - options string
     */
    public String getOptions(final String defaultOption, final String defaultValue) {

        StringBuilder result = new StringBuilder();

        if (defaultOption != null && !defaultOption.isEmpty() && defaultOption.contains("^")) {
            result.append(new ArrayList<>(Arrays.asList(defaultOption.split("#"))).stream()
                .map(s -> "<option value='" + s.split("\\^")[0] + "' "
                        + (s.split("\\^")[0].equals(defaultValue) ? "selected" : "") + ">" + s.split("\\^")[1]
                        + "</option>")
                .collect(Collectors.joining()));
        } else {
            result.append("<option value='0'>Select Value</option>");
        }

        return result.toString();
    }

    /**
     * Returns the given amount in Decimal Format.
     * 
     * @param amount      amount value in int, float, double.
     * @param decimalSize Size of the decimal in integer, 3 will convert the amount
     *                    in 0.000 Format. Negative integer or zero will return the
     *                    amount without Decimals.
     * @return amount by converting the value in decimal Format by considering the
     *         decimalSize.
     * @throws Exception the exception
     * @see #getAmountWithDecimal(String, int)
     */
    public String getAmountWithDecimal(final double amount, final int decimalSize) {

        StringBuilder strPattern = new StringBuilder();

        DecimalFormat df = new DecimalFormat();

        if (decimalSize > 0) {
            strPattern.append(".");
            for (int i = 1; i <= decimalSize; i++) {
                strPattern.append("0");
            }
        } else {
            strPattern.append("0");
        }

        df.applyPattern(strPattern.toString());

        String strAmt = amount == 0 ? "0" + strPattern.toString() : df.format(amount);

        return strAmt;
    }

    // This method needs to be defined or imported
    private static void fetchImcsPathToMap() {
        // Implementation here
    }
}
