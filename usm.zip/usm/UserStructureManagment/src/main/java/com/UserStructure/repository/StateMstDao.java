package com.UserStructure.repository;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.UserStructure.Bean.CountryBean;
import com.UserStructure.entity.GbltCountryMstImsc;
import com.UserStructure.entity.GbltStateMstImsc;
import com.UserStructure.service.StateMstService;
import jakarta.transaction.Transactional;

@Repository
public interface StateMstDao extends JpaRepository<GbltStateMstImsc, Integer> {

	// Using @Query annotation to define a custom query
    @Query("SELECT c FROM GbltCountryMstImsc c WHERE c.gnumIsvalid = 1 ORDER BY c.gnumCountrycode")
    List<GbltCountryMstImsc> findAllValidCountries();
    
//===========================================================================================================    

 // Custom query to find states based on multiple filters
    @Query("SELECT s FROM GbltStateMstImsc s WHERE s.gnumHospitalCode = :hospitalCode "
         + "AND (:countryCode IS NULL OR s.gnumCountrycode = :countryCode) "
         + "AND (:isValid IS NULL OR s.gnumIsvalid = :isValid) "
         + "ORDER BY s.gstrStatename")
    List<GbltStateMstImsc> findAllByFilters(
            @Param("hospitalCode") Integer hospitalCode,
            @Param("countryCode") Integer countryCode,
            @Param("isValid") Integer isValid);
    
//===========================================================================================================    
    // Insert new state
    @Modifying
    @Transactional
    default int createState(GbltStateMstImsc state) {
        state.setGnumIsvalid(1);
        save(state); // Save the state using JPA save method
        return 1;
    }
   

//===========================================================================================================    
    @Transactional
    @Modifying
    @Query("UPDATE GbltStateMstImsc s SET s.gnumIsvalid = :validity WHERE s.gnumStatecode IN :stateCodes")
    void updateStatesValidity(@Param("stateCodes") List<Long> stateCodes, @Param("validity") boolean validity);
   
    
    // Query to check for duplicate state based on hospital code and state name
    @Query("SELECT COUNT(s) FROM GbltStateMstImsc s WHERE s.gnumHospitalCode = :hospitalCode " +
            "AND UPPER(TRIM(s.gstrStatename)) = UPPER(TRIM(:stateName)) " +
            "AND (:gnumStatecode IS NULL OR s.gnumStatecode <> :gnumStatecode)")
    long chkDuplicate(@Param("hospitalCode") Integer hospitalCode,
                      @Param("stateName") String stateName,
                      @Param("gnumStatecode") Integer gnumStatecode);

    // Query to get state details for modification
    @Query("SELECT s FROM GbltStateMstImsc s WHERE s.gnumHospitalCode = :gnumHospitalCode " +
            "AND (:gnumIsvalid IS NULL OR s.gnumIsvalid = :gnumIsvalid) " +
            "AND (:gnumCountrycode IS NULL OR s.gnumCountrycode = :gnumCountrycode) " +
            "AND (:gnumStatecode IS NULL OR s.gnumStatecode = :gnumStatecode)")
    GbltStateMstImsc getStateDetail(@Param("gnumHospitalCode") Integer gnumHospitalCode,
                                    @Param("gnumIsvalid") Integer gnumIsvalid,
                                    @Param("gnumCountrycode") Integer gnumCountrycode,
                                    @Param("gnumStatecode") Integer gnumStatecode);

 // Update state details
    @Modifying
    @Transactional
    @Query("UPDATE GbltStateMstImsc g SET g.gstrStateshort = :gstrStateshort, " +
           "g.gstrStatename = :gstrStatename, gnumIsvalid = :gnumIsvalid, " +
           "gdtLstmodDate = CURRENT_TIMESTAMP, gnumLstmodSeatid = :gnumLstmodSeatid, " +
           "gnumIsDefaultUt = :gnumIsDefaultUt WHERE g.gnumHospitalCode = :gnumHospitalCode " +
           "AND g.gnumCountrycode = :gnumCountrycode AND g.gnumStatecode = :gnumStatecode")
    int updateState(@Param("gnumHospitalCode") Integer hospitalCode,
                    @Param("gnumCountrycode") Integer countryCode,
                    @Param("gnumStatecode") Integer stateCode,
                    @Param("gstrStateshort") String stateShort,
                    @Param("gstrStatename") String stateName,
                    @Param("gnumIsvalid") Integer isValid,
                    @Param("gnumLstmodSeatid") Integer seatId,
                    @Param("gnumIsDefaultUt") Integer isDefaultUt);
 

    
//===========================================================================================================     
    // Custom method to get the current database timestamp using JPA
    @Query(value = "SELECT CURRENT_TIMESTAMP", nativeQuery = true)
    Date getDSTimeStamp();
//======================================view data ===========================================================    
    
    Optional<GbltStateMstImsc> findByGnumStatecode(Integer gnumStatecode);
//===========================================================================================================      
    
    @Modifying
    @Transactional
    @Query("UPDATE GbltStateMstImsc s SET s.gnumIsvalid = 0 WHERE s.gnumHospitalCode = :gnumHospitalCode AND s.gnumCountrycode = :gnumCountrycode AND s.gnumStatecode IN :stateCodes")
    int deleteStates(Integer gnumHospitalCode, Integer gnumCountrycode, List<Integer> stateCodes);

//===================================================================================================================

   
}	

