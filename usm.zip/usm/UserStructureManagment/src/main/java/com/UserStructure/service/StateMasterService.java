package com.UserStructure.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.UserStructure.Bean.CountryBean;
import com.UserStructure.Bean.StateMstBean;
import com.UserStructure.entity.GbltCountryMstImsc;
import com.UserStructure.entity.GbltStateMstImsc;
import com.UserStructure.repository.CountryRepository;
import com.UserStructure.repository.StateMasterRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Service
@Transactional
public class StateMasterService {

    @Autowired
    private StateMasterRepository stateRepository;
    
    @Autowired
    private CountryRepository countryRepository;

    // ======================= Getting State List ===========================
    public List<StateMstBean> getStateList(Integer gnumIsValid) {
        List<GbltStateMstImsc> list = stateRepository.findAllByGnumIsvalid(gnumIsValid); 
        List<StateMstBean> beanList = new ArrayList<>();
        
        // Using Streams for better readability
        beanList = list.stream().map(mst -> {
            StateMstBean bean = new StateMstBean();
            BeanUtils.copyProperties(mst, bean);
            return bean;
        }).toList();
        
        return beanList;
    }

    public boolean isStateCodeExists(Integer stateCode) {
        return stateRepository.findByGnumStatecode(stateCode).isPresent();
    }

    public boolean isStateNameExists(String stateName) {
        return stateRepository.findByGstrStatename(stateName).isPresent(); // Use the repository method
    }

    public String saveState(StateMstBean stateMstBean) {
        try {
            // Check if state name or code already exists
            if (isStateNameExists(stateMstBean.getGstrStatename())) {
                return "State name already exists!";
            }

            if (isStateCodeExists(stateMstBean.getGnumStatecode())) {
                return "State code already exists!";
            }

            // Proceed with saving the state
            GbltStateMstImsc stateEntity = new GbltStateMstImsc();
            BeanUtils.copyProperties(stateMstBean, stateEntity);

            stateEntity.setGdtEntrydate(new Date()); // Set entry date
            stateEntity.setGnumIsvalid(1); // Assuming new states are valid

            // Access the HttpServletRequest via RequestContextHolder
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            Integer hospitalCode = (Integer) request.getAttribute("gnumHospitalCode");
            if (hospitalCode == null) {
                hospitalCode = 999; // Example default value
            }

            stateEntity.setGnumHospitalCode(hospitalCode); // Set hospital code

            // Save to the database
            stateRepository.save(stateEntity);
            return "State saved successfully!";
        } catch (Exception e) {
            e.printStackTrace();
            return "Error saving state: " + e.getMessage();
        }
    }

    public boolean deleteStatesByIds(List<Integer> stateIds) {
        try {
            stateRepository.deleteByGnumStatecodeIn(stateIds); // Use correct method name
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<CountryBean> getCountryList(Integer gnumIsValid) {
        List<GbltCountryMstImsc> countryList = countryRepository.findAllByGnumIsvalid(gnumIsValid);
        List<CountryBean> beanList = new ArrayList<>();
        
        // Using Streams for conversion
        beanList = countryList.stream().map(country -> {
            CountryBean bean = new CountryBean();
            BeanUtils.copyProperties(country, bean);
            return bean;
        }).toList();
        
        return beanList;
    }

    public GbltStateMstImsc getStateByCode(Integer stateCode) {
        return stateRepository.findByGnumStatecode(stateCode).orElse(null);
    }
}
