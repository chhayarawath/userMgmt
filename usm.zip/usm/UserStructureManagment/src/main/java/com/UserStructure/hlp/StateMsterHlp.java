package com.UserStructure.hlp;

import com.UserStructure.Bean.StateMstBean;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.List;

@Component
public class StateMsterHlp {

	public String getStateList(List<StateMstBean> stateMst) {
        StringBuilder result = new StringBuilder();
        result.append("<form action='/deleteState' method='post'>")
              .append("<table class='table table-striped table-bordered' id='tableListing'>")
              .append("<thead><tr class='bg-primary'>")
              .append("<th><input type='checkbox' id='checkAll' /></th>")
              .append("<th key='state-name'>State Name</th>")
              .append("<th key='state-short-name'>State Short Name</th>")
              .append("<th key='ut'>UT</th>")
              .append("</tr></thead><tbody>");

        if (stateMst != null && !stateMst.isEmpty()) {
            for (StateMstBean obj : stateMst) {
                String encodedStateCode = Base64.getEncoder()
                                                .encodeToString(String.valueOf(obj.getGnumStatecode()).getBytes());

                // Handling null value for gnumIsDefaultUt
                Integer isDefaultUt = obj.getGnumIsDefaultUt();
                String utDisplay = (isDefaultUt != null && isDefaultUt == 1) ? "Yes" : "No";

                result.append("<tr>")
                .append("<td><input class='checkbox' type='checkbox' name='selectedStates' value='")
                .append(encodedStateCode)
                .append("' onchange='checkBoxChange();' /></td>") // Fixed line
                .append("<td>").append(obj.getGstrStatename()).append("</td>")
                .append("<td>").append(obj.getGstrStateshort()).append("</td>")
                .append("<td>").append(utDisplay).append("</td>")
                .append("</tr>");

            }
        } else {
            result.append("<tr><td colspan='4'>No records found!</td></tr>");
        }

        result.append("</tbody></table></form>");
        return result.toString();
    }
}
