
  package com.UserStructure.hlp;
  

import java.util.List;

import org.springframework.stereotype.Component;

import com.UserStructure.Bean.DistrictBean;
  
  
  @Component
  public class DistrictHlp {
	  	  
		public String getDistrictList(List<DistrictBean> districtList) {
			StringBuffer result = new StringBuffer("");
			result.append("<table class='table table-striped table-bordered' id='tableListing' > "
					+ "<thead><tr class='bg-primary'> "
					+ "<th><input type='checkbox' id='checkAll' /></th> "
					+ "<th key='state-name'> District Name </th> "
					+ "<th key='state-short-name'> District Short Name </th>" 					
					+ "</tr></thead><tbody> ");
			if (districtList != null && districtList.size() > 0) {

				for (DistrictBean obj : districtList) {

					result.append(" <tr > ");
					result.append("  <td > <input class='checkbox' type='checkbox' name='id' value='"
							+ 
									(obj.getNumDistId() + "," + obj.getGnumSlno()).getBytes() + "' /> </td> ");
					result.append("  <td >"+obj.getStrDistName()+  "</td> ");
					result.append("  <td >" +obj.getStrDistStName()  + "</td> ");
					/*if(obj.getStrZoneName()==null)
						result.append("  <td >" +"-"  + "</td> ");
					else
					result.append("  <td >" +obj.getStrZoneName()  + "</td> "); */
					
					result.append(" </tr> ");
				}

			} else {
				
				result.append(" <tr> <td colspan='4'> <span key='no-record-found'> No Record Found </span> </td>  </tr> ");				
			}

			result.append("</tbody></table>");

			return result.toString();		
		}} 
 