package com.UserStructure.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.UserStructure.Bean.DistrictBean;
import com.UserStructure.hlp.DistrictHlp;
import com.UserStructure.service.DistrictService;
import com.UserStructure.service.StateMstService;
import com.UserStructure.util.GenericCombo;
import com.UserStructure.util.UsmUtill;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping(" ")
public class DistrictController {

    @Autowired
    private DistrictHlp districtHlp;

    @Autowired
    private DistrictService districtService;

    @Autowired
    private StateMstService stateMstService;

    @Autowired
    private HttpSession session; // Inject the HttpSession

    @RequestMapping("/getDistrict")
    public ModelAndView getDistrict(@ModelAttribute DistrictBean districtBean, Model model) {
        String countryCombo = UsmUtill.getGenericOptions(
                districtService.getCountry(1).stream()
                        .map(b -> new GenericCombo<>(b.getGnumCountrycode(), b.getGstrCountryname()))
                        .collect(Collectors.toList()),
                districtBean.getGnumCountrycode(), // Ensure this is an Integer
                GenericCombo.defaultOptionInteger()); // Use a default option

        model.addAttribute("CountryCombo", countryCombo);
        districtBean.setStateCode(districtBean.getGnumStatecode());

        return new ModelAndView("districtMstList", "districtBean", districtBean);
    }

    @RequestMapping("/getState")
    public @ResponseBody String getState(@ModelAttribute DistrictBean districtBean) {
        Integer countryCode = districtBean.getGnumCountrycode(); // Ensure this is set
        Integer isValid = 1; // Assuming you want to filter valid states

        String stateCombo = UsmUtill.getGenericOptions(
                stateMstService.getStateList(session, countryCode, isValid).stream()
                        .map(b -> new GenericCombo<>(b.getGnumStatecode(), b.getGstrStatename()))
                        .collect(Collectors.toList()),
                districtBean.getGnumStatecode(), // Ensure this is of the correct type
                GenericCombo.defaultOptionInteger()); // Use a default option

        return stateCombo;
    }


    // Displays the page with the district list
    @GetMapping("/districtMstList")
    public ModelAndView showMenu(@ModelAttribute DistrictBean districtBean, Model model) {
        System.out.println("===================Show your districts======================");

        // Fetching the district list
        List<DistrictBean> districtList = districtService.getDistrictList(1);

        // Log the size of the list
        System.out.println(districtList.size() + " size");

        // Iterate and print each district object (optional for debugging)
        districtList.forEach(district -> System.out.println(district.toString()));

        // Generate HTML content using DistrictHlp
        String districtTable = districtHlp.getDistrictList(districtList);

        // Add the HTML string to the model
        model.addAttribute("districtTable", districtTable);

        // Return the view with the model data
        return new ModelAndView("districtMstList", "DistrictBean", districtBean);
    }

    // API to return the district list in JSON format
    @RequestMapping(value = "/getdistList")
    public @ResponseBody String getDistrictList1(@ModelAttribute DistrictBean districtBean, Model model) {
        System.out.println("Calling to get district list...");

        // Fetch the district list
        List<DistrictBean> list = districtService.getDistrictList(1);

        // Log the fetched list
        System.out.println("District list: " + list);

        // Return the list as a string (convert using helper class)
        return districtHlp.getDistrictList(list);
    }

    @RequestMapping("/addDistrict")
    public ModelAndView addDistrict(@ModelAttribute DistrictBean districtBean, Model model) {
        System.out.println("=============test==================");
        districtBean.setIsModify(0); // Setting this to indicate it's an add operation
        return new ModelAndView("districtForm", "DistrictBean", districtBean); // Return the view with model
    }

    @PostMapping("/save")
    public ModelAndView saveDistrict(@ModelAttribute DistrictBean districtBean, Model model) {
        return new ModelAndView("districtForm", "districtBean", districtBean);
    }

}
