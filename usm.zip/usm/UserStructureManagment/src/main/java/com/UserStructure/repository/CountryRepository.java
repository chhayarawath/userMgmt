package com.UserStructure.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.UserStructure.entity.GbltCountryMstImsc;
import com.UserStructure.entity.GbltDistrictMstImsc;

@Repository
public interface CountryRepository  extends JpaRepository<GbltCountryMstImsc, Integer> {

	 List<GbltCountryMstImsc> findAllByGnumIsvalid(Integer gnumIsvalid);
}
