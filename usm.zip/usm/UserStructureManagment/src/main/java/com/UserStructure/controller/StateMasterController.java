package com.UserStructure.controller;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.UserStructure.Bean.CountryBean;
import com.UserStructure.Bean.StateMstBean;
import com.UserStructure.entity.GbltStateMstImsc;
import com.UserStructure.hlp.StateMsterHlp;
import com.UserStructure.service.StateMasterService;
import jakarta.servlet.http.HttpServletRequest;

/*@Controller
@RequestMapping("/")*/
public class StateMasterController {

    @Autowired
    private StateMsterHlp stateMsterHlp;

    @Autowired
    private StateMasterService stateMasterService;

    @Autowired
    private HttpServletRequest request;
    
//==============================================================get Index Page
    @GetMapping("/index")
    public ModelAndView showMenu(@ModelAttribute StateMstBean stateMstBean, Model model) {
        // Fetch the state list
        List<StateMstBean> stateList = stateMasterService.getStateList(1);
        model.addAttribute("stateList", stateList);

        // Fetch the country list
        List<CountryBean> countries = stateMasterService.getCountryList(1);
        model.addAttribute("countries", countries); // Add country list to the model

        // Return Thymeleaf template with both state and country lists
        return new ModelAndView("stateMst", "stateMstBean", stateMstBean);
    }

//==============================================================Getting state list in index page
    @RequestMapping("getList1")
    public @ResponseBody String getList1(@ModelAttribute StateMstBean menuMstBean, ModelMap model) {
        List<StateMstBean> list = stateMasterService.getStateList(1);
        return stateMsterHlp.getStateList(list);
    }

//================================================================ Add state form
    @RequestMapping("addState")
    public ModelAndView addState(@ModelAttribute StateMstBean stateMstBean, Model model) {
        stateMstBean.setIsModify(0);
        return new ModelAndView("addStateForm", "stateMstBean", stateMstBean);
    }

//================================================================ Save state form
    @PostMapping("/saveState")
    public ModelAndView saveState(@ModelAttribute StateMstBean stateMstBean, Model model) {
        Integer stateCode = stateMstBean.getGnumStatecode();
        String stateName = stateMstBean.getGstrStatename();

// Check for duplicate state code and name
        if (stateMasterService.isStateCodeExists(stateCode)) {
            model.addAttribute("ERROR_MESSAGE", "State code already exists! Please use a unique code.");
            return new ModelAndView("addStateForm", "stateMstBean", stateMstBean);
        }
        if (stateMasterService.isStateNameExists(stateName)) {
            model.addAttribute("ERROR_MESSAGE", "State name already exists! Please use a unique name.");
            return new ModelAndView("addStateForm", "stateMstBean", stateMstBean);
        }

        String saveResult = stateMasterService.saveState(stateMstBean);
        if ("State saved successfully!".equals(saveResult)) {
            model.addAttribute("SUCCESS_MESSAGE", saveResult);
            return new ModelAndView("addStateForm", "stateMstBean", new StateMstBean());
        } else {
            model.addAttribute("ERROR_MESSAGE", saveResult);
            return new ModelAndView("addStateForm", "stateMstBean", stateMstBean);
        }
    }

// =====================================================Delete state 
 /*   @PostMapping("deleteState")
    public ModelAndView deleteState(@RequestParam("selectedStates") List<String> selectedStates, Model model) {
        System.out.println("Deleting states: " + selectedStates);

        // Decode the Base64 encoded IDs
        List<Integer> stateIds = selectedStates.stream()
            .map(id -> Integer.valueOf(new String(Base64.getDecoder().decode(id)))) // Convert Base64 to Integer
            .collect(Collectors.toList());

        // Delete the states
        boolean result = stateMasterService.deleteStatesByIds(stateIds);

        if (result) {
            model.addAttribute("SUCCESS_MESSAGE", stateIds.size() + " State(s) successfully deleted!");
            return new ModelAndView("redirect:/index");
        } else {
            model.addAttribute("ERROR_MESSAGE", "State(s) deletion failed!");
            return new ModelAndView("stateMst");
        }
    }*/

// ==================================================Controller for getting state details in Modal on view button click
    @GetMapping("/viewState")
    @ResponseBody
    public String viewState(@RequestParam("stateCode") Integer stateCode) {
        GbltStateMstImsc state = stateMasterService.getStateByCode(stateCode);

        if (state != null) {
            return "<table id='viewTableListing' class='table-bordered' width='100%'>"
                    + "<tr><td><strong>State Name</strong></td><td>" + state.getGstrStatename() + "</td></tr>"
                    + "<tr><td><strong>State Short Name</strong></td><td>" + state.getGstrStateshort() + "</td></tr>"
                    + "<tr><td><strong>UT</strong></td><td>" + (state.getGnumIsDefaultUt() == 1 ? "Yes" : "No") + "</td></tr>"
                    + "</table>";
        } else {
            return "<p>State not found!</p>";
        }
    }
}
