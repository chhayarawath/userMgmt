package com.UserStructure.util;

import java.util.Objects;

public class GenericCombo<T> {
	
	private T value;   // The value for the option
	private String display; // The display text for the option

	// Constructor to initialize the value and display
	public GenericCombo(T value, String display) {
		super();
		Objects.requireNonNull(value, "Value cannot be null"); // Ensures value is not null
		this.value = value;
		this.display = display;
	}

	// Getter for value
	public T getValue() {
		return value;
	}

	// Getter for display
	public String getDisplay() {
		return display;
	}
	
	// Default option methods
	public static GenericCombo<Integer> defaultOptionInteger() {
		return new GenericCombo<>(0, "Select Value");
	}
	
	public static GenericCombo<String> defaultOptionString() {
		return new GenericCombo<>("", "Select Value");
	}
	
	public static GenericCombo<Long> defaultOptionLong() {
		return new GenericCombo<>(0L, "Select Value");
	}
	
	public static GenericCombo<Integer> allOptionInteger() {
		return new GenericCombo<>(0, "All");
	}
	
	public static GenericCombo<String> allOptionString() {
		return new GenericCombo<>("0", "All");
	}
	
	public static GenericCombo<Long> allOptionLong() {
		return new GenericCombo<>(0L, "All");
	}
}
