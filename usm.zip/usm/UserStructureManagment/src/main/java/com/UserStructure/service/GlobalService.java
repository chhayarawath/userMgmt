/*
 * package com.UserStructure.service; import java.text.ParseException; import
 * java.text.SimpleDateFormat; import java.util.ArrayList; import
 * java.util.Calendar; import java.util.Date; import java.util.List; import
 * java.util.Map; import java.util.function.Function; import
 * java.util.function.Predicate;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.stereotype.Service; import
 * org.springframework.transaction.annotation.Transactional;
 * 
 * import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap; import
 * usm.dao.GlobalDao; import usm.dao.HsttConfigDtlDAO; import usm.util.UsmUtil;
 * 
 * @Transactional
 * 
 * @Service public class GlobalService {
 * 
 * @Autowired private GlobalDao globalDao;
 * 
 * @Autowired private UsmUtil usmUtil;
 * 
 * @Autowired private HsttConfigDtlDAO configDtlDAO;
 * 
 * public String getDSDate(String dtFormat) { return
 * globalDao.getDSDate(dtFormat); }
 * 
 * public Date getDSDate() { return globalDao.getDSDate(); }
 * 
 * public Date getDSTimeStamp() { return globalDao.getDSTimeStamp(); }
 * 
 * public List<String> getFinancialYearFromDB(int mode) { List<String> fy = new
 * ArrayList<>(); Date d = globalDao.getDSDate(); Calendar cal =
 * Calendar.getInstance(); cal.setTime(d); int year = cal.get(Calendar.YEAR);
 * int month = cal.get(Calendar.MONTH);
 * 
 * String currentFinancialYear; int currentYear;
 * 
 * if (month <= 2) { currentFinancialYear = (year - 1) + " - " + year;
 * currentYear = year - 1; } else { currentFinancialYear = year + " - " + (year
 * + 1); currentYear = year + 1; }
 * 
 * fy.add(currentFinancialYear);
 * 
 * switch (mode) { case 2: fy.add(0, (currentYear - 1) + " - " + currentYear);
 * break; case 3: fy.add(currentYear + " - " + (currentYear + 1)); break; }
 * 
 * return fy; }
 * 
 * public String getCurrentFinancialYear() { return
 * getFinancialYearFromDB(1).get(0); }
 * 
 * public List<String> getFinancialYear(int mode, Date currentDate) {
 * List<String> fy = new ArrayList<>(); SimpleDateFormat sdf = new
 * SimpleDateFormat("dd-MMM-yyyy"); Calendar cal = Calendar.getInstance();
 * cal.setTime(currentDate); int year = cal.get(Calendar.YEAR); int month =
 * cal.get(Calendar.MONTH);
 * 
 * String currentFinancialYear; String lastFinancialYear; Date
 * lastFinancialDate; Date currentFinancialDate;
 * 
 * try { if (month <= 2) { currentFinancialYear = (year - 1) + " - " + year;
 * lastFinancialDate = sdf.parse("31-Mar-" + (year - 1)); currentFinancialDate =
 * sdf.parse("01-Apr-" + year); } else { currentFinancialYear = year + " - " +
 * (year + 1); lastFinancialDate = sdf.parse("31-Mar-" + year);
 * currentFinancialDate = sdf.parse("01-Apr-" + (year + 1)); }
 * 
 * fy.add(currentFinancialYear);
 * 
 * if (mode == 2) { cal.setTime(lastFinancialDate); year =
 * cal.get(Calendar.YEAR); lastFinancialYear = (year - 1) + " - " + year;
 * fy.clear(); fy.add(lastFinancialYear); fy.add(currentFinancialYear); }
 * 
 * if (mode == 3) { cal.setTime(currentFinancialDate); year =
 * cal.get(Calendar.YEAR); lastFinancialYear = year + " - " + (year + 1);
 * fy.clear(); fy.add(currentFinancialYear); fy.add(lastFinancialYear); } }
 * catch (ParseException e) { // Handle parse exceptions e.printStackTrace(); }
 * 
 * return fy; }
 * 
 * public String getFinancialDateFromDB() { SimpleDateFormat sdf = new
 * SimpleDateFormat("dd-MMM-yyyy"); Date d = globalDao.getDSDate(); Calendar cal
 * = Calendar.getInstance(); cal.setTime(d); int year = cal.get(Calendar.YEAR);
 * int month = cal.get(Calendar.MONTH);
 * 
 * Date startFinancialDate; Date endFinancialDate;
 * 
 * try { if (month <= 2) { startFinancialDate = sdf.parse("01-Apr-" + (year -
 * 1)); endFinancialDate = sdf.parse("31-Mar-" + year); } else {
 * startFinancialDate = sdf.parse("01-Apr-" + year); endFinancialDate =
 * sdf.parse("31-Mar-" + (year + 1)); } return sdf.format(startFinancialDate) +
 * "^" + sdf.format(endFinancialDate); } catch (ParseException e) { // Handle
 * parse exceptions e.printStackTrace(); return ""; } }
 * 
 * public String getFinancialDate(Date currentDate) { SimpleDateFormat sdf = new
 * SimpleDateFormat("dd-MMM-yyyy"); Calendar cal = Calendar.getInstance();
 * cal.setTime(currentDate); int year = cal.get(Calendar.YEAR); int month =
 * cal.get(Calendar.MONTH);
 * 
 * Date startFinancialDate; Date endFinancialDate;
 * 
 * try { if (month <= 2) { startFinancialDate = sdf.parse("01-Apr-" + (year -
 * 1)); endFinancialDate = sdf.parse("31-Mar-" + year); } else {
 * startFinancialDate = sdf.parse("01-Apr-" + year); endFinancialDate =
 * sdf.parse("31-Mar-" + (year + 1)); } return sdf.format(startFinancialDate) +
 * "^" + sdf.format(endFinancialDate); } catch (ParseException e) { // Handle
 * parse exceptions e.printStackTrace(); return ""; } }
 * 
 * public Date getFinancialStartDate(String financialYear) { String year =
 * financialYear.split("-")[0].trim(); SimpleDateFormat sdf = new
 * SimpleDateFormat("dd-MMM-yyyy");
 * 
 * try { return sdf.parse("01-Apr-" + year); } catch (ParseException e) {
 * e.printStackTrace(); return null; } }
 * 
 * public Date getCurrentFinancialStartDate() { String year =
 * getFinancialYearFromDB(1).get(0).split("-")[0].trim(); SimpleDateFormat sdf =
 * new SimpleDateFormat("dd-MMM-yyyy");
 * 
 * try { return sdf.parse("01-Apr-" + year); } catch (ParseException e) {
 * e.printStackTrace(); return null; } }
 * 
 * public Date getFinancialEndDate(String financialYear) { String year =
 * financialYear.split("-")[1].trim(); SimpleDateFormat sdf = new
 * SimpleDateFormat("dd-MMM-yyyy");
 * 
 * try { return sdf.parse("31-Mar-" + year); } catch (ParseException e) {
 * e.printStackTrace(); return null; } }
 * 
 * public Date getCurrentFinancialEndDate() { String year =
 * getFinancialYearFromDB(1).get(0).split("-")[1].trim(); SimpleDateFormat sdf =
 * new SimpleDateFormat("dd-MMM-yyyy");
 * 
 * try { return sdf.parse("31-Mar-" + year); } catch (ParseException e) {
 * e.printStackTrace(); return null; } }
 * 
 * public Integer getQuater(String financialYear) { Integer currentYear =
 * Integer.valueOf(getDSDate("yyyy")); String[] finYear =
 * financialYear.split("\\-");
 * 
 * if (Integer.parseInt(finYear[1].trim()) == currentYear) { return 4; } else if
 * (Integer.parseInt(finYear[0].trim()) == currentYear) { Integer currentMonth =
 * Integer.valueOf(getDSDate("MM")); return currentMonth > 3 ?
 * usmUtil.getCurrentQuarter(new SimpleDateFormat("dd-MM-yyyy").parse("01-" +
 * currentMonth + "-" + finYear[0].trim())) : 1; }
 * 
 * return 0; }
 * 
 * public Date getDOBFromAge(String patientUnit, int age) { Date referenceDate =
 * globalDao.getDSDate(); Calendar c = Calendar.getInstance();
 * c.setTime(referenceDate);
 * 
 * switch (patientUnit) { case "3": // Days c.add(Calendar.DATE, -age); break;
 * case "2": // Months c.add(Calendar.MONTH, -age); break; case "1": // Years
 * c.add(Calendar.YEAR, -age); break; } return c.getTime(); }
 * 
 * public Date getAgeFromDOB(Date dob) { Date referenceDate =
 * globalDao.getDSDate(); Calendar c = Calendar.getInstance();
 * c.setTime(referenceDate);
 * 
 * long diff = referenceDate.getTime() - dob.getTime();
 * System.out.println("Days: " + diff / (1000 * 60 * 60 * 24));
 * 
 * return c.getTime(); }
 * 
 * public List<String> getFinancialYears(Integer hospitalCode) { List<String>
 * lst = new ArrayList<>();
 * 
 * Integer lastFinPeriod =
 * Integer.valueOf(configDtlDAO.getConfigValue(hospitalCode,
 * "NOTIFICATION_LAST_FINANCIAL_PERIOD", "0")); Integer nxtFinPeriod =
 * Integer.valueOf(configDtlDAO.getConfigValue(hospitalCode,
 * "NOTIFICATION_NEXT_FINANCIAL_PERIOD", "0"));
 * 
 * int currentYear = Calendar.getInstance().get(Calendar.YEAR); String[] fy =
 * getFinancialYearFromDB(1).get(0).split(" - ");
 * 
 * int startYear = Integer.parseInt(fy[0]); int endYear =
 * Integer.parseInt(fy[1]);
 * 
 * if (lastFinPeriod != 0) { startYear = lastFinPeriod - 1; }
 * 
 * for (int i = startYear; i <= currentYear + nxtFinPeriod; i++) { lst.add(i +
 * " - " + (i + 1)); }
 * 
 * return lst; }
 * 
 * public Map<String, Integer> getFinYearWithYears() { Map<String, Integer> map
 * = new ConcurrentHashMap<>(); List<String> fy = getFinancialYears(0);
 * 
 * for (String year : fy) { String[] parts = year.split(" - "); if (parts.length
 * == 2) { map.put(parts[0].trim(), Integer.parseInt(parts[1].trim())); } }
 * return map; } }
 */