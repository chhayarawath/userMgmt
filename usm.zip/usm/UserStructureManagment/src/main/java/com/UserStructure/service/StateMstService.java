package com.UserStructure.service;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;
import com.UserStructure.Bean.CountryBean;
import com.UserStructure.Bean.StateMstBean;
import com.UserStructure.entity.GbltCountryMstImsc;
import com.UserStructure.entity.GbltStateMstImsc;
import com.UserStructure.repository.CountryDao;
import com.UserStructure.repository.StateMstDao;
import com.UserStructure.usm.DvdmsConfig;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

@Service
public class StateMstService {

	@Autowired
    private StateMstDao stateMstDao;

    @Autowired
    private CountryDao countryDao;
    
    
    public List<GbltCountryMstImsc> getCountryList() {
        return countryDao.findAllValidCountries();
    }

    // Define the getStateList method
    public List<StateMstBean> getStateList(HttpSession session, Integer countryCode, Integer isValid) {
        Integer hospCode = (Integer) session.getAttribute("hospitalCode");
        List<GbltStateMstImsc> stateList = stateMstDao.findAllByFilters(hospCode, countryCode, isValid);
        return stateList.stream().map(this::convertToBean).collect(Collectors.toList());
    }

    private StateMstBean convertToBean(GbltStateMstImsc state) {
        StateMstBean bean = new StateMstBean();
        BeanUtils.copyProperties(state, bean);
        return bean;
    }
    
   
   
    
    public StateMstBean getStateDetail(HttpSession session, Integer hospitalCode, String optionalParam, Integer id) {
        // Logic to retrieve state details based on the given parameters
        GbltStateMstImsc stateEntity = stateMstDao.findById(id).orElse(null);
        
        if (stateEntity != null) {
            StateMstBean stateMstBean = new StateMstBean();
            
            // Populate other properties
            stateMstBean.setGnumStatecode(stateEntity.getGnumStatecode());
            stateMstBean.setGstrStatename(stateEntity.getGstrStatename());
            stateMstBean.setGstrStateshort(stateEntity.getGstrStateshort());
            stateMstBean.setGnumIsvalid(stateEntity.getGnumIsvalid());
            stateMstBean.setGnumIsDefaultUt(stateEntity.getGnumIsDefaultUt()); // Ensure this value is set
            
            return stateMstBean; // Return the populated StateMstBean
        }

        return null; // Return null if the state entity is not found
    }


    
    public Integer createOrUpdateState(StateMstBean stateMstBean) {
    	stateMstBean.setGnumSeatid(DvdmsConfig.SEAT_ID);
    	stateMstBean.setGnumHospitalCode(DvdmsConfig.GLOBAL_HOSPITAL_CODE);
    	stateMstBean.setGdtEntrydate(getDSTimeStamp());
        GbltStateMstImsc state = new GbltStateMstImsc();
        BeanUtils.copyProperties(stateMstBean, state); // Copy data from bean to entity

        // Check for duplicates before saving
        long chkDuplicate = stateMstDao.chkDuplicate(state.getGnumHospitalCode(),
                state.getGstrStatename(), state.getGnumStatecode());

        if (chkDuplicate == 0) {
            // Create or Update state
            if (state.getGnumStatecode() == null || state.getGnumStatecode() == 0) {
                // New State
                stateMstBean.setStrMessage("New State '" + stateMstBean.getGstrStatename() + "' successfully added.");
                return stateMstDao.createState(state); // Create state
            } else {
                // Update existing state
                int updatedRows = stateMstDao.updateState(
                        state.getGnumHospitalCode(), 101, state.getGnumStatecode(),
                        state.getGstrStateshort(), state.getGstrStatename(), 1,
                        state.getGnumSeatid(), state.getGnumIsDefaultUt());

                if (updatedRows > 0) {
                    stateMstBean.setStrMessage("State '" + stateMstBean.getGstrStatename() + "' successfully updated.");
                } else {
                    stateMstBean.setStrMessage("No changes made to state '" + stateMstBean.getGstrStatename() + "'.");
                }
                return updatedRows;
            }
        } else {
            // Duplicate state found
            stateMstBean.setStrMessage("State Name '" + stateMstBean.getGstrStatename() + "' already exists.");
            return 0;
        }
    }
 
    public Date getDSTimeStamp() {
        // Fetch the current timestamp from the repository (DAO)
        return stateMstDao.getDSTimeStamp();
    }
   
    public GbltStateMstImsc getStateByCode(Integer stateCode) {
        return stateMstDao.findByGnumStatecode(stateCode).orElse(null);
    }
    
    public boolean deleteState(List<StateMstBean> stateMstBeans) {
        List<Integer> stateCodes = stateMstBeans.stream()
                .map(StateMstBean::getGnumStatecode) // Ensure state codes are correctly mapped
                .collect(Collectors.toList());

        Integer hospitalCode = DvdmsConfig.GLOBAL_HOSPITAL_CODE;
        Integer countryCode = stateMstBeans.get(0).getGnumCountrycode(); // Ensure this is not null or incorrect

        int deletedCount = stateMstDao.deleteStates(hospitalCode, countryCode, stateCodes);
        return deletedCount > 0;
    }

    
    
}