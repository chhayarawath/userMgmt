package com.UserStructure.util;


	public class ComboOption {

	    private String value; // The value of the combo option
	    private String display; // The display text of the combo option

	    // Default constructor
	    public ComboOption() {
	        this.value = "0";
	        this.display = "Select Value";
	    }

	    // Constructor with String parameters
	    public ComboOption(String value, String display) {
	        this.value = value;
	        this.display = display;
	    }

	    // Constructor with Integer parameter
	    public ComboOption(Integer value, String display) {
	        this.value = String.valueOf(value);
	        this.display = display;
	    }

	    // Constructor with Long parameter
	    public ComboOption(Long value, String display) {
	        this.value = String.valueOf(value);
	        this.display = display;
	    }

	    // Getters for value and display
	    public String getValue() {
	        return value;
	    }

	    public String getDisplay() {
	        return display;
	    }
	}

