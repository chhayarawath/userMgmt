package com.UserStructure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserStructureManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
